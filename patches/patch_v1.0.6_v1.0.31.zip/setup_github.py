# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · GitHub 自动更新托管一键脚本。

用途：把 dist/ 更新文件发布到 GitHub Pages，使启动器能「打开即自动更新」。
前提：需要一个有 repo 权限的 GitHub Personal Access Token（PAT）。

安全说明：
  - Token 仅在本脚本运行期间通过环境变量 GITHUB_TOKEN 传入，不会写入任何文件。
  - 运行结束后请到 GitHub 撤销该 token（Settings → Developer settings → PAT）。
  - 仓库设为 public（GitHub Pages 免费托管 public 仓库；更新文件本身不含任何私密信息）。

用法（在包根目录运行）：
    set GITHUB_TOKEN=ghp_xxxxxxxxxxxx
    python setup_github.py --username 你的GitHub用户名 --repo xiaoneng-comfyui-updater --version v1.0.6

流程：
  1. 校验 token，取得规范用户名（login，全小写）。
  2. 创建 public 仓库（若不存在）。
  3. 调用 make_release.py 生成 dist/（清单 + latest.json，base_url 指向 Pages）。
  4. 把 dist/ 推送到仓库 main 分支。
  5. 开启 GitHub Pages（发布自 main 分支根目录）。
  6. 打印最终 base_url，并提示把它写进 config.py 的 UPDATE_BASE_URLS。
"""
import os
import sys
import json
import time
import shutil
import tempfile
import subprocess
import urllib.request
import urllib.error

_HERE = os.path.dirname(os.path.abspath(__file__))


def _api(method, url, token, data=None, retries=3):
    """极简 GitHub REST 调用。返回 (json_or_text, status, err)。"""
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, method=method)
            req.add_header("Authorization", "Bearer %s" % token)
            req.add_header("Accept", "application/vnd.github+json")
            req.add_header("User-Agent", "xiaoneng-setup")
            if data is not None:
                req.add_header("Content-Type", "application/json")
                req.data = json.dumps(data).encode("utf-8")
            with urllib.request.urlopen(req, timeout=30) as r:
                body = r.read().decode("utf-8", "replace")
                return (json.loads(body) if body else {}), r.status, None
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace")
            try:
                j = json.loads(body)
                msg = j.get("message", body)
            except Exception:
                msg = body
            if e.code in (409, 422) and attempt < retries - 1:
                time.sleep(1.5)
                continue
            return None, e.code, "%s %s: %s" % (method, url, msg)
        except Exception as e:  # noqa
            if attempt < retries - 1:
                time.sleep(1.5)
                continue
            return None, 0, "%s %s: %s" % (method, url, e)
    return None, 0, "重试失败: %s %s" % (method, url)


def _optional_git(args, cwd):
    """执行 git 子命令；失败时仅警告不中断（用于 LFS 等可选步骤）。"""
    try:
        r = subprocess.run(["git"] + list(args), cwd=cwd, capture_output=True, text=True)
        if r.returncode != 0:
            print("  （可选步骤跳过 git %s：%s）" % (args[0], (r.stderr or r.stdout).strip()[:200]))
        else:
            if r.stdout.strip():
                print("  ", r.stdout.strip()[:200])
    except Exception as e:
        print("  （可选步骤跳过 git %s：%s）" % (args[0] if args else "", e))


def run(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if r.returncode != 0:
        print("  STDERR:", r.stderr.strip()[:500])
        raise SystemExit("命令失败（%s）：%s" % (r.returncode, " ".join(cmd[:3])))
    if r.stdout.strip():
        print("  ", r.stdout.strip()[:300])
    return r.stdout


def main():
    import argparse
    ap = argparse.ArgumentParser(description="发布更新到 GitHub Pages")
    ap.add_argument("--username", required=True, help="你的 GitHub 用户名")
    ap.add_argument("--repo", default="xiaoneng-comfyui-updater",
                    help="仓库名（默认 xiaoneng-comfyui-updater）")
    ap.add_argument("--version", default=None, help="要发布的版本号，如 v1.0.6（默认读 config.APP_VERSION）")
    ap.add_argument("--notes", default="自动发布更新文件", help="latest.json 更新说明")
    ap.add_argument("--branch", default="main", help="推送分支（默认 main）")
    args = ap.parse_args()

    token = os.environ.get("GITHUB_TOKEN", "").strip()
    # 本地令牌持久化：首次用环境变量运行后写入项目 .workbuddy/.publish_token，
    # 供后续「改完代码即自动发布」复用（该文件在包目录之外，不会随启动器分发）。
    tok_file = os.path.abspath(
        os.path.join(os.path.dirname(_HERE), ".workbuddy", ".publish_token"))
    if not token and os.path.isfile(tok_file):
        try:
            token = open(tok_file, encoding="utf-8").read().strip()
        except Exception:
            token = ""
    if not token:
        raise SystemExit(
            "未找到 GitHub Token。请设置环境变量 GITHUB_TOKEN，或在\n  %s\n写入你的 GitHub PAT。" % tok_file)
    if os.environ.get("GITHUB_TOKEN") and not os.path.isfile(tok_file):
        try:
            os.makedirs(os.path.dirname(tok_file), exist_ok=True)
            with open(tok_file, "w", encoding="utf-8") as f:
                f.write(os.environ["GITHUB_TOKEN"].strip())
            print("✔ 已将 token 持久化到 %s（供后续自动发布；请勿随包分发）" % tok_file)
        except Exception as e:
            print("  （token 未持久化：%s）" % e)

    # 1. 校验 token + 取规范用户名
    me, status, err = _api("GET", "https://api.github.com/user", token)
    if err or not me or "login" not in me:
        raise SystemExit("Token 校验失败：%s" % (err or "无 login 返回"))
    login = me["login"]
    print("✔ 已登录 GitHub：%s (canonical: %s)" % (args.username, login))

    # 2. 创建仓库（已存在则跳过）
    repo_url = "https://api.github.com/user/repos"
    data = {
        "name": args.repo,
        "private": False,
        "auto_init": True,
        "description": "小能ComfyUI启动器 自动更新托管（latest.json + 增量补丁）",
    }
    j, st, e = _api("POST", repo_url, token, data)
    if e and "already exists" not in (e or "").lower() and st not in (0,):
        # 422/409 常常表示已存在
        print("  创建仓库返回：%s（%s）" % (st, e))
    else:
        print("✔ 仓库就绪：https://github.com/%s/%s" % (login, args.repo))

    # 版本号
    version = args.version
    if not version:
        sys.path.insert(0, os.path.join(_HERE, "app"))
        import config
        version = config.APP_VERSION
    print("▶ 发布版本：%s" % version)

    # 3. 生成 dist/
    dist_dir = os.path.join(_HERE, "dist")
    base_url = "https://%s.github.io/%s" % (login.lower(), args.repo)
    print("▶ 目标 base_url：%s" % base_url)
    run([sys.executable, os.path.join(_HERE, "make_release.py"),
         "--new", _HERE,
         "--dist", dist_dir,
         "--version", version,
         "--base-url", base_url,
         "--notes", args.notes])

    # 4. 推送到 main
    pages_branch = args.branch
    clone_dir = tempfile.mkdtemp(prefix="xiao_gh_")
    try:
        remote = "https://%s@github.com/%s/%s.git" % (token, login, args.repo)
        run(["git", "clone", "--depth", "1", remote, clone_dir])
        # 用 dist 内容覆盖仓库（保留 .git）
        for entry in os.listdir(clone_dir):
            if entry == ".git":
                continue
            p = os.path.join(clone_dir, entry)
            if os.path.isdir(p):
                shutil.rmtree(p)
            else:
                os.remove(p)
        for entry in os.listdir(dist_dir):
            s = os.path.join(dist_dir, entry)
            d = os.path.join(clone_dir, entry)
            if os.path.isdir(s):
                shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)
        # 写一份说明
        with open(os.path.join(clone_dir, "README.md"), "w", encoding="utf-8") as f:
            f.write("# 小能ComfyUI启动器 · 自动更新托管\n\n")
            f.write("本仓库由 `setup_github.py` 自动维护，存放 `latest.json` 与增量补丁。\n")
            f.write("更新地址（base_url）：`%s`\n" % base_url)
            f.write("请勿手动修改 `latest.json` / `patches/`，改由 `make_release.py` 重新生成后推送。\n")
        # 若快照较大（>100MB），用 Git LFS 托管 snapshots/*，绕过 GitHub 单文件 100MB 限制
        _optional_git(["lfs", "install"], clone_dir)
        _optional_git(["lfs", "track", "snapshots/*"], clone_dir)
        run(["git", "config", "user.email", "update-bot@xiaoneng.local"], cwd=clone_dir)
        run(["git", "config", "user.name", "XiaoNeng Updater"], cwd=clone_dir)
        run(["git", "add", "-A"], cwd=clone_dir)
        run(["git", "commit", "-m", "release %s" % version], cwd=clone_dir)
        # 确保分支名
        cur = run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=clone_dir).strip()
        if cur != pages_branch:
            run(["git", "checkout", "-B", pages_branch], cwd=clone_dir)
        run(["git", "push", "-f", "origin", pages_branch], cwd=clone_dir)
    finally:
        shutil.rmtree(clone_dir, ignore_errors=True)

    # 5. 开启 Pages
    pages_api = "https://api.github.com/repos/%s/%s/pages" % (login, args.repo)
    j, st, e = _api("POST", pages_api, token,
                    {"source": {"branch": pages_branch, "path": "/"}})
    if st in (201, 204) or (j and "html_url" in j):
        print("✔ GitHub Pages 已开启")
    else:
        # 可能已开启（409），查询确认
        j2, st2, e2 = _api("GET", pages_api, token)
        if st2 == 200 and j2.get("html_url"):
            print("✔ GitHub Pages 此前已开启：%s" % j2["html_url"])
        else:
            print("⚠ 开启 Pages 返回：%s（%s）。可稍后在仓库 Settings → Pages 手动开启，选择 %s 分支 /(root)。"
                  % (st, e, pages_branch))

    # 6. 结果
    print("\n=== 完成 ===")
    print("仓库：     https://github.com/%s/%s" % (login, args.repo))
    print("Pages：    %s" % base_url)
    print("latest：   %s/latest.json" % base_url)
    print("\n请把下面这行写进 app/config.py 的 UPDATE_BASE_URLS：")
    print('    UPDATE_BASE_URLS = ["%s"]' % base_url)
    print("\n注意：Pages 首次部署可能需 1~2 分钟生效，期间访问会 404，稍后重试即可。")


if __name__ == "__main__":
    main()
