"""检测 ComfyUI 桌面版（官方安装包，基于 Todesktop 分发）的版本更新。

方案 A：仅检测 + 提示，绝不动桌面版文件、不自动安装、不触发下载。
- 本地版本：读 D:\\Comfy Desktop\\resources\\app.asar 内 package.json 的 version（运行中真实核心版本）。
- 最新版本：从 Todesktop 官方更新清单 latest.yml 读取（electron-updater 标准格式）。
- 待装版本：读 Todesktop 已下载到 pending 目录、重启后生效的更新包版本。
"""
import os
import re
import urllib.request

# 桌面版安装路径（用户固定为 D:\Comfy Desktop）
DESKTOP_DIR = r"D:\Comfy Desktop"
# Todesktop 更新清单（electron-updater 标准 latest.yml）
TODESKTOP_LATEST = "https://download.todesktop.com/241130tqe9q3y/latest.yml"
# 本地待安装更新目录（Todesktop 下载后放这里，重启应用生效）
UPDATER_DIR = os.path.join(
    os.environ.get("LOCALAPPDATA", r"C:\Users\Administrator\AppData\Local"),
    "comfyui-desktop-2-updater", "pending")


def _parse_ver(v):
    """把版本串转成可比较的元组，如 '1.0.46' -> (1, 0, 46)。"""
    if not v:
        return (0,)
    nums = re.findall(r"\d+", str(v))
    return tuple(int(x) for x in nums[:4]) if nums else (0,)


def get_local_desktop_version():
    """读已安装的桌面版核心版本（app.asar 内 package.json）。"""
    asar = os.path.join(DESKTOP_DIR, "resources", "app.asar")
    if os.path.isfile(asar):
        try:
            with open(asar, "rb") as f:
                data = f.read()
            m = re.search(rb'"version"\s*:\s*"([\d.]+)"', data)
            if m:
                return m.group(1).decode("utf-8", "replace")
        except Exception:
            pass
    return None


def get_desktop_pending_version():
    """读 Todesktop 已下载但尚未安装的更新版本（重启桌面版后生效）。"""
    if not os.path.isdir(UPDATER_DIR):
        return None
    try:
        for fn in os.listdir(UPDATER_DIR):
            m = re.search(r"(\d+\.\d+\.\d+)", fn)
            if m:
                return m.group(1)
    except Exception:
        pass
    return None


def get_latest_desktop_version(timeout=20):
    """从 Todesktop 官方更新清单读取最新版本号。"""
    req = urllib.request.Request(
        TODESKTOP_LATEST, headers={"User-Agent": "ComfyUI-Launcher"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        text = r.read().decode("utf-8", "replace")
    m = re.search(r"^version:\s*([\d.]+)", text, re.MULTILINE)
    return m.group(1) if m else None


def check_desktop_update():
    """返回桌面版更新状态 dict。

    字段：installed(是否检测到桌面版), local(已装核心版本),
    latest(官方最新版), pending(已下载待重启的版本),
    has_update(本地<最新), error(网络/解析错误)。
    """
    installed = os.path.isdir(DESKTOP_DIR)
    result = {
        "installed": installed,
        "local": None,
        "latest": None,
        "pending": None,
        "has_update": False,
        "error": None,
    }
    if not installed:
        return result
    local = get_local_desktop_version()
    pending = get_desktop_pending_version()
    result["local"] = local
    result["pending"] = pending
    try:
        latest = get_latest_desktop_version()
        result["latest"] = latest
        if local and latest and _parse_ver(local) < _parse_ver(latest):
            result["has_update"] = True
    except Exception as e:
        result["error"] = "无法获取最新版本：%s" % str(e)[:160]
    return result
