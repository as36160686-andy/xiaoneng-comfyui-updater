# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · 配置模块。

所有路径均从本文件位置推导，保证包整体移动后仍正确：
    app/config.py  ->  _PKG_ROOT = 包根（与 ComfyUI/ 平级）
"""
import os
import json

APP_DIR = os.path.dirname(os.path.abspath(__file__))          # 包/app
_PKG_ROOT = os.path.dirname(APP_DIR)                          # 包根目录

COMFY_DIR = os.path.join(_PKG_ROOT, "ComfyUI")
COMFY_URL = "http://127.0.0.1:8190"

# 默认模型根目录
MODEL_DIR_DEFAULT = os.path.join(COMFY_DIR, "models")

# 默认输入 / 输出目录（ComfyUI 原生默认）
INPUT_DIR_DEFAULT = os.path.join(COMFY_DIR, "input")
OUTPUT_DIR_DEFAULT = os.path.join(COMFY_DIR, "output")

# 界面上「默认」状态显示用的相对路径，避免把本机绝对路径写死在 settings.json / UI 上
INPUT_DIR_DISPLAY_DEFAULT = os.path.join("ComfyUI", "input")
OUTPUT_DIR_DISPLAY_DEFAULT = os.path.join("ComfyUI", "output")

# 默认工作流目录
WORKFLOW_DIR = os.path.join(COMFY_DIR, "user", "default", "workflows")

# 默认插件（自定义节点）目录
PLUGIN_DIR_DEFAULT = os.path.join(COMFY_DIR, "custom_nodes")

# 用户设置持久化位置（与 bootstrap.py 读取的 settings.json 为同一文件）
SETTINGS_PATH = os.path.join(_PKG_ROOT, "settings.json")

# 自更新：更新源按「Git 镜像」设置自动选择（境内/境外），无需用户手动填写。
# 每个镜像对应一组基础地址（末尾不带斜杠），客户端并发探测、取版本最高者，
# 下载失败自动切下一个；latest.json 的 mirrors 字段也会作为通用兜底源下发。
#   - 境外(foreign)：GitHub Pages + raw.githubusercontent（官方源）
#   - 境内(china)：ghfast.top 国内代理 + jsDelivr（国内可访问的 GitHub 镜像）
UPDATE_BASE_URLS_BY_MIRROR = {
    "foreign": [
        "https://as36160686-andy.github.io/xiaoneng-comfyui-updater",
        "https://raw.githubusercontent.com/as36160686-andy/xiaoneng-comfyui-updater/main",
    ],
    "china": [
        "https://ghfast.top/https://raw.githubusercontent.com/as36160686-andy/xiaoneng-comfyui-updater/main",
        "https://cdn.jsdelivr.net/gh/as36160686-andy/xiaoneng-comfyui-updater@main",
    ],
}
# 兜底默认（get_git_mirror 取不到时的回退，取境内源）
UPDATE_BASE_URLS = UPDATE_BASE_URLS_BY_MIRROR["china"]

# 启动器版本号（显示在「关于」对话框）。
# 递增规则：每次更新最后一位 +1；当小版本到 9 再进位（如 v1.9.9 -> v2.0.0）。
APP_VERSION = "v1.0.20"


def bump_version(current=APP_VERSION):
    """按规则递增版本号。默认递增当前 APP_VERSION 并写回本常量（调用后需重新导入）。"""
    # 去掉前导 v
    s = current.lstrip("vV")
    parts = s.split(".")
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        raise ValueError("版本号格式必须是 vX.Y.Z：%s" % current)
    major, minor, patch = map(int, parts)
    patch += 1
    if patch > 9:
        patch = 0
        minor += 1
    if minor > 9:
        minor = 0
        major += 1
    return "v%d.%d.%d" % (major, minor, patch)


# Git 境内外镜像（仅作用于包内 PortableGit 拉取）
GIT_MIRRORS = {
    "china": {
        "name": "中国镜像 (ghfast.top)",
        "base": "https://ghfast.top/https://github.com/",
    },
    "foreign": {
        "name": "境外官方 (github.com)",
        "base": "https://github.com",
    },
}

# HuggingFace 境内外镜像
HF_MIRRORS = {
    "china": {
        "name": "中国镜像 (hf-mirror.com)",
        "endpoint": "https://hf-mirror.com",
    },
    "foreign": {
        "name": "境外官方 (huggingface.co)",
        "endpoint": "https://huggingface.co",
    },
}


def _default_settings():
    return {
        "comfy_url": COMFY_URL,
        "model_dir": MODEL_DIR_DEFAULT,
        "input_dir": "",
        "output_dir": "",
        "workflow_dir": WORKFLOW_DIR,
        "plugin_dir": PLUGIN_DIR_DEFAULT,
        "extra_args": "",
        "git_mirror": "china",
        "hf_mirror": "china",
        "check_plugin_deps": True,
    }


def load_settings():
    """读取 settings.json，缺字段用默认值补齐。"""
    try:
        if not os.path.isfile(SETTINGS_PATH):
            return _default_settings()
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return _default_settings()
    except Exception:
        return _default_settings()
    base = _default_settings()
    base.update(data)
    return base


def save_settings(s):
    """原子式写回 settings.json。"""
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        tmp = SETTINGS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
        os.replace(tmp, SETTINGS_PATH)
        return True
    except Exception:
        return False


# ---- ComfyUI 地址 ----
def get_comfy_url():
    return load_settings().get("comfy_url") or COMFY_URL


def set_comfy_url(url):
    s = load_settings()
    s["comfy_url"] = url or COMFY_URL
    save_settings(s)


# ---- 模型根目录 ----
def get_model_dir():
    """返回用户设置的模型根目录；未设置返回默认 ComfyUI/models。"""
    return load_settings().get("model_dir", "") or MODEL_DIR_DEFAULT


def set_model_dir(path):
    """设置并持久化模型根目录。"""
    if path:
        path = os.path.normpath(path)
    s = load_settings()
    s["model_dir"] = path or ""
    save_settings(s)
    return path or ""


# ---- 输入目录 ----
def get_input_dir():
    """返回用户设置的 INPUT 目录；未设置返回 ComfyUI 默认 input。"""
    return load_settings().get("input_dir", "") or INPUT_DIR_DEFAULT


def set_input_dir(path):
    """设置并持久化 INPUT 目录；空字符串表示恢复默认。"""
    if path:
        path = os.path.normpath(path)
    s = load_settings()
    s["input_dir"] = path or ""
    save_settings(s)
    return path or ""


# ---- 输出目录 ----
def get_output_dir():
    """返回用户设置的 OUTPUT 目录；未设置返回 ComfyUI 默认 output。"""
    return load_settings().get("output_dir", "") or OUTPUT_DIR_DEFAULT


def set_output_dir(path):
    """设置并持久化 OUTPUT 目录；空字符串表示恢复默认。"""
    if path:
        path = os.path.normpath(path)
    s = load_settings()
    s["output_dir"] = path or ""
    save_settings(s)
    return path or ""


def get_input_dir_display():
    """返回 INPUT 目录在 UI 上应显示的文本。

    未设置（或保存值恰好等于默认绝对路径）时返回相对路径 ``ComfyUI\\input``，
    避免把本机绝对路径写死在界面上；已设置自定义目录时返回该目录的绝对路径。
    """
    saved = load_settings().get("input_dir", "")
    if not saved or os.path.normpath(saved) == os.path.normpath(INPUT_DIR_DEFAULT):
        return INPUT_DIR_DISPLAY_DEFAULT
    return saved


def get_output_dir_display():
    """返回 OUTPUT 目录在 UI 上应显示的文本（默认显示 ComfyUI\\output）。"""
    saved = load_settings().get("output_dir", "")
    if not saved or os.path.normpath(saved) == os.path.normpath(OUTPUT_DIR_DEFAULT):
        return OUTPUT_DIR_DISPLAY_DEFAULT
    return saved


# ---- 工作流目录（固定为包内默认，不做目录映射）----
def get_workflow_dir():
    """始终返回包内默认工作流目录。

    历史版本支持自定义外部目录并在包内建目录联接(junction)做映射，
    该机制会导致「复制替换包内插件」时实际写到外部目录、被其他
    ComfyUI 进程占用而失败，现已移除：工作流固定在包内。
    """
    return WORKFLOW_DIR


def set_workflow_dir(path):
    """已废弃：工作流目录固定为包内默认，此接口保留仅为兼容旧调用。"""
    return WORKFLOW_DIR


# ---- 插件（自定义节点）目录（固定为包内默认，不做目录映射）----
def get_plugin_dir():
    """始终返回包内默认插件目录 ComfyUI/custom_nodes（真实目录，非联接）。"""
    return PLUGIN_DIR_DEFAULT


def set_plugin_dir(path):
    """已废弃：插件目录固定为包内默认，此接口保留仅为兼容旧调用。"""
    return PLUGIN_DIR_DEFAULT


def reset_internal_dirs():
    """把 settings.json 里的 workflow_dir / plugin_dir 强制写回包内默认值。

    用于升级旧配置（此前可能保存了外部目录）。返回是否发生了改动。
    """
    s = load_settings()
    changed = False
    if s.get("workflow_dir") != WORKFLOW_DIR:
        s["workflow_dir"] = WORKFLOW_DIR
        changed = True
    if s.get("plugin_dir") != PLUGIN_DIR_DEFAULT:
        s["plugin_dir"] = PLUGIN_DIR_DEFAULT
        changed = True
    if changed:
        save_settings(s)
    return changed


# ---- 额外启动参数 ----
def get_extra_args():
    return load_settings().get("extra_args", "") or ""


def set_extra_args(v):
    s = load_settings()
    s["extra_args"] = (v or "").strip()
    save_settings(s)


# ---- 启动检查插件依赖注册 ----
def get_check_plugin_deps():
    """是否在启动服务前检查并注册（安装）插件依赖。默认开启。"""
    v = load_settings().get("check_plugin_deps", True)
    return True if v is None else bool(v)


def set_check_plugin_deps(v):
    s = load_settings()
    s["check_plugin_deps"] = bool(v)
    save_settings(s)


# ---- Git 镜像 ----
def get_git_mirror():
    key = load_settings().get("git_mirror", "china")
    return key if key in GIT_MIRRORS else "china"


def set_git_mirror(key):
    if key not in GIT_MIRRORS:
        key = "china"
    s = load_settings()
    s["git_mirror"] = key
    save_settings(s)


# ---- HuggingFace 镜像 ----
def get_hf_mirror():
    key = load_settings().get("hf_mirror", "china")
    return key if key in HF_MIRRORS else "china"


def set_hf_mirror(key):
    if key not in HF_MIRRORS:
        key = "china"
    s = load_settings()
    s["hf_mirror"] = key
    save_settings(s)


# ---- 自更新地址（按 Git 镜像自动选择境内/境外源，支持用户手动覆盖）----
def _clean_urls(urls):
    """清洗地址列表：去空白、去尾部斜杠、去重且保序。"""
    out = []
    for u in urls or []:
        if not isinstance(u, str):
            continue
        u = u.strip().strip('"').strip("'").rstrip("/")
        if not u:
            continue
        if u not in out:
            out.append(u)
    return out


def get_update_urls():
    """返回更新源地址列表（按优先级）。

    规则：
      1. 用户在「关于」中手动设置过 update_urls（保留兼容性，最高优先级）；
      2. 否则按当前 Git 镜像（git_mirror）自动选择：
         - 境外 → GitHub Pages + raw.githubusercontent
         - 境内 → ghfast.top 代理 + jsDelivr
      无需用户手动填写，开箱即按所在网络环境自动连仓库。
    """
    s = load_settings()
    urls = s.get("update_urls")
    if isinstance(urls, list) and urls:
        return _clean_urls(urls)
    key = get_git_mirror()  # 'china' / 'foreign'
    return _clean_urls(UPDATE_BASE_URLS_BY_MIRROR.get(key, UPDATE_BASE_URLS))


def set_update_urls(urls):
    """保存更新源列表；同时清掉旧的单地址键，避免重复。"""
    if isinstance(urls, str):
        urls = [urls]
    s = load_settings()
    s["update_urls"] = _clean_urls(urls)
    s.pop("update_url", None)
    save_settings(s)


def get_update_url():
    """返回首个（优先级最高的）更新地址；空串表示关闭自动更新。向后兼容。"""
    urls = get_update_urls()
    return urls[0] if urls else ""


def set_update_url(url):
    """仅设置单个更新地址（向后兼容）。"""
    set_update_urls([url] if url else [])
