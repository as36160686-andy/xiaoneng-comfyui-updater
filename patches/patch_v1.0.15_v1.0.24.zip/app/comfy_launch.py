# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · ComfyUI 启动/停止核心逻辑。

设计要点：
  - 全部路径从本文件位置推导，包可整体移动。
  - 子进程隐藏运行（STARTUPINFO + CREATE_NO_WINDOW），无黑框。
  - 通过 PID 文件（ComfyUI/user/comfyui.pid）持久化记录本次启动的进程，
    即使重启启动器也能准确停止。
  - 停止兜底：按端口用 netstat 定位占用进程杀树（覆盖「手动启动的 ComfyUI」等场景）。
  - 中文 Windows 的 netstat 输出为 GBK，须按字节解码，否则崩溃。
"""
import os
import re
import sys
import shutil
import time
import json
import shlex
import socket
import tempfile
import subprocess

APP_DIR = os.path.dirname(os.path.abspath(__file__))
_PKG_ROOT = os.path.dirname(APP_DIR)
COMFY_DIR = os.path.join(_PKG_ROOT, "ComfyUI")

# 包内 Python（venv 优先，回退 standalone-env）
_VENV_PY = os.path.join(COMFY_DIR, ".venv", "Scripts", "python.exe")
_BASE_PY = os.path.join(COMFY_DIR, "standalone-env", "python.exe")
COMFY_PYTHON = _VENV_PY if os.path.isfile(_VENV_PY) else _BASE_PY
COMFY_MAIN = os.path.join(COMFY_DIR, "main.py")

# 内置 Git（PortableGit）
_GIT_DIR = os.path.join(_PKG_ROOT, "tools", "PortableGit")
GIT_EXE = os.path.join(_GIT_DIR, "cmd", "git.exe")
BUNDLED_GIT_HOME = os.path.join(_GIT_DIR, "home")

import config

# 当前启动的子进程引用（同一会话内可用；跨会话靠 PID 文件）
_proc = None


# ---------------------------------------------------------------------------
# 环境构造
# ---------------------------------------------------------------------------
def _comfy_env():
    """构造 ComfyUI 子进程的环境变量。

    注入包内 PortableGit 到 PATH 首位，并设置 GitPython 所需的
    GIT_PYTHON_GIT_EXECUTABLE，以及 HOME/USERPROFILE（让 git 在包内写配置）。
    同时按用户选择的境内外镜像设置：
      - Git：通过 GIT_CONFIG_* 环境变量注入 insteadOf（不污染全局 git 配置）
      - HuggingFace：HF_ENDPOINT
    """
    env = dict(os.environ)
    git_dir = _GIT_DIR
    if os.path.isdir(git_dir):
        cmd = os.path.join(git_dir, "cmd")
        bin_ = os.path.join(git_dir, "bin")
        paths = env.get("PATH", "")
        prepend = ";".join([p for p in (cmd, bin_) if os.path.isdir(p)])
        env["PATH"] = prepend + ";" + paths if prepend else paths

    # 让 ComfyUI 子进程能找到 venv/Scripts 里的原生二进制（如 sox.exe）。
    # sox 的 Python 包在 import 时执行 os.popen('sox -h')，依赖 PATH 上能找到 sox.exe；
    # 不把 venv Scripts 加入 PATH，子进程就找不到我们放进去的 sox.exe。
    _venv_scripts = os.path.join(COMFY_DIR, ".venv", "Scripts")
    if os.path.isdir(_venv_scripts):
        _cur = env.get("PATH", "")
        if _venv_scripts not in _cur.split(";"):
            env["PATH"] = _venv_scripts + ";" + _cur

    if os.path.isfile(GIT_EXE):
        env["GIT_PYTHON_GIT_EXECUTABLE"] = GIT_EXE
    env["GIT_PYTHON_REFRESH"] = "quiet"
    if os.path.isdir(BUNDLED_GIT_HOME):
        env["HOME"] = BUNDLED_GIT_HOME
        env["USERPROFILE"] = BUNDLED_GIT_HOME

    # Git 镜像（insteadOf，仅作用于本进程 git 调用）
    gm = config.GIT_MIRRORS.get(config.get_git_mirror(), config.GIT_MIRRORS["china"])
    mirror_base = gm["base"]  # 如 https://ghfast.top/https://github.com
    # insteadOf 重写规则：把 https://github.com/ 前缀换成 mirror_base。
    # mirror_base 必须以 / 结尾，否则 Comfy-Org 会被粘在 github.com 后面。
    if mirror_base and not mirror_base.endswith("/"):
        mirror_base += "/"
    # 境外官方镜像就是 github.com/ 本身，不需要 insteadOf。
    if mirror_base in ("https://github.com/", "https://github.com"):
        env["GIT_CONFIG_COUNT"] = "0"
    else:
        env["GIT_CONFIG_COUNT"] = "1"
        # GIT_CONFIG_KEY 不需要给 URL 加引号；加引号会被 git 解析成协议的一部分，
        # 导致 fatal: protocol '"https' is not supported。
        env["GIT_CONFIG_KEY_0"] = "url.%s.insteadOf" % mirror_base
        env["GIT_CONFIG_VALUE_0"] = "https://github.com/"

    # HuggingFace 镜像
    hm = config.HF_MIRRORS.get(config.get_hf_mirror(), config.HF_MIRRORS["china"])
    env["HF_ENDPOINT"] = hm["endpoint"]

    return env


# ---------------------------------------------------------------------------
# 就绪检测 / 端口工具
# ---------------------------------------------------------------------------
def is_ready(url=None, timeout=3):
    """ComfyUI 是否可访问。"""
    url = url or config.get_comfy_url()
    try:
        import urllib.request
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def _host_port(url):
    try:
        from urllib.parse import urlparse
        o = urlparse(url or config.get_comfy_url())
        host = o.hostname or "127.0.0.1"
        port = o.port or 8190
        return host, port
    except Exception:
        return "127.0.0.1", 8190


def _port_in_use(port, host="127.0.0.1"):
    s = socket.socket()
    s.settimeout(0.5)
    try:
        return s.connect_ex((host, int(port))) == 0
    except Exception:
        return False
    finally:
        s.close()


def _pid_listening_on(port):
    """返回正在监听指定 TCP 端口的 PID；找不到返回 None。

    中文 Windows 下 netstat 输出为 GBK，必须按字节读取后 decode('gbk')，
    否则 text=True 默认 UTF-8 会抛 UnicodeDecodeError。
    """
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    try:
        proc = subprocess.run(
            ["netstat", "-ano", "-p", "TCP"],
            capture_output=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            startupinfo=si,
        )
        out = proc.stdout.decode("gbk", errors="replace")
    except Exception:
        return None
    target = ":%s " % port
    for line in out.splitlines():
        if target in line:
            parts = line.split()
            if parts:
                # 末列即 PID（不依赖英文/中文状态词）
                return parts[-1]
    return None


def _kill_tree(pid):
    """结束进程树（含子进程）。成功返回 True。"""
    if not pid:
        return False
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    try:
        r = subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            capture_output=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            startupinfo=si,
        )
        return r.returncode == 0
    except Exception:
        return False


# ---------------------------------------------------------------------------
# PID 文件
# ---------------------------------------------------------------------------
def _pid_file():
    return os.path.join(COMFY_DIR, "user", "comfyui.pid")


def _read_pid():
    try:
        p = _pid_file()
        if os.path.isfile(p):
            with open(p, "r", encoding="utf-8") as f:
                v = f.read().strip()
            return int(v) if v.isdigit() else None
    except Exception:
        return None
    return None


def _write_pid(pid):
    try:
        d = os.path.dirname(_pid_file())
        os.makedirs(d, exist_ok=True)
        with open(_pid_file(), "w", encoding="utf-8") as f:
            f.write(str(pid))
    except Exception:
        pass


def _clear_pid():
    try:
        p = _pid_file()
        if os.path.isfile(p):
            os.remove(p)
    except Exception:
        pass


def _comfy_log_path():
    d = os.path.join(COMFY_DIR, "user")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "comfyui_subprocess.log")


# ---------------------------------------------------------------------------
# CUDA 预检
# ---------------------------------------------------------------------------
def _run_cuda_probe(timeout=20):
    """在隔离子进程中探测 CUDA 信息，避免 torch.cuda 初始化崩溃传染主进程。

    返回 dict，包含：
      torch_version / torch_cuda_version / device_count / available /
      driver_version / nvidia_smi_cuda / error
    任一字段出错时返回 error 字符串，device_count 默认为 0。
    """
    result = {
        "torch_version": "unknown",
        "torch_cuda_version": "unknown",
        "device_count": 0,
        "available": False,
        "driver_version": "unknown",
        "nvidia_smi_cuda": "unknown",
        "error": None,
    }
    if not os.path.isfile(COMFY_PYTHON):
        result["error"] = "未找到 Python：%s" % COMFY_PYTHON
        return result

    script = r"""
import re, subprocess, torch
out = {
    "torch_version": torch.__version__,
    "torch_cuda_version": torch.version.cuda or "cpu",
    "device_count": 0,
    "available": False,
    "driver_version": "unknown",
    "nvidia_smi_cuda": "unknown",
    "gpu_name": "unknown",
    "error": None,
}
try:
    out["device_count"] = torch.cuda.device_count()
    out["available"] = torch.cuda.is_available()
    if out["available"]:
        out["gpu_name"] = torch.cuda.get_device_name(0)
except Exception as e:
    out["error"] = str(e)

# 调用 nvidia-smi 并按 GBK 解码；失败返回空串。
# 中文 Windows 下 nvidia-smi 输出为 GBK，text=True（UTF-8）会抛
# UnicodeDecodeError，必须按字节读取后手动解码。
def _smi(args=None):
    try:
        cmd = ["nvidia-smi"] + (args or [])
        r = subprocess.run(
            cmd, capture_output=True, timeout=10,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode != 0:
            return ""
        return r.stdout.decode("gbk", errors="replace")
    except Exception:
        return ""

# 驱动版本
txt = _smi(["--query-gpu=driver_version", "--format=csv,noheader"]).strip()
if txt:
    out["driver_version"] = txt.splitlines()[0].strip()

# 驱动支持的 CUDA 版本。
# 新版 nvidia-smi(>=560) 输出 "CUDA UMD Version: 13.4"，
# 旧版为 "CUDA Version: 12.4"，两种格式都要兼容。
smi = _smi()
m = re.search(r"CUDA\s+UMD\s+Version:\s*(\d+\.\d+)", smi)
if not m:
    m = re.search(r"CUDA\s+Version:\s*(\d+\.\d+)", smi)
if m:
    out["nvidia_smi_cuda"] = m.group(1)

print(repr(out))
"""
    try:
        proc = subprocess.Popen(
            [COMFY_PYTHON, "-c", script],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        stdout, stderr = proc.communicate(timeout=timeout)
        txt = stdout.decode("utf-8", errors="replace").strip()
        if not txt:
            err = stderr.decode("utf-8", errors="replace").strip()
            result["error"] = err or "CUDA 探测子进程无输出（可能已崩溃）"
            return result
        # 安全求值：只接受 dict 字面量
        parsed = eval(txt, {"__builtins__": {}}, {})
        if isinstance(parsed, dict):
            result.update(parsed)
        else:
            result["error"] = "CUDA 探测返回格式异常"
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
        except Exception:
            pass
        result["error"] = "CUDA 探测超时（%ss），torch.cuda 初始化卡住或崩溃" % timeout
    except Exception as e:
        result["error"] = "CUDA 探测异常：%s" % e
    return result


def check_cuda():
    """返回可用 CUDA 设备数；无 / 异常返回 0。

    通过隔离子进程探测，避免本进程被 PyTorch 的 CUDA 初始化错误带崩。
    """
    return _run_cuda_probe().get("device_count", 0)


def cuda_health_check():
    """返回 CUDA 健康信息 dict；调用方用于启动前提示。"""
    return _run_cuda_probe()


def sanitize_cuda_device(args):
    """剔除非法的 --cuda-device N（N 越界或无 CUDA）。返回清洗后的参数列表。"""
    if not isinstance(args, list):
        args = shlex.split(args or "")
    has = any(a == "--cuda-device" for a in args)
    if not has:
        return args
    try:
        i = args.index("--cuda-device")
        dev = int(args[i + 1])
    except (ValueError, IndexError):
        return args
    n = check_cuda()
    if n == 0 or dev >= n:
        # 非法，移除该参数及其值
        return [a for j, a in enumerate(args) if j not in (i, i + 1)]
    return args


# ---------------------------------------------------------------------------
# 启动 / 停止
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 工作流目录映射（让 ComfyUI 启动时自动加载用户配置的工作流目录）
# ---------------------------------------------------------------------------
def _read_reparse_target(path):
    """若 path 为联接 / 符号链接，返回其（归一化）目标路径；否则返回 None。

    Windows 上 os.readlink 对 junction 会返回带 \\\\?\\ 前缀的路径，这里去掉前缀并
    normpath，便于与用户配置路径做大小写/斜杠无关的比较。
    """
    try:
        t = os.readlink(path)
    except (OSError, ValueError, NotImplementedError):
        return None
    if t.startswith("\\\\?\\"):
        t = t[4:]
    return os.path.normpath(t)


def _create_workflow_junction(link, target):
    """在 link 创建指向 target 的目录联接（Windows 用 mklink /J，跨平台回退 os.symlink）。"""
    if sys.platform == "win32":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        r = subprocess.run(
            ["cmd", "/c", "mklink", "/J", link, target],
            capture_output=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            startupinfo=si,
        )
        if r.returncode != 0:
            raise RuntimeError(
                (r.stderr or r.stdout).decode("gbk", "replace").strip()
                or "mklink 失败")
    else:
        os.symlink(target, link, target_is_directory=True)


def _restore_one_dir(link_path, logger, label):
    """把包内 link_path 还原为真实目录。

    若该路径是目录联接(junction)：仅用 os.rmdir 删除联接本身（不会触达外部目标
    文件），从而取消外部映射；若此前有 .bak 备份目录且当前无内容，则还原备份；
    否则确保真实目录存在。
    """
    if _read_reparse_target(link_path) is not None:
        try:
            os.rmdir(link_path)  # 仅删除联接本身，不触达目标
            if logger:
                logger("🔓 已解除 %s 的目录联接（取消外部映射）" % label)
        except Exception as e:
            if logger:
                logger("⚠ 无法删除 %s 联接：%s（请手动删除后重试）" % (label, e))
            return
    bak = link_path + ".bak"
    if os.path.isdir(bak) and not os.path.exists(link_path):
        try:
            os.rename(bak, link_path)
            if logger:
                logger("↩️ %s 已从备份还原" % label)
            return
        except Exception:
            pass
    try:
        os.makedirs(link_path, exist_ok=True)
    except Exception as e:
        if logger:
            logger("⚠ 创建 %s 真实目录失败：%s" % (label, e))


def sync_workflow_dir(logger=None):
    """取消工作流目录的外部映射，确保使用包内真实目录。

    历史版本会在包内建目录联接(junction)指向外部「工作流路径」；现已改回
    固定包内路径、不做映射。此处仅负责清理残留联接：若是联接则仅删除联接
    （不触达外部目标文件），并还原 .bak 备份或创建真实目录。
    """
    _restore_one_dir(
        os.path.join(COMFY_DIR, "user", "default", "workflows"),
        logger, "工作流目录")


def sync_plugin_dir(logger=None):
    """取消插件目录的外部映射，确保使用包内真实目录 ComfyUI/custom_nodes。

    历史版本会在包内建目录联接(junction)指向外部「插件路径」；现已改回固定
    包内路径、不做映射。此处仅清理残留联接（仅删联接、不触达目标文件），
    并还原 .bak 备份或创建真实目录。插件依赖注册 / 版本管理均作用于此真实目录。
    """
    _restore_one_dir(
        os.path.join(COMFY_DIR, "custom_nodes"),
        logger, "插件目录")


# ---------------------------------------------------------------------------
# 插件依赖注册
# ---------------------------------------------------------------------------
def effective_plugin_dir():
    """返回 ComfyUI 实际扫描的插件目录。

    现已固定为包内真实目录 ComfyUI/custom_nodes（不再使用目录联接/外部映射）。
    依赖注册、版本管理均作用于此目录。
    """
    return os.path.join(COMFY_DIR, "custom_nodes")


def is_plugin_dir_linked():
    """包内 custom_nodes 是否为指向外部目录的联接。"""
    return _read_reparse_target(os.path.join(COMFY_DIR, "custom_nodes"))


# 依赖名别名归一化：部分插件 requirements.txt 写的是「导入名」而非 PyPI 包名，
# 直接 pip install 会失败（如 PIL 在 PyPI 上不存在，真包是 Pillow）。在此统一重定向，
# 既避免误判「缺失」，也避免触发必然失败的 pip 安装。
_NAME_ALIASES = {
    "PIL": "Pillow",
    "pillow": "Pillow",
    "pyyaml": "PyYAML",
    "yaml": "PyYAML",
}

# 可选依赖：安装耗时大 / 需 CUDA 工具链 + 编译器、且插件可回退的路径。
# 这些依赖若缺失，启动时归类为「可选/跳过」而非「注册失败」，避免误报。
_OPTIONAL_PACKAGES = {"cupy-wheel", "cupy-cuda11x", "cupy-cuda12x"}


def _is_optional_pkg(spec):
    """判断某依赖声明是否属于「可选」——缺失不应判为注册失败。"""
    name = _pkg_name(spec).lower()
    if name in _OPTIONAL_PACKAGES:
        return True
    if name.startswith("cupy-cuda"):
        return True
    return False


def _pkg_name(spec):
    """从依赖声明里取出包名（去掉版本约束 / extras / 环境标记）。"""
    s = (spec or "").strip()
    s = s.split("#", 1)[0].strip()          # 行内注释
    s = re.split(r";", s, 1)[0].strip()     # 环境标记
    s = s.split("[", 1)[0].strip()          # extras
    s = re.split(r"[<>=!~ ]", s, 1)[0].strip()
    return _NAME_ALIASES.get(s, s)


def _is_url_req(s):
    """是否 VCS / URL 形式的依赖（pip 可装但耗时且常需网络，单独提示手动安装）。"""
    low = (s or "").lower()
    return ("://" in low or low.startswith("git+") or " @ " in s
            or "@ git+" in low or low.startswith("http"))


def _parse_req_line(line):
    """解析 requirements.txt 的一行，返回标准化依赖声明。

    - 空行 / 注释 / pip 选项(-r/-e/--xxx) / VCS-URL 形式一律返回 ''。
    - 行内 PEP 508 环境标记（如 ; platform_system!="Windows"）会被求值：
      在当前平台为 False 时整行跳过（如 pynini / WeTextProcessing 在 Windows 上
      本就不需要安装，硬装反而会因缺 MSVC 编译器而失败——这是此前「注册失败」的根因）。
    - 包名按 _NAME_ALIASES 归一化（PIL->Pillow 等）。
    """
    s = (line or "").strip()
    if not s or s.startswith("#") or s.startswith("-"):
        return ""
    s = s.split(" #", 1)[0].strip()
    if _is_url_req(s):
        return ""
    # 用 packaging 正确解析 PEP 508（处理 extras / 环境标记 / 版本约束）
    try:
        from packaging.requirements import Requirement
        req = Requirement(s)
    except Exception:
        # 退化：去掉环境标记后用正则取包名（保守保留，避免漏装）
        name = _pkg_name(s)
        return name
    # 环境标记：在当前平台为 False 则整行跳过（不是缺失）
    if req.marker is not None and not req.marker.evaluate():
        return ""
    name = _NAME_ALIASES.get(req.name, req.name)
    spec = str(req.specifier)
    return (name + spec) if spec else name


def _collect_urls(line):
    """返回该行里的 VCS/URL 依赖原文（用于提示手动安装）；环境标记为 False 则跳过。"""
    s = (line or "").strip()
    if not s or s.startswith("#") or s.startswith("-"):
        return ""
    s = s.split(" #", 1)[0].strip()
    if not _is_url_req(s):
        return ""
    try:
        from packaging.requirements import Requirement
        req = Requirement(s)
        if req.marker is not None and not req.marker.evaluate():
            return ""
    except Exception:
        pass
    return s


def _read_pyproject_deps(folder):
    """读取插件 pyproject.toml 里的 dependencies（无 tomllib 时正则兜底）。"""
    p = os.path.join(folder, "pyproject.toml")
    if not os.path.isfile(p):
        return []
    try:
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except Exception:
        return []
    try:
        import tomllib
        data = tomllib.loads(text)
        deps = (data.get("project") or {}).get("dependencies") or []
        if isinstance(deps, list):
            return [_parse_req_line(d) for d in deps]
    except Exception:
        pass
    m = re.search(r"dependencies\s*=\s*\[(.*?)\]", text, re.S)
    if not m:
        return []
    out = []
    for item in re.findall(r"[\"']([^\"']+)[\"']", m.group(1)):
        r = _parse_req_line(item)
        if r:
            out.append(r)
    return out


def scan_plugin_requirements(plugin_dir=None):
    """扫描插件目录下每个插件的依赖声明。

    返回 [(插件名, [可 pip 安装的依赖...], [需手动安装的 VCS/URL 依赖...]), ...]
    （已按插件名排序）。
    """
    d = plugin_dir or effective_plugin_dir()
    out = []
    if not os.path.isdir(d):
        return out
    for name in sorted(os.listdir(d)):
        full = os.path.join(d, name)
        if not os.path.isdir(full) or name.startswith("."):
            continue
        reqs, urls = [], []
        rp = os.path.join(full, "requirements.txt")
        if os.path.isfile(rp):
            try:
                with open(rp, "r", encoding="utf-8", errors="replace") as f:
                    for ln in f:
                        u = _collect_urls(ln)
                        if u:
                            if u not in urls:
                                urls.append(u)
                            continue
                        r = _parse_req_line(ln)
                        if r and r not in reqs:
                            reqs.append(r)
            except Exception:
                pass
        for r in _read_pyproject_deps(full):
            if _is_url_req(r):
                if r not in urls:
                    urls.append(r)
            elif r and r not in reqs:
                reqs.append(r)
        out.append((name, reqs, urls))
    return out


_QUERY_SCRIPT = r'''
import json, re, sys
from importlib.metadata import distributions

with open(sys.argv[1], "r", encoding="utf-8") as f:
    specs = json.load(f)

installed = set()
for d in distributions():
    n = d.metadata["Name"] or ""
    if n:
        installed.add(n.lower().replace("_", "-"))

missing = []
for spec in specs:
    name = re.split(r"[<>=!~\[; ]", spec.strip(), 1)[0].strip()
    if not name:
        continue
    if name.lower().replace("_", "-") not in installed:
        missing.append(spec)
print(json.dumps(missing, ensure_ascii=False))
'''


def dedupe_specs(specs):
    """按包名去重。同一包出现不同声明时保留首个，冲突项单独返回。

    ComfyUI 各插件可能对同一个包要求不同版本（如 pynini==2.1.5 / ==2.1.6），
    整批安装必然失败，因此只保留首个并提示冲突，由用户按需手动处理。
    """
    seen, uniq, conflicts = {}, [], []
    for s in specs or []:
        key = _pkg_name(s).lower().replace("_", "-")
        if not key:
            continue
        if key in seen:
            old = seen[key]
            if old == s:
                continue
            # 保留带版本约束的声明（更严格），否则保留先出现的
            keep = s if (re.search(r"[<>=!~]", s) and not re.search(r"[<>=!~]", old)) else old
            drop = s if keep is old else old
            conflicts.append((keep, drop))
            if keep is not old:
                seen[key] = keep
                uniq[uniq.index(old)] = keep
            continue
        seen[key] = s
        uniq.append(s)
    return uniq, conflicts


def missing_packages(specs, timeout=120):
    """返回 venv 中尚未安装的依赖声明子集（已安装的会被过滤掉）。

    返回 (缺失列表, 错误信息)；错误信息为 None 表示查询成功。
    注意：查询子进程一旦异常（如 venv 损坏），历史上会把「全部声明」误判为缺失，
    进而让几乎所有插件被标为待注册/注册失败。此处把异常显式返回，由调用方决定
    是否中止，而不是默默返回全量缺失。
    """
    if not specs:
        return [], None
    if not os.path.isfile(COMFY_PYTHON):
        return list(specs), "未找到包内 Python：%s" % COMFY_PYTHON
    tmpdir = tempfile.mkdtemp(prefix="xndep_")
    qfile = os.path.join(tmpdir, "query.json")
    sfile = os.path.join(tmpdir, "query.py")
    try:
        with open(qfile, "w", encoding="utf-8") as f:
            json.dump(list(specs), f, ensure_ascii=False)
        with open(sfile, "w", encoding="utf-8") as f:
            f.write(_QUERY_SCRIPT)
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        proc = subprocess.Popen(
            [COMFY_PYTHON, sfile, qfile],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            startupinfo=si,
        )
        out, err = proc.communicate(timeout=timeout)
        txt = out.decode("utf-8", errors="replace").strip()
        if not txt:
            return list(specs), "查询子进程无输出（venv 探测可能失败）"
        return json.loads(txt), None
    except Exception as e:
        return list(specs), "依赖查询异常：%s" % e
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def _pip_install(specs, logger=None, timeout=1800):
    """执行一次 pip install。返回 (ok, 失败详情)。"""
    if not specs:
        return True, ""
    if not os.path.isfile(COMFY_PYTHON):
        return False, "未找到包内 Python：%s" % COMFY_PYTHON
    cmd = [COMFY_PYTHON, "-m", "pip", "install",
           "--disable-pip-version-check", "--no-input",
           "--no-build-isolation",
           "--no-warn-script-location"] + list(specs)
    if logger:
        logger("⬇ pip install %s" % " ".join(specs))
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            startupinfo=si,
        )
    except Exception as e:
        return False, "启动 pip 失败：%s" % e

    tail = []
    deadline = time.time() + timeout
    try:
        while True:
            if time.time() > deadline:
                try:
                    proc.kill()
                except Exception:
                    pass
                return False, "安装超时（%ss）" % timeout
            line = proc.stdout.readline()
            if not line and proc.poll() is not None:
                break
            if not line:
                time.sleep(0.2)
                continue
            txt = line.decode("gbk", errors="replace").rstrip()
            if txt:
                tail.append(txt)
                if len(tail) > 200:
                    tail.pop(0)
                if logger:
                    logger("   " + txt)
    except Exception as e:
        return False, "安装过程异常：%s" % e

    ok = proc.returncode == 0
    if ok:
        return True, ""
    return False, "\n".join(tail[-15:])


def install_packages(specs, logger=None, timeout=1800):
    """把依赖安装到 ComfyUI venv。返回 (ok, 失败详情)。

    先整批安装（快）；若整批失败（常见于个别依赖在 PyPI 上不存在/装不了），
    自动降级为逐项安装，隔离坏依赖，保证其余依赖仍能注册成功。
    """
    if not specs:
        return True, ""
    ok, detail = _pip_install(specs, logger, timeout)
    if ok:
        return True, ""
    if len(specs) == 1:
        return False, "%s：%s" % (specs[0], detail)
    if logger:
        logger("⚠ 整批安装失败，改为逐项安装以隔离异常依赖…")
    failed = []
    for s in specs:
        ok1, d1 = _pip_install([s], logger, timeout)
        if not ok1:
            failed.append(s)
            if logger:
                logger("   ❌ %s 安装失败" % s)
    if not failed:
        return True, ""
    return False, "以下依赖安装失败：%s" % ", ".join(failed)


# ---------------------------------------------------------------------------
# 包内进程清理：保证「未启动 / 已停止」时没有任何包内文件被加载
# ---------------------------------------------------------------------------
def _package_runtime_roots():
    """包内 ComfyUI 运行时解释器所在目录（只有这些进程会加载插件文件）。"""
    return [os.path.join(COMFY_DIR, ".venv"),
            os.path.join(COMFY_DIR, "python_embeded")]


def _package_runtime_pids():
    """返回由包内 ComfyUI 运行时（.venv / python_embeded）启动的进程 PID 列表。"""
    if sys.platform != "win32":
        return []
    roots = [r for r in _package_runtime_roots() if os.path.isdir(r)]
    if not roots:
        return []
    # 用 PowerShell/CIM 取可执行文件路径，只有路径落在包内运行时目录的才计入，
    # 避免误杀用户自己另外安装的 ComfyUI（不在本包内）。
    # 单行脚本：括号配对最直观，避免多行拼接时漏掉收尾大括号导致 ParserError。
    ps = (
        "$roots = @('%s'); "
        "Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath } | "
        "ForEach-Object { $p = $_.ExecutablePath; foreach ($r in $roots) { "
        "if ($p.StartsWith($r, [System.StringComparison]::OrdinalIgnoreCase)) "
        "{ $_.ProcessId; break } } }"
    ) % "', '".join(r.replace("'", "''") for r in roots)
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    try:
        proc = subprocess.Popen(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            startupinfo=si,
        )
        out, _ = proc.communicate(timeout=30)
    except Exception:
        return []
    txt = out.decode("gbk", errors="replace")
    pids = []
    for ln in txt.splitlines():
        ln = ln.strip()
        if ln.isdigit():
            pids.append(int(ln))
    return pids


def kill_stray_comfy_processes(logger=None):
    """结束仍占用包内文件的 ComfyUI 运行时进程（不含本进程与父进程）。

    用于「停止服务后 / 退出启动器前」的兜底清理：ComfyUI 子进程是 detached 派生的，
    若上一次是被强杀或启动器直接关闭，可能残留后台进程继续占用 custom_nodes 里的
    .pyd/.dll，导致用户复制/替换插件目录时报「文件被占用」。
    返回被结束的 PID 列表。
    """
    skip = {os.getpid()}
    try:
        skip.add(os.getppid())
    except Exception:
        pass
    killed = []
    for pid in _package_runtime_pids():
        if pid in skip:
            continue
        if _kill_tree(pid):
            killed.append(pid)
            if logger:
                logger("🧹 已结束残留进程 PID=%s（释放包内文件占用）" % pid)
    return killed


def _build_args(extra_args=None):
    url = config.get_comfy_url()
    host, port = _host_port(url)
    if extra_args is None:
        extra_args = config.get_extra_args()
    tokens = shlex.split(extra_args or "")
    tokens = sanitize_cuda_device(tokens)

    has_port = any(t == "--port" for t in tokens)
    has_listen = any(t == "--listen" for t in tokens)
    has_input = any(t == "--input-directory" for t in tokens)
    has_output = any(t == "--output-directory" for t in tokens)
    args = [COMFY_PYTHON, COMFY_MAIN]
    if not has_listen:
        args += ["--listen", host]
    if not has_port:
        args += ["--port", str(port)]
    # 用户自定义 INPUT/OUTPUT 目录（仅在设置中显式指定且未在启动参数中冲突时追加）
    if not has_input:
        input_dir = config.get_input_dir()
        if input_dir and os.path.normpath(input_dir) != os.path.normpath(config.INPUT_DIR_DEFAULT):
            args += ["--input-directory", input_dir]
    if not has_output:
        output_dir = config.get_output_dir()
        if output_dir and os.path.normpath(output_dir) != os.path.normpath(config.OUTPUT_DIR_DEFAULT):
            args += ["--output-directory", output_dir]
    args += tokens
    return args


def spawn_comfyui(silent=True, extra_args=None, logger=None):
    """后台启动 ComfyUI，返回 subprocess.Popen。

    logger 为可选回调，用于实时回显日志。
    启动前会先做 CUDA 健康检查，若 PyTorch CUDA 初始化异常且用户未显式指定
    --cpu，则给出明确提示，避免直接崩在 ComfyUI 子进程里才看到 access violation。
    """
    global _proc
    if not os.path.isfile(COMFY_MAIN):
        if logger:
            logger("❌ 找不到 ComfyUI 入口：%s" % COMFY_MAIN)
        return None
    # 启动前将工作流路径 / 插件目录映射为 ComfyUI 可读的目录联接
    sync_workflow_dir(logger)
    sync_plugin_dir(logger)
    args = _build_args(extra_args)

    # CUDA 预检：在隔离子进程中探测，避免把启动器自身带崩
    is_cpu_mode = "--cpu" in args or "--cpu-only" in args
    if not is_cpu_mode:
        health = cuda_health_check()
        if logger:
            logger("CUDA 预检：PyTorch %s（CUDA %s）| 驱动 %s | 设备数 %s | nvidia-smi CUDA %s" % (
                health.get("torch_version", "unknown"),
                health.get("torch_cuda_version", "unknown"),
                health.get("driver_version", "unknown"),
                health.get("device_count", 0),
                health.get("nvidia_smi_cuda", "unknown"),
            ))
        if health.get("error") or health.get("device_count", 0) == 0:
            if logger:
                logger("⚠ CUDA 不可用：%s" % (health.get("error") or "未检测到 NVIDIA GPU"))
                logger("   临时绕过：在「启动参数」里加 --cpu 可用 CPU 模式启动；")
                logger("   彻底解决：更新显卡驱动，或用「更新→环境依赖」安装与本机驱动匹配的 PyTorch/CUDA 版本。")
            # 仍然放行启动：可能用户就是要看具体报错；但已经给出提示。

    env = _comfy_env()
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    log_path = _comfy_log_path()
    try:
        logf = open(log_path, "ab", buffering=0)
    except Exception:
        logf = None
    _proc = subprocess.Popen(
        args,
        cwd=COMFY_DIR,
        env=env,
        stdout=logf,
        stderr=subprocess.STDOUT if logf else subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        startupinfo=si,
    )
    _write_pid(_proc.pid)
    if logger:
        logger("▶ 已启动 ComfyUI（PID=%s）：%s" % (_proc.pid, config.get_comfy_url()))
        logger("   命令：%s" % " ".join(args))
    return _proc


# 兼容旧调用名
launch_comfyui = spawn_comfyui


def find_running(url=None):
    """ComfyUI 是否已在运行。"""
    return is_ready(url)


def stop_comfyui(timeout=5, logger=None):
    """停止 ComfyUI。优先 PID 文件 → 内存进程 → 端口兜底（循环重试）。

    返回 True 表示端口最终释放。
    """
    global _proc
    killed = False

    # 1) PID 文件优先：即使再次打开启动器也能准确找到上次启动的进程
    recorded_pid = _read_pid()
    if recorded_pid:
        if recorded_pid == os.getpid():
            if logger:
                logger("忽略 PID 文件中的自身 PID")
        else:
            if logger:
                logger("从 PID 文件读取到 ComfyUI 进程 PID=%s" % recorded_pid)
            if _kill_tree(recorded_pid):
                if logger:
                    logger("已结束 PID=%s 进程树" % recorded_pid)
                killed = True
            else:
                if logger:
                    logger("结束 PID=%s 进程树失败（可能已退出）" % recorded_pid)

    # 2) 内存中的子进程
    if _proc is not None and _proc.poll() is None:
        try:
            if logger:
                logger("正在终止当前记录的 ComfyUI 进程 PID=%s…" % _proc.pid)
            _proc.terminate()
            _proc.wait(timeout=timeout)
            if logger:
                logger("当前 ComfyUI 进程已正常退出")
            killed = True
        except Exception:
            if logger:
                logger("正常退出失败，强制结束当前进程树…")
            try:
                if _kill_tree(_proc.pid):
                    if logger:
                        logger("已强制结束当前 ComfyUI 进程树")
                    killed = True
            except Exception as e:
                if logger:
                    logger("强制结束当前进程树异常：%s" % e)
    _proc = None

    # 3) 端口兜底：循环重试直到端口释放
    port = _host_port(config.get_comfy_url())[1]
    for attempt in range(4):
        if not _port_in_use(port):
            break
        pid = _pid_listening_on(port)
        if pid:
            if logger:
                logger("端口 %s 仍被 PID=%s 占用，强制结束…" % (port, pid))
            if _kill_tree(pid):
                killed = True
        else:
            if logger:
                logger("端口 %s 被占用但无法定位 PID" % port)
        time.sleep(1)

    _clear_pid()

    # 4) 兜底清理：结束仍由包内运行时启动的残留进程，
    #    确保「服务停止后」没有任何包内文件（插件 .pyd/.dll）被占用。
    kill_stray_comfy_processes(logger)

    time.sleep(1)
    if not _port_in_use(port):
        if logger:
            logger("✅ 端口已释放，ComfyUI 服务已停止，包内文件已解除占用"
                   "（可安全复制/替换 custom_nodes）")
        return True
    if logger:
        logger("⚠ 停止后端口仍被占用，可能需要任务管理器手动结束")
    return False
