@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
set "PYINSTALLER_RESET_ENVIRONMENT=1"
for /f "usebackq tokens=1* delims==" %%a in (`set`) do (
    set "varname=%%a"
    if /I "!varname:~0,4!"=="_PYI" set "%%a="
)
set "i=0"
:waitloop
tasklist /fi "PID eq 34376" /nh /fo csv 2>nul | findstr /I "34376" >nul
if errorlevel 1 goto launch
timeout /t 1 >nul
set /a i+=1
if !i! lss 10 goto waitloop
:launch
timeout /t 2 >nul
start "" "D:\ComfyUI小助手\小能ComfyUI启动器\启动.exe"
del "%~f0"
