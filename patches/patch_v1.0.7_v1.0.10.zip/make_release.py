# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · 发版补丁生成器。

用法（在包根目录运行）：
    python make_release.py \
        --new "D:/build/小能ComfyUI启动器" \
        --dist "D:/build/dist" \
        --version v1.0.5 \
        --base-url "https://<user>.github.io/<repo>/dist" \
        [--mirror "https://pan.xxx.com/s/xxxx/dist"]      # 可多次，网盘等备用源
        [--full-zip-url "https://.../完整包.zip"]         # 可多次用 --full-zip-url-mirror
        [--notes "本次更新说明"] \
        [--prev-version v1.0.4]   # 可多次指定，默认读取 dist/manifests/*.json

多更新源（GitHub 仓库 + 网盘同时用）：
  同一份 dist/ 目录分别上传到多个地方即可，客户端会并发探测所有源、取版本最高的，
  下载失败自动切下一个。增量包走**相对路径**（patches/xxx.zip），因此只要镜像保持
  dist/ 的目录结构就能直接用；只托管了完整包 zip 的网盘，可用 --full-zip-url-mirror
  指定直链，作为「没有增量补丁时」的回退。

功能：
  1. 扫描新版包，生成完整文件清单 dist/manifests/<version>.json
     （自动排除 settings.json / models / outputs / user / __pycache__ 等用户数据）。
  2. 对每个「旧版本清单」做差，只把变动文件打成
     dist/patches/patch_<旧版本>_<新版本>.zip，
     并在 zip 内嵌入完整新清单（__upd__/manifest.json）与元信息（__upd__/meta.json）。
  3. 生成 dist/latest.json（指向最新版本与各旧版本对应的增量包）。
  4. 打印托管说明（把 dist/ 整体上传到 --base-url 对应位置即可）。

客户端（app/updater.py）打开软件时会拉取 latest.json：
  - 若当前版本有对应增量包 → 只下载几 KB~几 MB 的 patch.zip 自动覆盖；
  - 否则回退下载完整包（full_zip_url，由你另行上传的完整 zip 提供）。

注意：完整包 zip 仍需你按原有方式打包上传（作为首次安装/大版本回退用），
本脚本只负责增量部分与清单。
"""
import os
import sys
import re
import json
import time
import argparse
import hashlib
import zipfile
import tempfile
import shutil

# 复用本仓库 app/updater.py 的清单/排除逻辑，保证两端一致
_HERE = os.path.dirname(os.path.abspath(__file__))


def _load_updater(new_pkg=None):
    app_dir = os.path.join(_HERE, "app")
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    import updater
    return updater


def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(chunk), b""):
            h.update(b)
    return h.hexdigest()


def build_manifest(upd, root):
    return updater_compute(upd, root)


def updater_compute(upd, root):
    return upd.compute_manifest(root)


def build_patch(upd, new_pkg, new_manifest, old_version, old_manifest, patch_path):
    """生成 patch.zip：变动文件 + 完整新清单 + 元信息。返回 (size, sha256)。"""
    # 变动文件
    changed = []
    for rel, meta in new_manifest.items():
        if old_manifest.get(rel) != meta:
            changed.append(rel)
    # 删除文件（旧有、新无）
    deleted = [rel for rel in old_manifest if rel not in new_manifest]

    os.makedirs(os.path.dirname(patch_path), exist_ok=True)
    tmp = patch_path + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel in changed:
            full = os.path.join(new_pkg, rel)
            if not os.path.isfile(full):
                continue
            zf.write(full, arcname=rel)
        # 完整新清单（供客户端校验与后续差分）
        zf.writestr(upd.UPD_PREFIX + "manifest.json",
                    json.dumps(new_manifest, ensure_ascii=False, separators=(",", ":")))
        # 元信息
        zf.writestr(upd.UPD_PREFIX + "meta.json",
                    json.dumps({"version": None, "deleted": deleted},
                               ensure_ascii=False, separators=(",", ":")))
    os.replace(tmp, patch_path)
    size = os.path.getsize(patch_path)
    sha = sha256_file(patch_path)
    return size, sha, len(changed), len(deleted)


def build_snapshot(upd, new_pkg, new_manifest, snapshot_path):
    """生成某版本的全量快照 zip（含 __upd__/manifest.json，便于降级/跨版本还原）。

    仅包含「启动器自身管理的文件」：排除 ComfyUI/（其源码与插件通常 1GB+，且由用户
    自行通过 ComfyUI Manager 管理、不随启动器版本回退，误删风险高）、以及 venv / 模型 /
    输出 / 用户数据等。因此快照体积很小，且降级时绝不会触碰用户的 ComfyUI 与模型。
    """
    # 快照作用域：除常规排除项外，再剔除 ComfyUI/ 整棵目录
    snap_manifest = {k: v for k, v in new_manifest.items() if not k.startswith("ComfyUI/")}
    os.makedirs(os.path.dirname(snapshot_path), exist_ok=True)
    tmp = snapshot_path + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel in snap_manifest:
            full = os.path.join(new_pkg, rel)
            if os.path.isfile(full):
                zf.write(full, arcname=rel)
        zf.writestr(upd.UPD_PREFIX + "manifest.json",
                    json.dumps(snap_manifest, ensure_ascii=False, separators=(",", ":")))
    os.replace(tmp, snapshot_path)
    return os.path.getsize(snapshot_path), sha256_file(snapshot_path)


def _github_io_to_raw(base_url):
    """https://user.github.io/repo -> https://raw.githubusercontent.com/user/repo/main"""
    m = re.match(r"https?://([^.]+)\.github\.io/([^/]+)/?$", base_url.rstrip("/"))
    if m:
        return "https://raw.githubusercontent.com/%s/%s/main" % (m.group(1), m.group(2))
    return ""


def main():
    ap = argparse.ArgumentParser(description="生成启动器增量更新补丁")
    ap.add_argument("--new", required=True, help="新版包根目录（含 ComfyUI/、app/、启动.exe）")
    ap.add_argument("--dist", required=True, help="输出目录（将写入 manifests/、patches/、latest.json）")
    ap.add_argument("--version", required=True, help="新版本号，如 v1.0.5")
    ap.add_argument("--base-url", required=True, help="latest.json 托管基础地址（如 GitHub Pages/dist）")
    ap.add_argument("--notes", default="", help="更新说明（写入 latest.json）")
    ap.add_argument("--full-zip-url", default="",
                    help="完整包 zip 的绝对下载地址（回退用，可选）")
    ap.add_argument("--mirror", action="append", default=[],
                    help="额外更新源地址（可多次），如网盘直链目录；与 --base-url 互为备份")
    ap.add_argument("--full-zip-url-mirror", action="append", default=[],
                    help="完整包 zip 的备用直链（可多次），没有增量补丁时的回退地址")
    ap.add_argument("--prev-version", action="append", default=[],
                    help="指定要生成补丁的基准旧版本（可多次）。默认读取 dist/manifests/*.json")
    args = ap.parse_args()

    new_pkg = os.path.abspath(args.new)
    dist = os.path.abspath(args.dist)
    if not os.path.isdir(new_pkg):
        print("✗ 新版包目录不存在：%s" % new_pkg)
        sys.exit(1)

    upd = _load_updater(new_pkg)

    print("▶ 扫描新版包清单：%s" % new_pkg)
    new_manifest = upd.compute_manifest(new_pkg)
    print("  文件数：%d" % len(new_manifest))

    manifests_dir = os.path.join(dist, "manifests")
    patches_dir = os.path.join(dist, "patches")
    os.makedirs(manifests_dir, exist_ok=True)
    os.makedirs(patches_dir, exist_ok=True)

    # 保存新版本完整清单
    new_manifest_path = os.path.join(manifests_dir, args.version + ".json")
    with open(new_manifest_path, "w", encoding="utf-8") as f:
        json.dump(new_manifest, f, ensure_ascii=False, separators=(",", ":"))
    print("✔ 已写出清单：%s" % new_manifest_path)

    # 决定基准旧版本清单
    prev_list = []
    if args.prev_version:
        for pv in args.prev_version:
            p = os.path.join(manifests_dir, pv + ".json")
            if os.path.isfile(p):
                prev_list.append((pv, p))
            else:
                print("⚠ 未找到旧版本清单（跳过）：%s" % p)
    else:
        for fn in sorted(os.listdir(manifests_dir)):
            if fn.endswith(".json") and fn != (args.version + ".json"):
                prev_list.append((fn[:-5], os.path.join(manifests_dir, fn)))

    patches = {}
    for pv, ppath in prev_list:
        try:
            with open(ppath, "r", encoding="utf-8") as f:
                old_manifest = json.load(f)
        except Exception as e:
            print("⚠ 旧清单读取失败 %s：%s" % (ppath, e))
            continue
        patch_name = "patch_%s_%s.zip" % (pv, args.version)
        patch_path = os.path.join(patches_dir, patch_name)
        size, sha, n_chg, n_del = build_patch(
            upd, new_pkg, new_manifest, pv, old_manifest, patch_path)
        patches[pv] = {
            "url": "patches/" + patch_name,
            "size": size,
            "sha256": sha,
            "changed": n_chg,
            "deleted": n_del,
        }
        print("✔ 补丁 %s：变更 %d 文件 / 删除 %d 文件，%d 字节"
              % (patch_name, n_chg, n_del, size))

    # 归一化镜像地址（去尾部斜杠、去重保序）
    def _clean(us):
        out = []
        for u in us or []:
            u = (u or "").strip().rstrip("/")
            if u and u not in out:
                out.append(u)
        return out

    base = args.base_url.rstrip("/") + "/"
    # 通用兜底镜像：把 GitHub Pages 地址换算成 raw.githubusercontent，作为所有用户的最终回退源
    raw_fb = _github_io_to_raw(args.base_url)
    mirrors = _clean([raw_fb] + list(args.mirror))
    mirrors = [m for m in mirrors if m != base.rstrip("/")]
    full_zip_urls = _clean([args.full_zip_url] + list(args.full_zip_url_mirror))

    latest = {
        "version": args.version,
        "notes": args.notes,
        "base_url": base,
        "mirrors": mirrors,
        "full_zip_url": full_zip_urls[0] if full_zip_urls else "",
        "full_zip_urls": full_zip_urls,
        "patches": patches,
    }
    latest_path = os.path.join(dist, "latest.json")
    with open(latest_path, "w", encoding="utf-8") as f:
        json.dump(latest, f, ensure_ascii=False, indent=2)
    print("✔ 已写出 latest.json：%s" % latest_path)

    # 生成该版本的全量快照（用于历史版本选择 / 降级还原）
    snapshots_dir = os.path.join(dist, "snapshots")
    os.makedirs(snapshots_dir, exist_ok=True)
    snapshot_name = "%s.zip" % args.version
    snapshot_path = os.path.join(snapshots_dir, snapshot_name)
    snap_size, snap_sha = build_snapshot(upd, new_pkg, new_manifest, snapshot_path)
    print("✔ 已写出快照：%s（%d 字节，sha256=%s…）" % (snapshot_path, snap_size, snap_sha[:12]))

    # 维护 versions.json（累积所有历史版本，仓库保留旧版本）
    versions_file = os.path.join(dist, "versions.json")
    existing = []
    if os.path.isfile(versions_file):
        try:
            existing = json.load(open(versions_file, encoding="utf-8")).get("versions", [])
        except Exception:
            existing = []
    existing = [e for e in existing if isinstance(e, dict) and e.get("version") != args.version]
    entry = {
        "version": args.version,
        "date": time.strftime("%Y-%m-%d"),
        "notes": args.notes,
        "snapshot_url": "snapshots/" + snapshot_name,
        "patches": {
            pv: {"url": p["url"], "size": p["size"], "sha256": p["sha256"]}
            for pv, p in patches.items()
        },
    }
    existing.append(entry)
    existing.sort(key=lambda e: upd.parse_ver(e.get("version", "v0.0.0")))
    versions_data = {"latest": args.version, "versions": existing}
    with open(versions_file, "w", encoding="utf-8") as f:
        json.dump(versions_data, f, ensure_ascii=False, indent=2)
    print("✔ 已更新 versions.json：共 %d 个历史版本" % len(existing))

    all_sources = [base.rstrip("/")] + mirrors
    print("\n=== 托管说明 ===")
    print("1. 把 dist/ 整个目录分别上传到以下 %d 个更新源：" % len(all_sources))
    for i, s in enumerate(all_sources, 1):
        print("   %d. %s" % (i, s))
    print("   每个源的 latest.json 都必须可被直链访问（如 <源>/latest.json）。")
    print("   增量包使用相对路径 patches/*.zip，镜像只要保持 dist/ 目录结构即可直接复用。")
    print("2. 完整包 zip（首次安装/大版本回退用）请另行打包上传，")
    print("   并把直链通过 --full-zip-url / --full-zip-url-mirror 写入 latest.json。")
    print("3. 客户端打开软件会并发探测所有源，取版本最高的；下载失败自动切换下一个源。")
    if mirrors:
        print("\nℹ 已配置 %d 个备用源，任一源可用即可完成更新。" % len(mirrors))
    if not patches:
        print("\n⚠ 本次未生成任何增量补丁（无旧版本清单作基准）。")
        print("  首次发版属正常；后续版本请把上一版 manifests/*.json 留在 dist/ 中。")


if __name__ == "__main__":
    main()
