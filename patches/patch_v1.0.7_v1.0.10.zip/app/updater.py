# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · 自更新客户端（纯标准库，不依赖 PySide，可被 bootstrap 调用）。

增量更新思路：
  - 发布端（make_release.py）把新版包与上一版清单做差，只把「变动文件」打成
    patch.zip，并在 zip 内嵌入完整新清单（__upd__/manifest.json）与元信息（__upd__/meta.json）。
  - 本端（启动器）打开软件时拉取 latest.json，发现版本更新则只下载几 KB~几 MB 的
    patch.zip，逐文件校验 sha256 后覆盖到包内，并备份旧文件以便回滚。
  - 启动器主程序（启动.exe）若在补丁内被更新，无法在运行时原地覆盖，改为暂存为
    `启动_new.exe`，由 bootstrap 在下次启动时完成替换并重拉起，实现「启动器核心自更新」。

多更新源（GitHub 仓库 + 网盘可同时配置，互为备份）：
  - 配置多个源地址时，并发探测所有源的 latest.json，取「版本号最高」的那个；
  - 下载阶段主源失败会自动切下一个源重试（补丁走相对路径，因此每个源都能拼出自己的地址）；
  - 服务器还可通过 latest.json 的 mirrors 字段下发额外镜像，客户端自动合并。
  - 全部源都不可达时静默跳过，离线照样能用。

安全：
  - 覆盖前把被替换/删除的文件备份到 `.update_bak/<旧版本>/`，中途失败可回滚，不让软件变砖。
  - 服务器不可达时静默跳过（离线也能用）。
  - 不触碰用户数据：settings.json / models / outputs / user 工作流 等始终被排除在清单之外。
"""
import os
import io
import sys
import json
import shutil
import hashlib
import zipfile
import threading
import urllib.request
import urllib.error

try:
    import config
except Exception:  # bootstrap 早期可能尚未把 app 加入 sys.path
    config = None


# ---- 路径推导 ----
_HERE = os.path.dirname(os.path.abspath(__file__))      # 包/app
PKG_ROOT = os.path.dirname(_HERE)                        # 包根目录（与 ComfyUI/ 平级）

MANIFEST_FILE = ".package_manifest.json"                 # 当前已安装文件清单（rel -> {sha256,size}）
BAK_DIR = ".update_bak"                                  # 备份根目录
UPD_PREFIX = "__upd__/"                                  # patch 内元信息文件夹（不落地到包）
EXE_NAME = "启动.exe"                                    # 启动器主程序（onefile 引导器）
EXE_STAGE = "启动_new.exe"                               # 暂存的新版启动器（待下次启动替换）

# 永远不更新、不删除的用户数据 / 临时文件 / 重型运行环境 / 工具链缓存
_EXCLUDE_DIRS = {
    "__pycache__", ".git", BAK_DIR, "System Volume Information",
    "outputs", "output", "models", "user", ".github", "node_modules",
    # 以下为巨型运行环境或本地构建产物，绝不可纳入更新清单（否则会尝试随补丁
    # 传输/删除 torch 等 1.7GB+ 内容，既浪费又危险）：
    ".venv", "standalone-env", "dist", "build", ".workbuddy",
    # tools/ 是 PortableGit 等工具链（含 pip 缓存、输入法缓存等数百 MB 垃圾），
    # 属静态工具、不随启动器版本变化，且误删会破坏 git 功能，故整体排除出更新范围。
    "tools",
}
_EXCLUDE_FILES = {
    "settings.json", MANIFEST_FILE, "launch_log.txt",
    EXE_STAGE, "启动_old.exe", "desktop.ini", "Thumbs.db", ".DS_Store",
}


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------
def _log(msg):
    try:
        print("[updater] " + msg, file=sys.stderr)
    except Exception:
        pass


def normalize_rel(root, path):
    """返回相对包根、统一正斜杠的路径。"""
    rel = os.path.relpath(path, root)
    return rel.replace(os.sep, "/")


def is_excluded(rel):
    """判断某相对路径是否属于「用户数据/临时文件」，应排除在更新外。"""
    parts = rel.split("/")
    name = parts[-1]
    if name in _EXCLUDE_FILES:
        return True
    # 仅排除顶层/任意层级的这些目录名
    for p in parts:
        if p in _EXCLUDE_DIRS:
            return True
    return False


def file_sha256(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def parse_ver(v):
    """'v1.0.4' -> (1,0,4)；失败返回 (0,0,0)。"""
    s = (v or "").lstrip("vV")
    try:
        return tuple(int(x) for x in s.split("."))
    except Exception:
        return (0, 0, 0)


def ver_gt(a, b):
    return parse_ver(a) > parse_ver(b)


def current_version():
    if config is not None:
        try:
            return config.APP_VERSION
        except Exception:
            pass
    return "v0.0.0"


# ---------------------------------------------------------------------------
# 清单
# ---------------------------------------------------------------------------
def compute_manifest(root):
    """扫描 root 下所有文件（排除用户数据），返回 {rel: {sha256, size}}。"""
    m = {}
    for dirpath, dirnames, filenames in os.walk(root):
        # 原地剪枝：跳过大体积/用户数据目录，省时间
        dirnames[:] = [d for d in dirnames if not is_excluded(d)]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = normalize_rel(root, full)
            if is_excluded(rel):
                continue
            try:
                st = os.stat(full)
                if not os.path.isfile(full):
                    continue
                m[rel] = {"sha256": file_sha256(full), "size": st.st_size}
            except Exception:
                continue
    return m


def load_local_manifest(root):
    p = os.path.join(root, MANIFEST_FILE)
    if not os.path.isfile(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def save_local_manifest(root, manifest):
    p = os.path.join(root, MANIFEST_FILE)
    tmp = p + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp, p)
        return True
    except Exception as e:
        _log("保存本地清单失败：%s" % e)
        return False


# ---------------------------------------------------------------------------
# 网络
# ---------------------------------------------------------------------------
def _resolve_url(base, url):
    if url.startswith("http://") or url.startswith("https://"):
        return url
    if not base:
        return url
    return base.rstrip("/") + "/" + url.lstrip("/")


def fetch_bytes(url, timeout=30, progress_cb=None):
    """下载并返回 bytes；失败返回 (None, err)。progress_cb(done, total, msg)。"""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "XiaoNeng-Launcher-Updater"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            total = int(resp.headers.get("Content-Length", "0") or "0")
            data = io.BytesIO()
            done = 0
            chunk = 1 << 16
            while True:
                buf = resp.read(chunk)
                if not buf:
                    break
                data.write(buf)
                done += len(buf)
                if progress_cb:
                    try:
                        progress_cb(done, total, "下载中")
                    except Exception:
                        pass
        return data.getvalue(), None
    except urllib.error.URLError as e:
        return None, "网络错误：%s" % e
    except Exception as e:
        return None, "下载失败：%s" % e


def fetch_json(url, timeout=15):
    data, err = fetch_bytes(url, timeout=timeout)
    if err:
        return None, err
    try:
        return json.loads(data.decode("utf-8")), None
    except Exception as e:
        return None, "JSON 解析失败：%s" % e


def _host(url):
    """从 URL 提取简短主机标识，用于日志/错误提示。"""
    try:
        if url.lower().startswith("file://"):
            return "本地目录"
        rest = url.split("://", 1)[-1]
        host = rest.split("/", 1)[0]
        return host or url
    except Exception:
        return url


def download_file(url, dest, timeout=120, progress_cb=None, expected_sha=None,
                  alt_urls=None):
    """下载到 dest（覆盖写）。失败返回 (False, err)。

    alt_urls：备用地址列表（多更新源时逐个重试）。expected_sha 会校验每个源的下载结果，
    因此即使切到网盘等非官方源，也能保证内容一致。
    """
    urls = [u for u in ([url] + list(alt_urls or [])) if u]
    errs = []
    for idx, u in enumerate(urls):
        if idx > 0 and progress_cb:
            try:
                progress_cb(0, 0, "主源失败，切换备用源：%s" % _host(u))
            except Exception:
                pass
        data, err = fetch_bytes(u, timeout=timeout, progress_cb=progress_cb)
        if err:
            errs.append("[%s] %s" % (_host(u), err))
            continue
        try:
            os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
            tmp = dest + ".part"
            with open(tmp, "wb") as f:
                f.write(data)
            if expected_sha:
                if file_sha256(tmp) != expected_sha:
                    os.remove(tmp)
                    errs.append("[%s] 校验和不匹配（sha256 不符）" % _host(u))
                    continue
            os.replace(tmp, dest)
            return True, None
        except Exception as e:
            errs.append("[%s] 写入失败：%s" % (_host(u), e))
    if not errs:
        return False, "无可用下载地址"
    return False, "；".join(errs)


# ---------------------------------------------------------------------------
# 检查更新
# ---------------------------------------------------------------------------
def resolve_sources(base_urls=None):
    """归一化更新源列表：支持传入 str / list；None 时读取 config.get_update_urls()。

    返回清洗后的地址列表（去空白、去尾部斜杠、去重保序）。
    """
    if base_urls is None:
        if config is not None:
            try:
                base_urls = config.get_update_urls()
            except Exception:
                base_urls = []
        else:
            base_urls = []
    if isinstance(base_urls, str):
        base_urls = [base_urls]
    out = []
    for u in base_urls or []:
        if not isinstance(u, str):
            continue
        u = u.strip().strip('"').strip("'").rstrip("/")
        if u and u not in out:
            out.append(u)
    return out


def _check_one_source(src, timeout):
    """检查单个更新源，返回 (info, err)。info 为 None 表示已是最新。"""
    latest_url = _resolve_url(src, "latest.json")
    data, err = fetch_json(latest_url, timeout=timeout)
    if err:
        return None, err
    if not isinstance(data, dict):
        return None, "latest.json 格式错误"
    remote_ver = data.get("version", "")
    # 服务器声明的额外镜像，合并进来（用于源自身搬迁/扩容时下发新地址）
    extra = data.get("mirrors") or []
    if isinstance(extra, str):
        extra = [extra]
    sources = [src] + [m for m in extra if isinstance(m, str) and m.strip()]
    sources = resolve_sources(sources)
    if not ver_gt(remote_ver, current_version()):
        return None, None
    base = data.get("base_url") or src
    cur = current_version()
    patches = data.get("patches", {}) or {}
    patch = patches.get(cur) or _find_best_patch(patches, cur)
    fz = data.get("full_zip_url", "") or ""
    fz_list = data.get("full_zip_urls") or []
    if isinstance(fz_list, str):
        fz_list = [fz_list]
    info = {
        "version": remote_ver,
        "notes": data.get("notes", ""),
        "base_url": base,
        "sources": sources,                    # 候选源（第一个为当前命中源）
        "source": sources[0] if sources else base,
        "full_zip_url": _resolve_url(base, fz) if fz else "",
        "full_zip_rel": fz,                    # 相对路径，便于切源时重新拼接
        "full_zip_urls": [_resolve_url(base, x) for x in fz_list if x],
        "patches": patches,                  # 保留完整补丁映射，供历史版本/跨版本选择时使用
        "patch": None,
    }
    if patch:
        rel = patch.get("url", "") or ""
        info["patch"] = {
            "url": _resolve_url(base, rel),
            "rel_url": rel,                    # 相对路径，切源时可复用
            "size": patch.get("size", 0),
            "sha256": patch.get("sha256", ""),
        }
    return info, None


def check_for_update(base_url=None, timeout=15):
    """并发探测所有更新源，取版本号最高的可用更新。

    base_url：可传单个地址字符串，也可传地址列表（None 时读取配置）。

    返回 (info, err)：
      info = {
        "version": "v1.0.6",
        "notes": "...",
        "source": "<命中的源>",
        "sources": ["<源1>", "<源2>", ...],     # 下载失败时按顺序切换
        "base_url": "<用于拼接相对地址>",
        "full_zip_url": "<绝对地址，回退用>",
        "full_zip_urls": [...],                 # 完整包的各源地址
        "patch": {"url":..., "rel_url":..., "size":..., "sha256":...} | None,
      }
      info 为 None 表示已是最新或无可用更新；err 非 None 表示所有源都不可用。
    """
    sources = resolve_sources(base_url)
    if not sources:
        return None, "未配置更新地址（请在「关于」→「更新源地址」填写，每行一个）"

    results = {}
    errors = {}

    def _work(src):
        try:
            info, err = _check_one_source(src, timeout)
            results[src] = (info, err)
        except Exception as e:
            results[src] = (None, str(e))

    threads = []
    for s in sources:
        t = threading.Thread(target=_work, args=(s,), daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join(timeout=timeout + 5)

    # 未返回的线程视为失败
    for i, s in enumerate(sources):
        if s not in results:
            errors[s] = "探测超时"

    best = None
    ok_any = False
    for s in sources:
        info, err = results.get(s, (None, "探测超时"))
        if err:
            errors[s] = err
            continue
        ok_any = True
        if info and (best is None or ver_gt(info["version"], best["version"])):
            best = info

    if best is None:
        if ok_any:
            return None, None  # 至少一个源连通，但已是最新
        detail = "；".join("[%s] %s" % (_host(s), e) for s, e in errors.items())
        return None, "所有更新源均不可用：%s" % detail

    # 备选下载源：命中的源排第一，其余按「已连通 → 原顺序」排列
    alive = [s for s in sources if s in results and not results[s][1]]
    fallbacks = [best.get("source")] + [s for s in alive if s != best.get("source")]
    for s in sources:
        if s not in fallbacks:
            fallbacks.append(s)
    fallbacks = resolve_sources(fallbacks)
    best["sources"] = fallbacks

    # 按候选源展开完整包地址（相对路径才能跨源复用）
    if best.get("full_zip_rel"):
        fz_rel = best["full_zip_rel"]
        if not (fz_rel.startswith("http://") or fz_rel.startswith("https://")):
            urls = [_resolve_url(s, fz_rel) for s in fallbacks]
            urls += [u for u in best.get("full_zip_urls", []) if u not in urls]
            best["full_zip_urls"] = urls
            best["full_zip_url"] = urls[0]
    if best.get("patch") and best["patch"].get("rel_url"):
        rel = best["patch"]["rel_url"]
        if not (rel.startswith("http://") or rel.startswith("https://")):
            best["patch_urls"] = [_resolve_url(s, rel) for s in fallbacks]
            best["patch"]["url"] = best["patch_urls"][0]
    return best, None


def list_versions(base_url=None, timeout=15):
    """拉取 versions.json，返回 (versions, err)。

    versions 为按发布顺序（旧→新）排列的条目列表，每项含：
      version / date / notes / snapshot_url / patches(可选)。
    err 为 None 表示成功（versions 可能为空列表，表示仓库未提供历史版本）；
    返回 (None, err) 表示网络/解析失败（此时调用方应仅用 latest.json 的单版本）。
    """
    sources = resolve_sources(base_url)
    if not sources:
        return None, "未配置更新地址"
    last_err = ""
    for src in sources:
        url = _resolve_url(src, "versions.json")
        data, err = fetch_json(url, timeout=timeout)
        if err:
            # 404 等「文件不存在」视为「暂无历史版本」，不算致命
            if "404" in (err or "") or "Not Found" in (err or ""):
                return [], None
            last_err = err
            continue
        if not isinstance(data, dict) or not isinstance(data.get("versions"), list):
            last_err = "versions.json 格式错误"
            continue
        out = [v for v in data["versions"] if isinstance(v, dict) and v.get("version")]
        out.sort(key=lambda x: parse_ver(x.get("version", "v0.0.0")))
        return out, None
    return None, last_err or "无可用更新源"


def build_target_info(target_version, versions, latest_info, current, sources):
    """把「所选历史/目标版本」构造成与 check_for_update 同构的 info（供 download_update 复用）。

    - 若 target == latest 且 latest 有针对 current 的增量补丁 → 走快路径(patch)
    - 否则 → 走该版本的全量快照 snapshot（支持跨版本升级与降级）
    返回 (info, err)；info 为 None 表示已是最新或无法更新。
    """
    sources = resolve_sources(sources) or []
    if not sources:
        return None, "未配置更新地址"
    if target_version == current:
        return None, "已是最新版本"
    entry = None
    for v in (versions or []):
        if v.get("version") == target_version:
            entry = v
            break
    latest_ver = latest_info.get("version") if isinstance(latest_info, dict) else None

    # 最新版：优先增量补丁快路径
    if target_version == latest_ver and isinstance(latest_info, dict):
        patches = latest_info.get("patches") or {}
        p = patches.get(current) or _find_best_patch(patches, current)
        info = {
            "version": target_version,
            "notes": latest_info.get("notes", ""),
            "sources": sources,
            "source": sources[0],
            "base_url": latest_info.get("base_url", ""),
            "full_zip_urls": [],
            "patch": None,
            "_mode": "patch",
            "snapshot_url": None,
        }
        if p:
            rel = p.get("url", "")
            info["patch"] = {
                "url": _resolve_url(latest_info.get("base_url", ""), rel),
                "rel_url": rel,
                "size": p.get("size", 0),
                "sha256": p.get("sha256", ""),
            }
            if not (rel.startswith("http://") or rel.startswith("https://")):
                info["patch_urls"] = [_resolve_url(s, rel) for s in sources]
                info["patch"]["url"] = info["patch_urls"][0]
            return info, None
        # 无对应补丁 → 退化用快照（若该版本有）
        if entry and entry.get("snapshot_url"):
            snap = entry["snapshot_url"]
            urls = [_resolve_url(s, snap) for s in sources] if not _is_abs(snap) else [snap]
            info["snapshot_url"] = urls[0]
            info["full_zip_urls"] = urls
            info["full_zip_url"] = urls[0]
            info["_mode"] = "snapshot"
            return info, None
        return None, "找不到可用的更新包"

    # 非最新版：使用全量快照（支持降级）
    if not entry:
        return None, "找不到目标版本 %s 的信息" % target_version
    snap = entry.get("snapshot_url")
    if not snap:
        return None, "版本 %s 未提供可下载的快照" % target_version
    urls = [_resolve_url(s, snap) for s in sources] if not _is_abs(snap) else [snap]
    info = {
        "version": target_version,
        "notes": entry.get("notes", ""),
        "sources": sources,
        "source": sources[0],
        "base_url": "",
        "patch": None,
        "_mode": "snapshot",
        "snapshot_url": urls[0],
        "full_zip_urls": urls,
        "full_zip_url": urls[0],
    }
    return info, None


def _is_abs(url):
    return url.startswith("http://") or url.startswith("https://")


def _find_best_patch(patches, cur):
    """找不到精确匹配时，优先选比当前版本旧的、且最接近的（best-effort）。"""
    best = None
    best_v = None
    cur_v = parse_ver(cur)
    for from_ver, p in patches.items():
        fv = parse_ver(from_ver)
        if fv >= cur_v:
            continue
        if best_v is None or fv > best_v:
            best_v = fv
            best = p
    return best


def download_update(info, dest, progress_cb=None, timeout=180):
    """按 info 下载更新包：增量补丁优先，否则完整包；失败自动切换下一个源。

    返回 (ok, err, kind)；kind ∈ {"patch", "full", ""}。
    """
    p = info.get("patch")
    if p:
        urls = info.get("patch_urls") or [p.get("url")]
        ok, err = download_file(
            urls[0], dest, timeout=timeout, progress_cb=progress_cb,
            expected_sha=p.get("sha256") or None, alt_urls=urls[1:])
        return ok, err, ("patch" if ok else "")
    urls = info.get("full_zip_urls") or ([info.get("full_zip_url")] if info.get("full_zip_url") else [])
    if not urls:
        return False, "该版本未提供任何可下载的更新包", ""
    ok, err = download_file(
        urls[0], dest, timeout=max(timeout, 600), progress_cb=progress_cb,
        alt_urls=urls[1:])
    return ok, err, ("full" if ok else "")


# ---------------------------------------------------------------------------
# 应用补丁
# ---------------------------------------------------------------------------
def _backup_file(root, rel, bak_dir):
    src = os.path.join(root, rel)
    if not os.path.isfile(src):
        return
    dst = os.path.join(bak_dir, rel)
    try:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
    except Exception as e:
        _log("备份失败 %s: %s" % (rel, e))


def _remove_with_backup(root, rel, bak_dir):
    src = os.path.join(root, rel)
    if not os.path.isfile(src):
        return
    _backup_file(root, rel, bak_dir)
    try:
        os.remove(src)
    except Exception as e:
        _log("删除失败 %s: %s" % (rel, e))


def apply_patch(root, patch_zip_path, progress_cb=None):
    """应用 patch.zip：校验并覆盖变更文件，备份旧文件，处理启动器自替换。

    返回 (ok, err, exe_staged)：
      exe_staged=True 表示补丁含新的启动器主程序，已暂存为 启动_new.exe，
      需用户在下次启动时（bootstrap）完成替换并重拉起。
    """
    try:
        zf = zipfile.ZipFile(patch_zip_path, "r")
    except Exception as e:
        return False, "补丁打开失败：%s" % e, False

    names = zf.namelist()
    # 读取元信息
    manifest = None
    meta = {}
    for n in names:
        if n == UPD_PREFIX + "manifest.json":
            try:
                manifest = json.loads(zf.read(n).decode("utf-8"))
            except Exception:
                manifest = None
        elif n == UPD_PREFIX + "meta.json":
            try:
                meta = json.loads(zf.read(n).decode("utf-8"))
            except Exception:
                meta = {}
    if not isinstance(manifest, dict):
        zf.close()
        return False, "补丁缺少有效 manifest.json", False

    old_manifest = load_local_manifest(root)
    bak_dir = os.path.join(root, BAK_DIR, current_version())
    os.makedirs(bak_dir, exist_ok=True)

    # 提取到临时目录，再逐文件校验+覆盖
    import tempfile
    tmpd = tempfile.mkdtemp(prefix="xiao_upd_")
    try:
        zf.extractall(tmpd)
        zf.close()

        total = sum(1 for n in names if not n.startswith(UPD_PREFIX))
        done = 0
        exe_staged = False
        for n in names:
            if n.startswith(UPD_PREFIX):
                continue
            rel = n.replace("\\", "/")
            done += 1
            if progress_cb:
                try:
                    progress_cb(done, total, "应用文件 %s" % rel)
                except Exception:
                    pass
            exp = manifest.get(rel)
            if not exp:
                continue  # 清单里没有的新文件不落地（理论不该发生）
            src = os.path.join(tmpd, n)
            if not os.path.isfile(src):
                continue
            actual = file_sha256(src)
            if actual != exp.get("sha256"):
                return False, "文件校验失败：%s" % rel, False
            # 启动器主程序无法运行时覆盖 → 暂存
            if rel == EXE_NAME:
                dst = os.path.join(root, EXE_STAGE)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
                exe_staged = True
                continue
            if is_excluded(rel):
                continue
            _backup_file(root, rel, bak_dir)
            dst = os.path.join(root, rel)
            os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
            shutil.copy2(src, dst)

        # 删除在旧版存在、新版已移除的文件
        deleted = meta.get("deleted", []) or []
        for rel in deleted:
            rel = rel.replace("\\", "/")
            if is_excluded(rel):
                continue
            _remove_with_backup(root, rel, bak_dir)

        save_local_manifest(root, manifest)
        return True, None, exe_staged
    except Exception as e:
        return False, "应用补丁异常：%s" % e, False
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)


def apply_full_zip(root, zip_path, progress_cb=None):
    """回退方案：下载完整包 zip 并覆盖（排除用户数据）。返回 (ok, err, exe_staged)。"""
    try:
        zf = zipfile.ZipFile(zip_path, "r")
    except Exception as e:
        return False, "完整包打开失败：%s" % e, False
    names = zf.namelist()
    total = sum(1 for n in names if not (n.startswith(UPD_PREFIX) or is_excluded(n.replace("\\", "/"))))
    done = 0
    exe_staged = False
    try:
        for n in names:
            rel = n.replace("\\", "/")
            if n.startswith(UPD_PREFIX):
                continue
            if is_excluded(rel):
                continue
            done += 1
            if progress_cb:
                try:
                    progress_cb(done, total, "解压 %s" % rel)
                except Exception:
                    pass
            if rel == EXE_NAME:
                dst = os.path.join(root, EXE_STAGE)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with zf.open(n) as src, open(dst, "wb") as out:
                    shutil.copyfileobj(src, out)
                exe_staged = True
                continue
            dst = os.path.join(root, rel)
            os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
            with zf.open(n) as src, open(dst, "wb") as out:
                shutil.copyfileobj(src, out)
        # 完整包/快照内若含清单：先删「当前有、目标无」的启动器文件（支持降级/跨版本清理），
        # 但绝不动 ComfyUI/（其由用户自行管理，误删代价极高）；再合并保存新清单。
        try:
            if (UPD_PREFIX + "manifest.json") in names:
                new_manifest = json.loads(zf.read(UPD_PREFIX + "manifest.json").decode("utf-8"))
                if isinstance(new_manifest, dict):
                    cur_manifest = load_local_manifest(root) or {}
                    bak_dir = os.path.join(root, BAK_DIR, current_version())
                    # 仅删除启动器作用域内、目标快照里已不存在的文件（保留 ComfyUI / 用户数据）
                    for rel in list(cur_manifest.keys()):
                        if rel.startswith("ComfyUI/"):
                            continue
                        if rel not in new_manifest and not is_excluded(rel):
                            _remove_with_backup(root, rel, bak_dir)
                    # 合并清单：保留 ComfyUI 等条目，仅以快照作用域覆盖/清理启动器文件
                    for rel in list(cur_manifest.keys()):
                        if rel.startswith("ComfyUI/"):
                            continue
                        if rel not in new_manifest:
                            cur_manifest.pop(rel, None)
                        else:
                            cur_manifest[rel] = new_manifest[rel]
                    for rel, meta in new_manifest.items():
                        if not rel.startswith("ComfyUI/"):
                            cur_manifest[rel] = meta
                    save_local_manifest(root, cur_manifest)
        except Exception:
            pass
        return True, None, exe_staged
    except Exception as e:
        return False, "解压完整包异常：%s" % e, False
    finally:
        zf.close()


# ---------------------------------------------------------------------------
# 启动器主程序自替换（由 bootstrap 在启动最早期调用）
# ---------------------------------------------------------------------------
def maybe_swap_exe(root):
    """若上次更新暂存了 启动_new.exe，则替换 启动.exe 并重拉起启动器。

    返回 True 表示已执行替换并应退出当前进程（让新启动器接管）。
    """
    new = os.path.join(root, EXE_STAGE)
    if not os.path.isfile(new):
        return False
    exe = os.path.join(root, EXE_NAME)
    old = os.path.join(root, "启动_old.exe")
    try:
        if os.path.isfile(exe):
            if os.path.isfile(old):
                try:
                    os.remove(old)
                except Exception:
                    pass
            os.rename(exe, old)
        os.rename(new, exe)
    except Exception as e:
        _log("启动器替换失败：%s" % e)
        return False
    try:
        flags = getattr(subprocess_module(), "CREATE_NEW_PROCESS_GROUP", 0) | \
                getattr(subprocess_module(), "DETACHED_PROCESS", 0)
        import subprocess as _sp
        _sp.Popen([exe], close_fds=True, creationflags=flags)
    except Exception:
        try:
            import subprocess as _sp
            _sp.Popen([exe])
        except Exception:
            pass
    return True


def subprocess_module():
    import subprocess
    return subprocess


# ---------------------------------------------------------------------------
# 回滚
# ---------------------------------------------------------------------------
def rollback(root):
    """回滚到最近一次备份（.update_bak/<版本>/）。返回 (ok, msg)。"""
    bak_root = os.path.join(root, BAK_DIR)
    if not os.path.isdir(bak_root):
        return False, "没有可回滚的备份"
    versions = sorted(
        [d for d in os.listdir(bak_root) if os.path.isdir(os.path.join(bak_root, d))],
        reverse=True,
    )
    if not versions:
        return False, "没有可回滚的备份"
    ver = versions[0]
    bak_dir = os.path.join(bak_root, ver)
    count = 0
    for dirpath, _, filenames in os.walk(bak_dir):
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, bak_dir).replace(os.sep, "/")
            dst = os.path.join(root, rel)
            try:
                os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
                shutil.copy2(full, dst)
                count += 1
            except Exception:
                pass
    return True, "已回滚 %d 个文件（来源备份版本 %s）" % (count, ver)


if __name__ == "__main__":
    # 简单自测：打印当前版本与本地清单规模
    print("当前版本：", current_version())
    m = load_local_manifest(PKG_ROOT)
    print("本地清单文件数：", len(m) if m else "无（首次运行）")
