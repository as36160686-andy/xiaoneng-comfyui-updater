# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · 配置模块。

所有路径均从本文件位置推导，保证包整体移动后仍正确：
    app/config.py  ->  _PKG_ROOT = 包根（与 ComfyUI/ 平级）
"""
import os
import json

APP_DIR = os.path.dirname(os.path.abspath(__file__))          # 包/app
_PKG_ROOT = os.path.dirname(APP_DIR)                          # 包根目录

COMFY_DIR = os.path.join(_PKG_ROOT, "ComfyUI")
COMFY_URL = "http://127.0.0.1:8190"

# 默认模型根目录
MODEL_DIR_DEFAULT = os.path.join(COMFY_DIR, "models")

# 默认工作流目录
WORKFLOW_DIR = os.path.join(COMFY_DIR, "user", "default", "workflows")

# 默认插件（自定义节点）目录
PLUGIN_DIR_DEFAULT = os.path.join(COMFY_DIR, "custom_nodes")

# 用户设置持久化位置（与 bootstrap.py 读取的 settings.json 为同一文件）
SETTINGS_PATH = os.path.join(_PKG_ROOT, "settings.json")

# 自更新：latest.json 所在的基础地址（末尾带不带斜杠均可）。
# 【支持多个源，按顺序尝试，前一个挂了自动用下一个——用于 GitHub 仓库 + 网盘双备份】
# 例如 GitHub Pages：「https://<user>.github.io/<repo>/dist」
# 或任意静态托管/网盘直链：「https://你的域名/小能更新/dist」
# 留空则关闭自动更新检查（用户可在「关于」里自行填写，用户配置优先于此处）。
UPDATE_BASE_URL = ""

# 内置默认更新源（打包分发时可预置；用户未配置时使用）。
# 例：UPDATE_BASE_URLS = [
#     "https://<user>.github.io/<repo>/dist",
#     "https://pan.xxx.com/s/xxxx/dist",
# ]
# 已预置 GitHub Pages 托管源（小能ComfyUI启动器 自动更新仓库）：
UPDATE_BASE_URLS = [
    "https://as36160686-andy.github.io/xiaoneng-comfyui-updater",
]

# 启动器版本号（显示在「关于」对话框）。
# 递增规则：每次更新最后一位 +1；当小版本到 9 再进位（如 v1.9.9 -> v2.0.0）。
APP_VERSION = "v1.0.7"


def bump_version(current=APP_VERSION):
    """按规则递增版本号。默认递增当前 APP_VERSION 并写回本常量（调用后需重新导入）。"""
    # 去掉前导 v
    s = current.lstrip("vV")
    parts = s.split(".")
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        raise ValueError("版本号格式必须是 vX.Y.Z：%s" % current)
    major, minor, patch = map(int, parts)
    patch += 1
    if patch > 9:
        patch = 0
        minor += 1
    if minor > 9:
        minor = 0
        major += 1
    return "v%d.%d.%d" % (major, minor, patch)


# Git 境内外镜像（仅作用于包内 PortableGit 拉取）
GIT_MIRRORS = {
    "china": {
        "name": "中国镜像 (ghfast.top)",
        "base": "https://ghfast.top/https://github.com/",
    },
    "foreign": {
        "name": "境外官方 (github.com)",
        "base": "https://github.com",
    },
}

# HuggingFace 境内外镜像
HF_MIRRORS = {
    "china": {
        "name": "中国镜像 (hf-mirror.com)",
        "endpoint": "https://hf-mirror.com",
    },
    "foreign": {
        "name": "境外官方 (huggingface.co)",
        "endpoint": "https://huggingface.co",
    },
}


def _default_settings():
    return {
        "comfy_url": COMFY_URL,
        "model_dir": MODEL_DIR_DEFAULT,
        "workflow_dir": WORKFLOW_DIR,
        "plugin_dir": PLUGIN_DIR_DEFAULT,
        "extra_args": "",
        "git_mirror": "china",
        "hf_mirror": "china",
        "check_plugin_deps": True,
        "update_url": UPDATE_BASE_URL,
    }


def load_settings():
    """读取 settings.json，缺字段用默认值补齐。"""
    try:
        if not os.path.isfile(SETTINGS_PATH):
            return _default_settings()
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return _default_settings()
    except Exception:
        return _default_settings()
    base = _default_settings()
    base.update(data)
    return base


def save_settings(s):
    """原子式写回 settings.json。"""
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        tmp = SETTINGS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
        os.replace(tmp, SETTINGS_PATH)
        return True
    except Exception:
        return False


# ---- ComfyUI 地址 ----
def get_comfy_url():
    return load_settings().get("comfy_url") or COMFY_URL


def set_comfy_url(url):
    s = load_settings()
    s["comfy_url"] = url or COMFY_URL
    save_settings(s)


# ---- 模型根目录 ----
def get_model_dir():
    """返回用户设置的模型根目录；未设置返回默认 ComfyUI/models。"""
    return load_settings().get("model_dir", "") or MODEL_DIR_DEFAULT


def set_model_dir(path):
    """设置并持久化模型根目录。"""
    if path:
        path = os.path.normpath(path)
    s = load_settings()
    s["model_dir"] = path or ""
    save_settings(s)
    return path or ""


# ---- 工作流目录（固定为包内默认，不做目录映射）----
def get_workflow_dir():
    """始终返回包内默认工作流目录。

    历史版本支持自定义外部目录并在包内建目录联接(junction)做映射，
    该机制会导致「复制替换包内插件」时实际写到外部目录、被其他
    ComfyUI 进程占用而失败，现已移除：工作流固定在包内。
    """
    return WORKFLOW_DIR


def set_workflow_dir(path):
    """已废弃：工作流目录固定为包内默认，此接口保留仅为兼容旧调用。"""
    return WORKFLOW_DIR


# ---- 插件（自定义节点）目录（固定为包内默认，不做目录映射）----
def get_plugin_dir():
    """始终返回包内默认插件目录 ComfyUI/custom_nodes（真实目录，非联接）。"""
    return PLUGIN_DIR_DEFAULT


def set_plugin_dir(path):
    """已废弃：插件目录固定为包内默认，此接口保留仅为兼容旧调用。"""
    return PLUGIN_DIR_DEFAULT


def reset_internal_dirs():
    """把 settings.json 里的 workflow_dir / plugin_dir 强制写回包内默认值。

    用于升级旧配置（此前可能保存了外部目录）。返回是否发生了改动。
    """
    s = load_settings()
    changed = False
    if s.get("workflow_dir") != WORKFLOW_DIR:
        s["workflow_dir"] = WORKFLOW_DIR
        changed = True
    if s.get("plugin_dir") != PLUGIN_DIR_DEFAULT:
        s["plugin_dir"] = PLUGIN_DIR_DEFAULT
        changed = True
    if changed:
        save_settings(s)
    return changed


# ---- 额外启动参数 ----
def get_extra_args():
    return load_settings().get("extra_args", "") or ""


def set_extra_args(v):
    s = load_settings()
    s["extra_args"] = (v or "").strip()
    save_settings(s)


# ---- 启动检查插件依赖注册 ----
def get_check_plugin_deps():
    """是否在启动服务前检查并注册（安装）插件依赖。默认开启。"""
    v = load_settings().get("check_plugin_deps", True)
    return True if v is None else bool(v)


def set_check_plugin_deps(v):
    s = load_settings()
    s["check_plugin_deps"] = bool(v)
    save_settings(s)


# ---- Git 镜像 ----
def get_git_mirror():
    key = load_settings().get("git_mirror", "china")
    return key if key in GIT_MIRRORS else "china"


def set_git_mirror(key):
    if key not in GIT_MIRRORS:
        key = "china"
    s = load_settings()
    s["git_mirror"] = key
    save_settings(s)


# ---- HuggingFace 镜像 ----
def get_hf_mirror():
    key = load_settings().get("hf_mirror", "china")
    return key if key in HF_MIRRORS else "china"


def set_hf_mirror(key):
    if key not in HF_MIRRORS:
        key = "china"
    s = load_settings()
    s["hf_mirror"] = key
    save_settings(s)


# ---- 自更新地址（支持多源，按顺序尝试，互为备份）----
def _clean_urls(urls):
    """清洗地址列表：去空白、去尾部斜杠、去重且保序。"""
    out = []
    for u in urls or []:
        if not isinstance(u, str):
            continue
        u = u.strip().strip('"').strip("'").rstrip("/")
        if not u:
            continue
        if u not in out:
            out.append(u)
    return out


def get_update_urls():
    """返回更新源地址列表（按优先级）。用户配置优先，其次内置默认源。

    兼容旧的单个 update_url 键：若存在则放在最前面。
    """
    s = load_settings()
    urls = s.get("update_urls")
    if not isinstance(urls, list):
        urls = []
    legacy = s.get("update_url", "") or ""
    merged = _clean_urls([legacy] + list(urls))
    if merged:
        return merged
    return _clean_urls(UPDATE_BASE_URLS)


def set_update_urls(urls):
    """保存更新源列表；同时清掉旧的单地址键，避免重复。"""
    if isinstance(urls, str):
        urls = [urls]
    s = load_settings()
    s["update_urls"] = _clean_urls(urls)
    s.pop("update_url", None)
    save_settings(s)


def get_update_url():
    """返回首个（优先级最高的）更新地址；空串表示关闭自动更新。向后兼容。"""
    urls = get_update_urls()
    return urls[0] if urls else ""


def set_update_url(url):
    """仅设置单个更新地址（向后兼容）。"""
    set_update_urls([url] if url else [])
