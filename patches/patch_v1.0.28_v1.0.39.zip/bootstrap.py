# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · 首次启动准备（由 启动.bat 调用）。

职责（每次启动都会跑，幂等）：
  1. 把包内 ComfyUI/.venv/pyvenv.cfg 的「home」修正为当前绝对路径
     （指向 包/ComfyUI/standalone-env），使 venv 随包移动到任意位置都能用。
  2. 确保 PySide6 已装进 venv（UI 依赖）；没有就 pip 安装。
  3. 检查模型是否就位（按 models_manifest.json）；缺失则给出清晰提示/尝试下载。
  4. 启动 UI（ui_pyside.py）。
"""
import os
import sys
import subprocess
import json
import shutil
import time
import socket
import glob
import zipfile
import ctypes


# 包根目录。PyInstaller onefile 打包后 __file__ 指向临时解压目录，
# 必须用 sys.executable（指向真实 exe 路径）推算；以脚本方式直接运行
# （如 启动.bat 调 pythonw bootstrap.py）时回退 __file__。
if getattr(sys, "frozen", False):
    BASE = os.path.dirname(os.path.abspath(sys.executable))
else:
    BASE = os.path.dirname(os.path.abspath(__file__))
COMFY = os.path.join(BASE, "ComfyUI")
VENV_PY = os.path.join(COMFY, ".venv", "Scripts", "python.exe")
# 优先用 pythonw（无控制台窗口）启动 UI；找不到时回退 python.exe
VENV_PYW = os.path.join(COMFY, ".venv", "Scripts", "pythonw.exe")
VENV_UI = VENV_PYW if os.path.isfile(VENV_PYW) else VENV_PY
BASE_PY = os.path.join(BASE, "standalone-env", "python.exe")
BASE_PYW = os.path.join(COMFY, "standalone-env", "pythonw.exe")
BASE_UI = BASE_PYW if os.path.isfile(BASE_PYW) else BASE_PY
APP_DIR = os.path.join(BASE, "app")
MODELS_DIR = os.path.join(BASE, "models")                   # 包内模型根（与 extra_model_paths.yaml 对应）
MANIFEST = os.path.join(BASE, "models_manifest.json")
EXTRA_YAML = os.path.join(COMFY, "extra_model_paths.yaml")


def get_user_model_dir():
    """读取用户在 settings.json 中设置的模型根目录；未设置返回空串。"""
    try:
        if APP_DIR not in sys.path:
            sys.path.insert(0, APP_DIR)
        import config
    except Exception:
        return ""
    try:
        return config.get_model_dir()
    except Exception:
        return ""


def sync_extra_model_paths(model_dir):
    """把 extra_model_paths.yaml 的 base_path 改成用户指定的模型根目录。

    模型不再随包捆绑，用户在 UI 设置里手动选择含
    diffusion_models/text_encoders/loras/vae 子目录的目录（如 D:/models），
    本函数原地改写 ComfyUI 的 extra_model_paths.yaml 的 base_path 行。
    幂等：仅当确有变化时写文件。返回是否成功改写。
    """
    if not model_dir or not os.path.isdir(model_dir):
        _log(f"模型目录无效，跳过 extra_model_paths 同步：{model_dir}")
        return False
    if not os.path.isfile(EXTRA_YAML):
        _log("（无 extra_model_paths.yaml，跳过模型路径同步）")
        return False
    try:
        with open(EXTRA_YAML, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception as e:
        _log(f"读取 extra_model_paths.yaml 失败：{e}")
        return False
    norm = os.path.normpath(model_dir).replace("/", "\\")
    new_lines = []
    changed = False
    for ln in lines:
        stripped = ln.strip()
        if stripped.startswith("base_path"):
            indent = ln[:len(ln) - len(ln.lstrip())]
            new = f"{indent}base_path: {norm}\n"
            if ln.rstrip("\n") != new.rstrip("\n"):
                changed = True
            new_lines.append(new)
        else:
            new_lines.append(ln)
    if changed:
        try:
            with open(EXTRA_YAML, "w", encoding="utf-8") as f:
                f.writelines(new_lines)
            _log(f"已把模型根目录写入 ComfyUI -> {norm}")
        except Exception as e:
            _log(f"写入 extra_model_paths.yaml 失败：{e}")
            return False
    else:
        _log("模型根目录已就位")
    return True


_BOOT_T0 = time.time()


def _log(msg):
    """输出日志，带「相对进程启动的秒数」，便于定位启动各阶段耗时。"""
    print("[bootstrap +%6.2fs] %s" % (time.time() - _BOOT_T0, msg))


def ensure_pythonw():
    """venv 的 pythonw.exe 缺失时，自动从包内 standalone-env 补回。

    否则 bootstrap 会回退到控制台版 python.exe 启动 UI / 停止进程，导致启动器在
    一个黑控制台窗口后运行（误关黑窗会连带杀掉整个启动器；关闭时也会弹黑窗）。
    该 venv 由 standalone-env 创建（见 .venv/pyvenv.cfg 的 home），两者 Python
    版本一致，直接复制即可，无需重装环境。
    """
    if os.path.isfile(VENV_PYW):
        return
    # 1) 首选：包内随附的 standalone-env/pythonw.exe
    src = os.path.join(BASE, "standalone-env", "pythonw.exe")
    # 2) 备选：pyvenv.cfg 里记录的 home（venv 原始基解释器所在目录）
    if not os.path.isfile(src):
        try:
            cfg = os.path.join(COMFY, ".venv", "pyvenv.cfg")
            if os.path.isfile(cfg):
                with open(cfg, "r", encoding="utf-8") as _fh:
                    for _line in _fh:
                        if _line.lower().startswith("home"):
                            _home = _line.split("=", 1)[1].strip().strip('"')
                            _cand = os.path.join(_home, "pythonw.exe")
                            if os.path.isfile(_cand):
                                src = _cand
                                break
        except Exception:
            pass
    if os.path.isfile(src):
        try:
            shutil.copyfile(src, VENV_PYW)
            _log("已自动补回缺失的 pythonw.exe（来源：%s）" % src)
        except Exception as e:
            _log("pythonw 自修复失败：%s" % e)
    else:
        _log("警告：未找到 pythonw.exe 来源（standalone-env 与 pyvenv.cfg 均无），"
             "将回退控制台 python.exe，启动器可能带黑窗。")


def ensure_venv_dlls():
    """把 venv 运行所需的 CPython 运行库 DLL 从包内 standalone-env 补到 venv/Scripts。

    根因修复（2026-09-12）：venv/Scripts 默认没有 python313.dll / python3.dll /
    vcruntime140.dll / vcruntime140_1.dll，venv 的 pythonw.exe 启动时会到 PATH 上
    找这些 DLL；若 bootstrap 把 standalone-env 从 PATH 剔除，pythonw 会退化去加载
    冻结启动器自身 _MEI 里的 python313.dll——其初始化会把 _MEI/python313.zip 注入
    sys.path 并与 venv 的 PySide6 ABI 不兼容，导致 import PySide6 时
    "DLL load failed while importing Shiboken" → 启动器一闪而退。
    把这些 DLL 直接放到 pythonw.exe 同目录，Windows 加载器优先用本地副本，
    彻底避免误加载冻结 DLL。随附包已带 standalone-env，拷贝到任何机器都能自愈。
    """
    dlls = ["python313.dll", "python3.dll", "vcruntime140.dll", "vcruntime140_1.dll"]
    src_dir = os.path.join(BASE, "standalone-env")
    dst_dir = os.path.join(COMFY, ".venv", "Scripts")
    if not os.path.isdir(dst_dir):
        return
    copied = []
    for _d in dlls:
        _src = os.path.join(src_dir, _d)
        _dst = os.path.join(dst_dir, _d)
        if not os.path.isfile(_dst) and os.path.isfile(_src):
            try:
                shutil.copyfile(_src, _dst)
                copied.append(_d)
            except Exception as e:
                _log("venv DLL 自修复失败 %s：%s" % (_d, e))
    if copied:
        _log("已自动补回 venv 运行库 DLL：%s" % ", ".join(copied))


def _redirect_logs():
    """把 stdout/stderr 重定向到包内 launch_log.txt。

    冻结（PyInstaller noconsole）后无论 sys.stdout 是否为 None 都强制落盘，
    确保即使启动器「闪退」也有完整日志可供排查；手动运行 启动.bat（python.exe
    有真实控制台）时保留原样，方便看实时日志。
    """
    if (not getattr(sys, "frozen", False)) and sys.stdout is not None:
        return
    try:
        log_path = os.path.join(BASE, "launch_log.txt")
        f = open(log_path, "w", encoding="utf-8", buffering=1)
        sys.stdout = f
        sys.stderr = f
    except Exception:
        pass


def fix_venv_home():
    """把 .venv/pyvenv.cfg 的 home 改成当前 standalone-env 绝对路径（幂等）。

    若 pyvenv.cfg 不存在（例如移动/复制后小文件丢失），自动重建，避免 venv 启动器
    报 "failed to locate pyvenv.cfg" 而退出。
    """
    cfg = os.path.join(COMFY, ".venv", "pyvenv.cfg")
    target = os.path.join(os.path.dirname(COMFY), "standalone-env")
    norm = os.path.normpath(target).replace("/", "\\")

    if not os.path.isfile(cfg):
        _log(f"未找到 {cfg}，自动重建 pyvenv.cfg")
        try:
            with open(cfg, "w", encoding="utf-8") as f:
                f.write(f"home = {norm}\n")
                f.write("include-system-site-packages = false\n")
                f.write("version = 3.13.12\n")
                f.write(f"executable = {norm}\\python.exe\n")
                f.write(f"command = {norm}\\python.exe -m venv {os.path.dirname(cfg)}\n")
            _log(f"已重建 pyvenv.cfg，home -> {norm}")
        except Exception as e:
            _log(f"重建 pyvenv.cfg 失败：{e}")
            return

    with open(cfg, "r", encoding="utf-8") as f:
        lines = f.readlines()
    # venv 的 home 必须指向 standalone-env 目录本身（其顶层含 python.exe），
    # 它位于 包/standalone-env（与 ComfyUI/ 平级）。
    target = os.path.join(os.path.dirname(COMFY), "standalone-env")
    norm = os.path.normpath(target).replace("/", "\\")
    new_lines = []
    changed = False
    for ln in lines:
        s = ln.strip()
        if s.startswith("home") or s.startswith("executable") or s.startswith("command"):
            if s.startswith("home"):
                newv = f"home = {norm}\n"
            elif s.startswith("executable"):
                newv = f"executable = {norm}\\python.exe\n"
            else:
                newv = f"command = {norm}\\python.exe -m venv {os.path.dirname(cfg)}\n"
            if s != newv.strip():
                changed = True
            new_lines.append(newv)
        else:
            new_lines.append(ln)
    if changed:
        with open(cfg, "w", encoding="utf-8") as f:
            f.writelines(new_lines)
        _log(f"已修正 venv 路径 -> {norm}")


# pytorch CUDA 构建的专用索引（锁定官方 cu126 构建，匹配本机 RTX 4070 驱动；
# 版本号与 ComfyUI 自带的 comfy_kitchen 0.2.31 兼容：需 torch >= 2.7 以支持
# `float | None` 类型注解。严禁写不存在的 cu130 / 任意非官方 CUDA 标签）。
TORCH_INDEX = "https://download.pytorch.org/whl/cu126"
TORCH_PIN = ["torch==2.11.0+cu126", "torchvision==0.26.0+cu126", "torchaudio==2.11.0+cu126"]


def _find_links():
    """返回 pip 的 --find-links 参数（指向包内 _pip_whl 离线 wheel 缓存）。"""
    whl = os.path.join(BASE, "_pip_whl")
    return ["-f", whl] if os.path.isdir(whl) else []


def _venv_quick_check():
    """文件级健康检查（快，无需导入 torch）：扫描每个 .dist-info 的 top_level.txt，
    确认其中声明的顶层可导入模块（包目录/单文件模块）确实存在于 site-packages。
    任一缺失即认为环境损坏（转移撕裂会删除源码目录但保留 dist-info）。
    返回 (ok: bool, detail: str)。
    """
    import importlib

    site = os.path.join(COMFY, ".venv", "Lib", "site-packages")
    if not os.path.isdir(site):
        return False, "site-packages 不存在"
    missing = []
    try:
        for d in os.listdir(site):
            if not d.endswith(".dist-info"):
                continue
            tl = os.path.join(site, d, "top_level.txt")
            if not os.path.isfile(tl):
                continue
            with open(tl, "r", encoding="utf-8", errors="replace") as f:
                for name in f.read().splitlines():
                    name = name.strip()
                    # 跳过含路径分隔符的条目（非顶层模块，无法用简单目录存在性判断）
                    if not name or "/" in name or "\\" in name:
                        continue
                    # 若该条目是已知 PySide6 的命名不一致项，直接跳过（不破坏健康判定）
                    if name in ("Shiboken",):
                        continue
                    # 候选名集合：原始名 + 大小写变体 + 数字后缀 + 去下划线前缀变体
                    # （很多 wheel 的 top_level.txt 写的是私有实现模块名，如
                    #  _cffi_backend / _brotli / _xxhash，实际文件是 .pyd 或入口名不同）
                    candidates = {name, name.lower(), name.capitalize()}
                    for base in list(candidates):
                        if base.startswith("_"):
                            candidates.add(base[1:])          # _brotli -> brotli
                        if not base[-1:].isdigit():
                            candidates.add(base + "6")        # 常见数字后缀兜底
                    exts = (".py", ".pyd")
                    found = False
                    site_entries = os.listdir(site)  # 用于匹配带 ABI 标签后缀的 .pyd
                    for c in candidates:
                        p = os.path.join(site, c)
                        if os.path.isdir(p):
                            found = True
                            break
                        # 精确匹配 .py / .pyd
                        if any(os.path.isfile(p + e) for e in exts):
                            found = True
                            break
                        # 带 ABI 标签后缀的 C 扩展（如 ahocorasick.cp313-win_amd64.pyd）
                        if any(f.startswith(c + ".") and f.endswith(".pyd")
                               for f in site_entries):
                            found = True
                            break
                    # 文件级查不到时，用真实导入做最终裁决（避免误报）
                    if not found:
                        try:
                            importlib.import_module(name)
                            found = True
                        except Exception:
                            pass
                    # 仍失败：某些 C 扩展是子包私有模块（如 PyNaCl 的 _sodium
                    # 实际位于 nacl/_sodium.pyd，top_level.txt 却写了 _sodium）。
                    # 在一级子目录内再扫描带 ABI 标签的 .pyd。
                    if not found:
                        for sub in site_entries:
                            sub_path = os.path.join(site, sub)
                            if not os.path.isdir(sub_path):
                                continue
                            try:
                                sub_files = os.listdir(sub_path)
                            except Exception:
                                continue
                            if any(f == name + ".pyd" or
                                   (f.startswith(name + ".") and f.endswith(".pyd"))
                                   for f in sub_files):
                                found = True
                                break
                    if found:
                        continue
                    missing.append(name)
                    if len(missing) >= 8:
                        break
            if len(missing) >= 8:
                break
    except Exception as e:
        return False, "scan-error:" + repr(e)
    if missing:
        return False, "缺失顶层模块示例: " + ", ".join(missing[:8])
    return True, "OK"


def _port_in_use(port=8190):
    """检测本机端口是否被占用（避免重建时 .venv 被正在运行的 ComfyUI 锁定）。"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        res = s.connect_ex(("127.0.0.1", port))
        s.close()
        return res == 0
    except Exception:
        return False


def _kill_comfy_processes():
    """终止所有属于本包的 python 进程（路径在 BASE 下），不含本进程。"""
    try:
        pat = os.path.normpath(BASE).replace("/", "\\") + "\\*\\python*.exe"
        ps = (
            "Get-CimInstance Win32_Process | "
            "Where-Object { ($_.ExecutablePath -like '%s') -and ($_.ProcessId -ne %d) } | "
            "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
            % (pat, os.getpid())
        )
        subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=30,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0)
        return True
    except Exception as e:
        _log(f"终止旧进程失败：{e}")
        return False


def _confirm_rebuild():
    """弹窗询问是否由启动器自动关闭旧 ComfyUI 并重建环境。返回 True=确定。"""
    try:
        import ctypes
        res = ctypes.windll.user32.MessageBoxW(
            0,
            "检测到上次的 ComfyUI 仍在运行（占用 8190 端口），\n"
            "且其 Python 环境已损坏、需要重建。\n\n"
            "点击【确定】将由启动器自动关闭旧进程并重建环境；\n"
            "点击【取消】则退出，请手动关闭 ComfyUI 后重试。",
            "小能ComfyUI启动器", 0x21)  # MB_ICONQUESTION | MB_YESNO
        return res == 6  # IDYES
    except Exception:
        return True  # 无桌面环境时默认继续


# 单实例锁：防止重复双击启动器导致两个 bootstrap 并发重建 .venv（会互相破坏环境）
_LAUNCHER_MUTEX = None


def _acquire_single_instance():
    """用 Windows 命名互斥量保证启动器全局单实例。返回 False 表示已有实例在运行。

    关键修复：必须用 ``use_last_error=True`` 创建 kernel32 句柄，并配合
    ``ctypes.get_last_error()`` 读取结果；**不能**调用 ``kernel32.GetLastError()``——
    后者本身是一次外部调用，在 Python 3.13 下其返回值会在 ctypes 处理上一次
    调用的返回值时被覆盖，导致第二次启动误判为「无实例」而放行
    （这正是此前能打开多个启动器的根因）。
    """
    global _LAUNCHER_MUTEX
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.argtypes = [
            ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        kernel32.CreateMutexW.restype = ctypes.c_void_p
        mutex = kernel32.CreateMutexW(
            None, False, "Global\\XiaoNengComfyUILauncher")
        last_err = ctypes.get_last_error()
        if last_err == 183:  # ERROR_ALREADY_EXISTS
            _LAUNCHER_MUTEX = None
            return False
        _LAUNCHER_MUTEX = mutex
        return True
    except Exception:
        # 拿不到互斥量时默认放行（避免在无 API 环境卡死）
        return True


def _show_rebuild_notice():
    """重建期间弹出一个提示框（非阻塞：另起子进程显示，不阻塞主线程重建）。

    因启动器用 pythonw 无控制台窗口，重建过程（装 torch 等约几分钟）全程不可见，
    用户容易误以为「打不开」而重复双击 → 触发并发重建冲突。此提示框明确告知进度。
    """
    try:
        code = (
            'import ctypes;'
            'ctypes.windll.user32.MessageBoxW(0,'
            '"正在自动修复 Python 环境（首次较慢，约需几分钟），\\n'
            '请勿关闭此提示或重复双击启动器。\\n完成后会自动打开主界面。",'
            '"小能ComfyUI启动器", 0x40)'
        )
        subprocess.Popen([BASE_PY, "-c", code],
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0)
    except Exception:
        pass


def rebuild_venv():
    """用 base python 彻底重建 .venv（在 ComfyUI 启动之前调用，此时 venv 未被占用）。

    采用「干净重建」：删除整个 venv 后，按 ComfyUI 官方 requirements.txt + 精确锁定的
    torch cu130 构建 + 各插件 requirements.txt 重新安装，得到一致、可工作的环境，
    避免保留之前因文件夹错误移动而留下的重复/冲突版本（如多个 transformers）。
    """
    venv_dir = os.path.join(COMFY, ".venv")
    base_py = os.path.join(BASE, "standalone-env", "python.exe")
    if not os.path.isfile(base_py):
        _log(f"[错误] 找不到便携式 Python：{base_py}")
        return False
    # 端口被占用说明旧 ComfyUI 仍存活 -> 不能重建（文件被锁）
    if _port_in_use(8190):
        _log("⚠ 端口 8190 仍被占用，无法重建 .venv，请先关闭旧 ComfyUI。")
        return False
    _log("环境健康检查未通过，正在自动重建 .venv（首次较慢，请耐心等待）…")
    _show_rebuild_notice()
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    if os.path.isdir(venv_dir):
        shutil.rmtree(venv_dir, ignore_errors=True)
    if os.path.isdir(venv_dir):
        _log("⚠ 旧 .venv 删除失败（可能被占用），请完全关闭 ComfyUI 后重试。")
        return False
    # 1. 创建 venv（用 base python）
    subprocess.run([base_py, "-m", "venv", venv_dir], check=True, creationflags=flags)
    vpy = VENV_PY
    # 2. 升级 pip（非致命：venv 自带 pip 通常已够用；离线/受限网络升级失败不应阻断重建）
    try:
        subprocess.run([vpy, "-m", "pip", "install", "--upgrade", "pip"],
                       check=True, capture_output=True, creationflags=flags, timeout=180)
    except Exception as e:
        _log(f"[提示] pip 升级跳过（不影响安装）：{str(e)[:120]}")
    # 3. 安装 torch CUDA 构建（精确锁定当前能用的 cu130 版本，避免装到不同 CUDA 构建）
    _log("安装 torch (cu130) …")
    subprocess.run([vpy, "-m", "pip", "install"] + TORCH_PIN +
                   ["--extra-index-url", TORCH_INDEX] + _find_links(),
                   check=True, creationflags=flags)
    # 4. ComfyUI 核心依赖（transformers / tokenizers 等由 requirements.txt 统一解析，保证一致）
    req = os.path.join(COMFY, "requirements.txt")
    if os.path.isfile(req):
        _log("安装 ComfyUI 核心依赖 …")
        subprocess.run([vpy, "-m", "pip", "install"] + _find_links() + ["-r", req],
                       check=True, creationflags=flags)
    else:
        _log("[警告] 找不到 ComfyUI/requirements.txt，跳过核心依赖。")
    # 5. 各插件依赖
    #    重要：逐行安装（而非整文件 -r），因为某些插件依赖可能包含「可选但无法从
    #    源码构建」的包（如 cupy-wheel 在 cp313 下需构建却缺 pkg_resources）。
    #    整文件 -r 会在任一包失败时整体回滚，导致该文件内其它正常依赖（einops/kornia
    #    等）也装不上。逐行安装可让坏包单独失败、好包照常装上，与当前「无 cupy 也能跑」
    #    的环境表现一致。
    cn = os.path.join(COMFY, "custom_nodes")
    if os.path.isdir(cn):
        for d in sorted(os.listdir(cn)):
            rfile = os.path.join(cn, d, "requirements.txt")
            if not os.path.isfile(rfile):
                continue
            _log(f"安装插件依赖：{d}")
            try:
                with open(rfile, "r", encoding="utf-8", errors="replace") as f:
                    lines = f.readlines()
            except Exception:
                lines = []
            for raw in lines:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                # 去掉行内注释（如 "x-transformers>=2.0.0  # Transformer 扩展"），
                # 否则整行传给 pip 解析失败被跳过，导致该依赖漏装。
                if " #" in line:
                    line = line.split(" #", 1)[0].strip()
                if not line:
                    continue
                # 跳过 -r / -e 等子文件引用（插件极少用，交回官方依赖处理）
                if line.startswith("-r") or line.startswith("-e"):
                    continue
                try:
                    subprocess.run([vpy, "-m", "pip", "install", "--no-input"] +
                                   _find_links() + [line],
                                   check=True, capture_output=True, creationflags=flags)
                except subprocess.CalledProcessError as e:
                    _log(f"[忽略] 插件 {d} 的依赖「{line}」安装失败（不影响其余依赖）："
                         + str(e)[:120])
    _log(".venv 重建完成。")
    return True


def ensure_venv():
    """启动时保证 .venv 健康：轻量检查，失败则自动重建（必要时先关闭旧 ComfyUI）。"""
    ok, detail = _venv_quick_check()
    if ok:
        _log("venv 健康检查通过")
        return True
    _log(f"venv 健康检查未通过：{detail}")
    # 若端口被占用，说明旧 ComfyUI 仍存活 -> 需先关闭它才能重建
    if _port_in_use(8190):
        _log("端口 8190 被占用，需先关闭旧 ComfyUI。")
        if not _confirm_rebuild():
            _log("用户取消重建，退出。")
            return False
        _kill_comfy_processes()
        time.sleep(2)
    try:
        if not rebuild_venv():
            return False
    except Exception as e:
        _log(f"自动重建失败：{e}")
        return False
    ok2, d2 = _venv_quick_check()
    if not ok2:
        _log(f"重建后检查仍失败：{d2}")
        return False
    _log("venv 已重建并恢复健康。")
    return True


def _install_pyside6_from_wheels():
    """pip 安装被安全策略/网络拦截时的兜底：从 _pip_whl 里的 wheel 直接解压到 site-packages。"""
    import zipfile
    site = os.path.join(COMFY, ".venv", "Lib", "site-packages")
    wheel_dir = os.path.join(BASE, "_pip_whl")
    names = ["shiboken6*.whl", "pyside6_essentials*.whl", "pyside6_addons*.whl", "pyside6-*.whl"]
    found = []
    for pat in names:
        for p in sorted(glob.glob(os.path.join(wheel_dir, pat))):
            if os.path.basename(p).lower().startswith("pyside6-") and not os.path.basename(p).lower().startswith("pyside6_"):
                # 顶层 pyside6-xxx.whl 放在最后（依赖前三个）
                found.append(p)
                break
            else:
                found.append(p)
                break
    if len(found) < 4:
        _log(f"_pip_whl 里 PySide6 wheel 不全（只找到 {len(found)} 个），无法兜底解压")
        return False
    for whl in found:
        _log(f"兜底解压: {os.path.basename(whl)}")
        try:
            with zipfile.ZipFile(whl, "r") as z:
                z.extractall(site)
        except Exception as e:
            _log(f"解压失败: {e}")
            return False
    # 验证
    try:
        subprocess.run([VENV_UI, "-c", "import PySide6; print('PySide6 OK')"], check=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0)
        return True
    except Exception as e:
        _log(f"兜底解压后验证失败: {e}")
        return False


def _pyside6_installed():
    """文件级检查 PySide6 是否已装（快）。

    用文件检查代替 ``pythonw -c "import PySide6"`` 子进程，是为了省掉一次
    venv pythonw 冷启动（约 0.5-1 秒）。启动器每次打开都走这一步，而真正
    需要起子进程验证的只有「PySide6 没装」这一种罕见情况，其余全走快路径。
    """
    site = os.path.join(COMFY, ".venv", "Lib", "site-packages")
    pkg = os.path.join(site, "PySide6")
    if not os.path.isdir(pkg):
        return False
    # 目录存在但内容不完整（安装中断留下的空壳）时不能算就绪，需见到 QtCore
    try:
        return any(f.lower().startswith("qtcore") for f in os.listdir(pkg))
    except Exception:
        return False


def ensure_pyside6():
    """确保 venv 里装了 PySide6；没有就装。"""
    if not os.path.isfile(VENV_UI):
        _log("venv python 不存在，无法安装 PySide6")
        return
    # 快路径：文件级检查通过即认为就绪，省掉一次 pythonw 冷启动
    if _pyside6_installed():
        _log("PySide6 已就绪")
        return
    # 慢路径：文件检查不通过时，才起子进程真实验证（决定是否需要安装）
    # 用 pythonw 跑（无控制台窗口），并加 CREATE_NO_WINDOW 进一步防止闪窗
    kwargs = dict(check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        subprocess.run([VENV_UI, "-c", "import PySide6"], **kwargs)
        _log("PySide6 已就绪")
        return
    except subprocess.CalledProcessError:
        pass
    _log("正在安装 PySide6（首次较慢）…")
    try:
        subprocess.run([VENV_UI, "-m", "pip", "install", "--quiet"] + _find_links() + ["PySide6"],
                       check=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0)
        _log("PySide6 安装完成")
        return
    except Exception as e:
        _log(f"pip 安装 PySide6 失败: {e}，尝试从离线 wheel 解压兜底…")
    if _install_pyside6_from_wheels():
        _log("PySide6 已从离线 wheel 解压完成")
        return
    _log("PySide6 安装失败，启动器 UI 无法启动")
    sys.exit(1)


def _looks_like_model_dir(d):
    """判断目录是否像模型根（含已知子目录，或直接含权重文件）。"""
    if not os.path.isdir(d):
        return False
    known = {
        "diffusion_models", "checkpoints", "text_encoders", "loras", "vae",
        "unet", "clip", "clip_vision", "controlnet", "upscale_models",
        "embeddings", "annotator", "inpaint", "comfyui",
    }
    try:
        entries = os.listdir(d)
    except Exception:
        return False
    if any(e in known for e in entries):
        return True
    if any(e.lower().endswith((".safetensors", ".ckpt", ".pt", ".bin", ".gguf"))
           for e in entries):
        return True
    return False


def detect_model_dir():
    """免配置：自动定位模型根目录。返回 (目录, 是否自动探测到)。

    优先级：
      1. 用户在 settings.json 里手动设置且目录非空（尊重用户选择）
      2. 常见盘符下的 models 目录（D:/models、E:/models、C:/models、F:/models）
         且确实像模型根目录
      3. 包内 models（可能为空，由 UI 首次向导引导）
    """
    d = get_user_model_dir()
    if d and os.path.isdir(d) and os.listdir(d):
        return d, False
    # 用户填了但目录为空/不存在，或根本没填 → 自动探测常见位置
    import config as _cfg
    _cfg.set_model_dir("")  # 清掉无效设置，避免下次误用
    for drv in ("D", "E", "C", "F"):
        c = f"{drv}:\\models"
        if _looks_like_model_dir(c):
            return c, True
    return MODELS_DIR, False


def fix_model_paths():
    """把 extra_model_paths.yaml 的 base_path 指向模型根目录（免配置自动探测）。

    优先使用用户在 settings.json 里手动选择的模型根目录；未设置或无效时，
    自动探测 D:/models、E:/models 等常见位置；都找不到则回退包内 models，
    并由 UI 在首次运行时提示用户选择 / 用 Manager 下载。
    每次启动改写一次，保证模型根指向正确位置，随包移动到任意机器可用。
    """
    model_dir, auto = detect_model_dir()
    if auto:
        import config as _cfg
        _cfg.set_model_dir(model_dir)
        _log(f"自动探测到模型目录：{model_dir}（已写入设置）")
    else:
        _log(f"使用模型目录：{model_dir}")
    sync_extra_model_paths(model_dir)


def check_models():
    """按 manifest 检查模型是否就位；缺失给出提示。

    检查目录优先取用户设置的模型根目录（model_dir），否则取包内 models。
    """
    import json
    if not os.path.isfile(MANIFEST):
        _log("（无 models_manifest.json，跳过模型检查）")
        return
    try:
        data = json.load(open(MANIFEST, "r", encoding="utf-8"))
    except Exception as e:
        _log(f"读取 manifest 失败：{e}")
        return
    model_dir = get_user_model_dir() or MODELS_DIR
    missing = []
    for m in data.get("models", []):
        sub = m.get("subdir", "")
        name = m.get("file", "")
        p = os.path.join(model_dir, sub, name) if sub else os.path.join(model_dir, name)
        if not os.path.isfile(p):
            missing.append((sub, name))
    if missing:
        _log(f"⚠ 以下模型在「{model_dir}」尚未就位：")
        for sub, name in missing:
            _log(f"   - {sub}/{name}" if sub else f"   - {name}")
    else:
        _log("模型检查通过")


def _start_splash():
    """显示启动进度条（Splash）。失败不影响主流程。

    仅在无控制台场景（双击 启动.exe / pythonw）显示；用户手动跑 启动.bat
    （有控制台、能看到实时日志）时不弹，避免多余窗口干扰。
    窗口由 UI 进程在窗口 show() 之后调用 splash.close() 关闭。
    """
    try:
        if APP_DIR not in sys.path:
            sys.path.insert(0, APP_DIR)
        import splash
        if not splash.should_show():
            _log("（控制台模式，跳过启动进度条）")
            return
        if splash.show():
            _log("启动进度条已显示")
        else:
            _log("启动进度条未显示：%s" % splash.last_error())
    except Exception as e:
        _log(f"启动进度条跳过：{e}")


def main():
    _redirect_logs()
    # 单实例保护：重复双击的第二个实例直接退出，避免两个 bootstrap 并发重建 .venv
    if not _acquire_single_instance():
        _log("检测到已有启动器实例在运行，本实例退出。")
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0, "小能ComfyUI启动器已在运行，请勿重复双击。", "小能ComfyUI启动器", 0x40)
        except Exception:
            pass
        return
    _log(f"包根：{BASE}")
    # 启动器核心自更新：若上轮更新暂存了 启动_new.exe，先完成替换并重拉起，
    # 让新版启动器接管；随后退出当前进程（旧引导器不再启动 UI）。
    try:
        if APP_DIR not in sys.path:
            sys.path.insert(0, APP_DIR)
        import updater
        if updater.maybe_swap_exe(BASE):
            _log("已应用启动器核心更新，正在重启…")
            sys.exit(0)
    except Exception as e:
        _log(f"启动器自替换检查跳过：{e}")
    # 启动进度条：双击后立刻可见，覆盖 UI 冷启动（pythonw + PySide6 导入）的等待
    _start_splash()
    # 自动修复受管 ComfyUI 节点(如 comfyui-kjnodes 的 Sage 注意力崩溃 bug)：
    # 幂等、仅修旧版带 bug 的文件、绝不覆盖用户自定义/新版节点。
    try:
        sys.path.insert(0, APP_DIR)
        import node_patches
        node_patches.apply_node_patches(BASE)
    except Exception as e:
        _log(f"节点自动修复跳过：{e}")
    # 确保 outputs 目录存在（UI 默认保存目录）
    os.makedirs(os.path.join(BASE, "outputs"), exist_ok=True)
    fix_venv_home()
    if not ensure_venv():
        _fatal_error(
            "Python 环境已损坏，且无法自动修复。\n"
            "最常见原因：另一个 ComfyUI / python 进程正在运行并占用 .venv 文件。\n"
            "请先完全关闭所有 ComfyUI 与启动器窗口（确保 8190 端口空闲），\n"
            "再重新双击 启动.exe；启动器会自动重建环境。详见 launch_log.txt。")
        return
    fix_model_paths()
    ensure_pyside6()
    try:
        check_models()
    except Exception as e:
        import traceback as _tb
        _log("check_models 异常（跳过，继续启动 UI）：%s" % e)
        try:
            with open(os.path.join(BASE, "crash.log"), "a", encoding="utf-8") as _cf:
                _cf.write(_tb.format_exc() + "\n====\n")
        except Exception:
            pass
    ui = os.path.join(APP_DIR, "ui_pyside.py")
    if not os.path.isfile(ui):
        _log(f"未找到 UI 入口：{ui}")
        try:
            input("按回车退出…")
        except Exception:
            pass
        return
    # 确保 venv 的 pythonw.exe 存在（缺失时自动从 standalone-env 补回），
    # 否则会回退控制台 python.exe → 启动器带黑窗。自修复可能刚补回 pythonw，
    # 因此必须按当前实际状态重新选定解释器（模块加载时的 VENV_UI 可能已是 python.exe）。
    try:
        ensure_pythonw()
    except Exception as e:
        _log("ensure_pythonw 异常（忽略，继续）：%s" % e)
    # 确保 venv/Scripts 自带 CPython 运行库 DLL（python313.dll 等），避免 pythonw
    # 退化去加载冻结 _MEI 里的 python313.dll 导致 PySide6/Shiboken 崩溃闪退。
    try:
        ensure_venv_dlls()
    except Exception as e:
        _log("ensure_venv_dlls 异常（忽略，继续）：%s" % e)
    _ui_exe = VENV_PYW if os.path.isfile(VENV_PYW) else VENV_PY
    _log("启动主界面… (UI 解释器: %s)" % os.path.basename(_ui_exe))
    # 直接在前台启动 UI（UI 内部会按需拉起 ComfyUI）
    # 用 pythonw 启动 → 无控制台黑框；-u 去掉块缓冲，崩溃 traceback 仍能写进 launch_log.txt。
    kwargs = {}
    if os.name == "nt":
        # ⚠️ 关键：pythonw 是 GUI 子系统程序，本身就不会创建控制台窗口，
        # 绝不能给它传 STARTF_USESHOWWINDOW + SW_HIDE / CREATE_NO_WINDOW——
        # Qt 会把 STARTUPINFO.wShowWindow 当成首个窗口的默认 nCmdShow，导致主界面
        # 窗口被隐藏（进程在跑、看不到界面、再点一次提示"正在运行"=单实例命中）。
        # 只有当 pythonw 缺失、回退到控制台版 python.exe 时才需要隐藏黑窗。
        if os.path.basename(_ui_exe).lower() == "python.exe":
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = 0  # SW_HIDE
            kwargs["startupinfo"] = si
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    # 给 UI 子进程传一份干净环境（剔除冻结启动器自身的 PyInstaller 痕迹）：
    # 删除 PYTHON* 变量、_PYI* / _MEIPASS，并用 -E 让 venv pythonw 忽略继承的 PYTHON*
    # 环境变量；PATH 过滤掉 _MEI / app.asar.unpacked / standalone-env 等冻结期注入的目录，
    # 避免子进程环境被污染。根因修复另见 ensure_venv_dlls()——它已把 python313.dll 等
    # CPython 运行库放到 venv/Scripts 本地，Windows 加载器优先用本地副本，从根本上杜绝
    # pythonw 误加载冻结 _MEI 里的 python313.dll（其会把 _MEI/python313.zip 注入子进程
    # sys.path，与 venv 的 PySide6 ABI 不兼容，导致 import PySide6 时 Shiboken 崩溃闪退）。
    _env = {k: v for k, v in os.environ.items()
            if not k.upper().startswith("PYTHON")
            and not k.upper().startswith("_PYI")
            and k.upper() != "_MEIPASS"}
    _env["PATH"] = os.pathsep.join(
        p for p in _env.get("PATH", "").split(os.pathsep)
        if "_MEI" not in p and "standalone-env" not in p
        and "app.asar.unpacked" not in p
    )
    # 把 UI 的 stdout/stderr 落盘到 ui_err.txt，并在 UI 退出后记录 returncode/耗时，
    # 便于后续排查（正常启动时应超时存活、无报错）。
    _ui_err = os.path.join(BASE, "ui_err.txt")
    with open(_ui_err, "w", encoding="utf-8") as _ue:
        try:
            _t0 = time.time()
            _rc = subprocess.run([_ui_exe, "-E", "-u", ui], cwd=APP_DIR, env=_env,
                                 stdout=_ue, stderr=subprocess.STDOUT, **kwargs)
            _log("UI 进程退出 returncode=%s 耗时%.2fs" % (_rc.returncode, time.time() - _t0))
        except Exception as e:
            _log("拉起 UI 异常：%s" % e)


def _fatal_error(msg):
    """致命错误：写日志 + 弹出系统消息框（无控制台时也能看到）。

    额外把完整 traceback 落盘到 crash.log，避免 noconsole 下 sys.stderr 为 None
    导致信息丢失、只剩「闪退」无从排查。
    """
    try:
        with open(os.path.join(BASE, "crash.log"), "a", encoding="utf-8") as _cf:
            _cf.write(time.strftime("%Y-%m-%d %H:%M:%S [crash] ") + msg + "\n====\n")
    except Exception:
        pass
    try:
        _log("【致命错误】" + msg)
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(
            0, "启动失败：\n" + msg + "\n\n详细排查见同目录 launch_log.txt",
            "小能ComfyUI启动器", 0x10)
    except Exception:
        try:
            sys.stderr.write(msg + "\n")
        except Exception:
            pass


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        import traceback
        _fatal_error(traceback.format_exc())
