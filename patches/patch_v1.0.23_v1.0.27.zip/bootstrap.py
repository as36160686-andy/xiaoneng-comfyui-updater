# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · 首次启动准备（由 启动.bat 调用）。

职责（每次启动都会跑，幂等）：
  1. 把包内 ComfyUI/.venv/pyvenv.cfg 的「home」修正为当前绝对路径
     （指向 包/ComfyUI/standalone-env），使 venv 随包移动到任意位置都能用。
  2. 确保 PySide6 已装进 venv（UI 依赖）；没有就 pip 安装。
  3. 检查模型是否就位（按 models_manifest.json）；缺失则给出清晰提示/尝试下载。
  4. 启动 UI（ui_pyside.py）。
"""
import os
import sys
import subprocess
import json


BASE = os.path.dirname(os.path.abspath(__file__))          # 包根目录
COMFY = os.path.join(BASE, "ComfyUI")
VENV_PY = os.path.join(COMFY, ".venv", "Scripts", "python.exe")
# 优先用 pythonw（无控制台窗口）启动 UI；找不到时回退 python.exe
VENV_PYW = os.path.join(COMFY, ".venv", "Scripts", "pythonw.exe")
VENV_UI = VENV_PYW if os.path.isfile(VENV_PYW) else VENV_PY
BASE_PY = os.path.join(COMFY, "standalone-env", "python.exe")
BASE_PYW = os.path.join(COMFY, "standalone-env", "pythonw.exe")
BASE_UI = BASE_PYW if os.path.isfile(BASE_PYW) else BASE_PY
APP_DIR = os.path.join(BASE, "app")
MODELS_DIR = os.path.join(BASE, "models")                   # 包内模型根（与 extra_model_paths.yaml 对应）
MANIFEST = os.path.join(BASE, "models_manifest.json")
EXTRA_YAML = os.path.join(COMFY, "extra_model_paths.yaml")


def get_user_model_dir():
    """读取用户在 settings.json 中设置的模型根目录；未设置返回空串。"""
    try:
        if APP_DIR not in sys.path:
            sys.path.insert(0, APP_DIR)
        import config
    except Exception:
        return ""
    try:
        return config.get_model_dir()
    except Exception:
        return ""


def sync_extra_model_paths(model_dir):
    """把 extra_model_paths.yaml 的 base_path 改成用户指定的模型根目录。

    模型不再随包捆绑，用户在 UI 设置里手动选择含
    diffusion_models/text_encoders/loras/vae 子目录的目录（如 D:/models），
    本函数原地改写 ComfyUI 的 extra_model_paths.yaml 的 base_path 行。
    幂等：仅当确有变化时写文件。返回是否成功改写。
    """
    if not model_dir or not os.path.isdir(model_dir):
        _log(f"模型目录无效，跳过 extra_model_paths 同步：{model_dir}")
        return False
    if not os.path.isfile(EXTRA_YAML):
        _log("（无 extra_model_paths.yaml，跳过模型路径同步）")
        return False
    try:
        with open(EXTRA_YAML, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception as e:
        _log(f"读取 extra_model_paths.yaml 失败：{e}")
        return False
    norm = os.path.normpath(model_dir).replace("/", "\\")
    new_lines = []
    changed = False
    for ln in lines:
        stripped = ln.strip()
        if stripped.startswith("base_path"):
            indent = ln[:len(ln) - len(ln.lstrip())]
            new = f"{indent}base_path: {norm}\n"
            if ln.rstrip("\n") != new.rstrip("\n"):
                changed = True
            new_lines.append(new)
        else:
            new_lines.append(ln)
    if changed:
        try:
            with open(EXTRA_YAML, "w", encoding="utf-8") as f:
                f.writelines(new_lines)
            _log(f"已把模型根目录写入 ComfyUI -> {norm}")
        except Exception as e:
            _log(f"写入 extra_model_paths.yaml 失败：{e}")
            return False
    else:
        _log("模型根目录已就位")
    return True


def _log(msg):
    print(f"[bootstrap] {msg}")


def _redirect_logs():
    """把 stdout/stderr 重定向到包内 launch_log.txt。

    仅在「没有真实控制台」时生效（pythonw / 桌面隐藏启动）。
    手动运行 启动.bat（python.exe 有控制台）时保留原样，方便看实时日志。
    这样即使在 pythonw 下运行，启动日志也能落盘便于排查，且全程无控制台窗口。
    """
    if sys.stdout is not None:
        return
    try:
        log_path = os.path.join(BASE, "launch_log.txt")
        f = open(log_path, "w", encoding="utf-8", buffering=1)
        sys.stdout = f
        sys.stderr = f
    except Exception:
        pass


def fix_venv_home():
    """把 .venv/pyvenv.cfg 的 home 改成当前 standalone-env 绝对路径（幂等）。"""
    cfg = os.path.join(COMFY, ".venv", "pyvenv.cfg")
    if not os.path.isfile(cfg):
        _log(f"未找到 {cfg}，跳过 venv 修正")
        return
    with open(cfg, "r", encoding="utf-8") as f:
        lines = f.readlines()
    # venv 的 home 必须指向 standalone-env 目录本身（其顶层含 python.exe），
    # 它位于 包/standalone-env（与 ComfyUI/ 平级）。
    target = os.path.join(os.path.dirname(COMFY), "standalone-env")
    norm = os.path.normpath(target).replace("/", "\\")
    new_lines = []
    changed = False
    for ln in lines:
        if ln.strip().startswith("home"):
            new_home = f"home = {norm}\n"
            if ln.strip() != new_home.strip():
                changed = True
            new_lines.append(new_home)
        else:
            new_lines.append(ln)
    if changed:
        with open(cfg, "w", encoding="utf-8") as f:
            f.writelines(new_lines)
        _log(f"已修正 venv home -> {norm}")


def ensure_pyside6():
    """确保 venv 里装了 PySide6；没有就装。"""
    if not os.path.isfile(VENV_PY):
        _log("venv python 不存在，无法安装 PySide6")
        return
    # 用 pythonw 跑（无控制台窗口），并加 CREATE_NO_WINDOW 进一步防止闪窗
    kwargs = dict(check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        subprocess.run([VENV_UI, "-c", "import PySide6"], **kwargs)
        _log("PySide6 已就绪")
    except subprocess.CalledProcessError:
        _log("正在安装 PySide6（首次较慢）…")
        subprocess.run([VENV_UI, "-m", "pip", "install", "--quiet", "PySide6"],
                       check=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0)
        _log("PySide6 安装完成")


def _looks_like_model_dir(d):
    """判断目录是否像模型根（含已知子目录，或直接含权重文件）。"""
    if not os.path.isdir(d):
        return False
    known = {
        "diffusion_models", "checkpoints", "text_encoders", "loras", "vae",
        "unet", "clip", "clip_vision", "controlnet", "upscale_models",
        "embeddings", "annotator", "inpaint", "comfyui",
    }
    try:
        entries = os.listdir(d)
    except Exception:
        return False
    if any(e in known for e in entries):
        return True
    if any(e.lower().endswith((".safetensors", ".ckpt", ".pt", ".bin", ".gguf"))
           for e in entries):
        return True
    return False


def detect_model_dir():
    """免配置：自动定位模型根目录。返回 (目录, 是否自动探测到)。

    优先级：
      1. 用户在 settings.json 里手动设置且目录非空（尊重用户选择）
      2. 常见盘符下的 models 目录（D:/models、E:/models、C:/models、F:/models）
         且确实像模型根目录
      3. 包内 models（可能为空，由 UI 首次向导引导）
    """
    d = get_user_model_dir()
    if d and os.path.isdir(d) and os.listdir(d):
        return d, False
    # 用户填了但目录为空/不存在，或根本没填 → 自动探测常见位置
    import config as _cfg
    _cfg.set_model_dir("")  # 清掉无效设置，避免下次误用
    for drv in ("D", "E", "C", "F"):
        c = f"{drv}:\\models"
        if _looks_like_model_dir(c):
            return c, True
    return MODELS_DIR, False


def fix_model_paths():
    """把 extra_model_paths.yaml 的 base_path 指向模型根目录（免配置自动探测）。

    优先使用用户在 settings.json 里手动选择的模型根目录；未设置或无效时，
    自动探测 D:/models、E:/models 等常见位置；都找不到则回退包内 models，
    并由 UI 在首次运行时提示用户选择 / 用 Manager 下载。
    每次启动改写一次，保证模型根指向正确位置，随包移动到任意机器可用。
    """
    model_dir, auto = detect_model_dir()
    if auto:
        import config as _cfg
        _cfg.set_model_dir(model_dir)
        _log(f"自动探测到模型目录：{model_dir}（已写入设置）")
    else:
        _log(f"使用模型目录：{model_dir}")
    sync_extra_model_paths(model_dir)


def check_models():
    """按 manifest 检查模型是否就位；缺失给出提示。

    检查目录优先取用户设置的模型根目录（model_dir），否则取包内 models。
    """
    import json
    if not os.path.isfile(MANIFEST):
        _log("（无 models_manifest.json，跳过模型检查）")
        return
    try:
        data = json.load(open(MANIFEST, "r", encoding="utf-8"))
    except Exception as e:
        _log(f"读取 manifest 失败：{e}")
        return
    model_dir = get_user_model_dir() or MODELS_DIR
    missing = []
    for m in data.get("models", []):
        sub = m.get("subdir", "")
        name = m.get("file", "")
        p = os.path.join(model_dir, sub, name) if sub else os.path.join(model_dir, name)
        if not os.path.isfile(p):
            missing.append((sub, name))
    if missing:
        _log(f"⚠ 以下模型在「{model_dir}」尚未就位：")
        for sub, name in missing:
            _log(f"   - {sub}/{name}" if sub else f"   - {name}")
    else:
        _log("模型检查通过")


def main():
    _redirect_logs()
    _log(f"包根：{BASE}")
    # 启动器核心自更新：若上轮更新暂存了 启动_new.exe，先完成替换并重拉起，
    # 让新版启动器接管；随后退出当前进程（旧引导器不再启动 UI）。
    try:
        if APP_DIR not in sys.path:
            sys.path.insert(0, APP_DIR)
        import updater
        if updater.maybe_swap_exe(BASE):
            _log("已应用启动器核心更新，正在重启…")
            sys.exit(0)
    except Exception as e:
        _log(f"启动器自替换检查跳过：{e}")
    # 确保 outputs 目录存在（UI 默认保存目录）
    os.makedirs(os.path.join(BASE, "outputs"), exist_ok=True)
    fix_venv_home()
    fix_model_paths()
    ensure_pyside6()
    check_models()
    ui = os.path.join(APP_DIR, "ui_pyside.py")
    if not os.path.isfile(ui):
        _log(f"未找到 UI 入口：{ui}")
        try:
            input("按回车退出…")
        except Exception:
            pass
        return
    _log("启动主界面…")
    # 直接在前台启动 UI（UI 内部会按需拉起 ComfyUI）
    # 用 pythonw（VENV_UI）启动 → 无控制台黑框；-u 去掉块缓冲，崩溃 traceback 仍能写进 launch_log.txt。
    kwargs = {}
    if os.name == "nt":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0  # SW_HIDE
        kwargs["startupinfo"] = si
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.run([VENV_UI, "-u", ui], cwd=APP_DIR, **kwargs)


def _fatal_error(msg):
    """致命错误：写日志 + 弹出系统消息框（无控制台时也能看到）。"""
    try:
        _log("【致命错误】" + msg)
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(
            0, "启动失败：\n" + msg + "\n\n详细排查见同目录 launch_log.txt",
            "小能ComfyUI启动器", 0x10)
    except Exception:
        try:
            sys.stderr.write(msg + "\n")
        except Exception:
            pass


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        import traceback
        _fatal_error(traceback.format_exc())
