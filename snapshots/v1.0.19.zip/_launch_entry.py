# -*- coding: utf-8 -*-
"""启动.exe 入口（PyInstaller --onefile 打包此文件）。

设计要点（解决「换电脑无法启动」）：
  - 本文件是【纯启动器】，不依赖任何外部模块（仅标准库）。
  - PyInstaller onefile 运行时 __file__ 指向 %TEMP%_MEIxxxx 临时目录，
    因此绝不能用 __file__ 去找同级的 ComfyUI / standalone-env / app。
  - 正确做法：用 sys.argv[0]（用户双击的原始 exe 路径）反推【包根目录】，
    再用包内 pythonw 启动真正的 bootstrap.py（盘上的真实文件）。
  - bootstrap.py 从真实文件运行时，它自己的 BASE = 真实包根，
    所有相对路径（fix_venv_home 修正 venv、找 app/ 等）才会正确。
"""
import os
import sys
import subprocess


def _msgbox(text, title="小能ComfyUI启动器"):
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, str(text), title, 0x10)
    except Exception:
        # 兜底：至少打印到控制台（若有）
        try:
            sys.stderr.write(str(text) + "\n")
        except Exception:
            pass


def main():
    # 关键：用原始 exe 路径定位包根，onefile 临时目录也能正确得到真实包路径
    pkg = os.path.dirname(os.path.abspath(sys.argv[0]))
    try:
        os.chdir(pkg)
    except Exception:
        _msgbox("无法进入程序目录：\n%s" % pkg)
        return 1

    bootstrap = os.path.join(pkg, "bootstrap.py")
    # 优先用包内独立 base 环境（standalone-env）跑 bootstrap，
    # 因为它不是 venv、不受 pyvenv.cfg 的 home 路径影响；
    # 仅当不存在时回退到 ComfyUI 自带 venv。
    py_base = os.path.join(pkg, "standalone-env", "pythonw.exe")
    py_venv = os.path.join(pkg, "ComfyUI", ".venv", "Scripts", "pythonw.exe")
    python = py_base if os.path.isfile(py_base) else py_venv

    missing = []
    if not os.path.isfile(bootstrap):
        missing.append("bootstrap.py（启动脚本丢失）")
    if not os.path.isfile(python):
        missing.append("Python 运行环境（standalone-env / ComfyUI\\.venv）")
    if missing:
        _msgbox("启动失败：以下文件缺失，请确认【整个文件夹】已完整复制。\n\n- "
                + "\n- ".join(missing)
                + "\n\n建议：把「小能ComfyUI启动器」整个目录一起拷贝，不要只复制 exe。")
        return 1

    # 注入 PortableGit 到 PATH（与 启动.bat 行为一致），使更新/拉取可用
    env = os.environ.copy()
    git = os.path.join(pkg, "tools", "PortableGit", "cmd", "git.exe")
    if os.path.isfile(git):
        gitdir = os.path.join(pkg, "tools", "PortableGit")
        env["PATH"] = ";".join([
            os.path.join(gitdir, "cmd"),
            os.path.join(gitdir, "mingw64", "bin"),
            os.path.join(gitdir, "usr", "bin"),
            env.get("PATH", ""),
        ])
        home = os.path.join(gitdir, "home")
        os.makedirs(home, exist_ok=True)
        env["HOME"] = home
        env["USERPROFILE"] = home

    # 用 pythonw 启动 bootstrap，无控制台黑窗；
    # bootstrap 内部崩溃的 traceback 会写进包根 launch_log.txt。
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    try:
        subprocess.run(
            [python, "-u", bootstrap],
            cwd=pkg,
            env=env,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            startupinfo=si,
        )
    except Exception as e:
        _msgbox("启动失败：%s" % e)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
