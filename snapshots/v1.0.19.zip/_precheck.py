import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "app"))
import config, comfy_launch

print("=== 启动前预检：依赖注册对包内真实目录生效 ===")
print("effective_plugin_dir =", comfy_launch.effective_plugin_dir())

# 1) 扫描包内所有插件依赖声明
pairs = comfy_launch.scan_plugin_requirements()
with_deps = [(n, r, u) for n, r, u in pairs if r or u]
print("插件总数 = %d, 有依赖声明的 = %d" % (len(pairs), len(with_deps)))

all_specs = []
for n, reqs, urls in pairs:
    for r in reqs:
        if r not in all_specs:
            all_specs.append(r)
print("依赖声明项总数 = %d" % len(all_specs))

# 2) 比对 venv 已安装（不联网），只算 pip 可装项
miss = comfy_launch.missing_packages(all_specs)
print("venv 中缺失(pip 可装) = %d" % len(miss))
for m in miss[:15]:
    print("   -", m)

# 3) 验证 restore 逻辑：当前无 junction，调用不应破坏现有目录
before = len(os.listdir(comfy_launch.os.path.join(comfy_launch.COMFY_DIR, "custom_nodes")))
comfy_launch.sync_plugin_dir()
comfy_launch.sync_workflow_dir()
after = len(os.listdir(comfy_launch.os.path.join(comfy_launch.COMFY_DIR, "custom_nodes")))
print("restore 前后 custom_nodes 条目: %d -> %d (应相等，未误删)" % (before, after))
print("PRECHECK_OK")
