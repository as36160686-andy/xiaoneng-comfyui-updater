import os, sys, time
sys.path.insert(0, os.path.join(os.getcwd(), "app"))
import comfy_launch, config

log_path = comfy_launch._comfy_log_path()
# 清空旧日志，便于只看本次启动
if os.path.isfile(log_path):
    try:
        os.remove(log_path)
    except Exception:
        pass

print(">>> 启动 ComfyUI（GPU 模式）...")
proc = comfy_launch.spawn_comfyui(silent=True, extra_args="")
print(">>> PID =", proc.pid if proc else None)

started = False
dead = False
poll_until = time.time() + 200
last_read = 0
while time.time() < poll_until:
    # 检查就绪
    if comfy_launch.is_ready(config.get_comfy_url()):
        started = True
        break
    # 读取日志尾部，捕捉致命错误
    if os.path.isfile(log_path):
        size = os.path.getsize(log_path)
        if size > last_read:
            with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                f.seek(last_read)
                chunk = f.read()
            last_read = size
            low = chunk.lower()
            if "running on" in low or "to see the gui go to" in low:
                started = True
                break
            if "access violation" in low or "torch_library" in low or \
               "importerror" in low or "modulenotfounderror" in low or \
               ("traceback" in low and "error" in low):
                # 可能仍在启动早期，先不急着判死，继续等
                pass
    time.sleep(3)

# 读取最终日志尾部
tail = ""
if os.path.isfile(log_path):
    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.read().splitlines()
    tail = "\n".join(lines[-40:])

print(">>> is_ready:", comfy_launch.is_ready(config.get_comfy_url()))
print(">>> 启动成功:", started)
print("=" * 60)
print(tail[-3000:] if tail else "(无日志)")
print("=" * 60)

# 无论成败都清理
print(">>> 停止 ComfyUI...")
comfy_launch.stop_comfyui()
print(">>> 测试结束")
