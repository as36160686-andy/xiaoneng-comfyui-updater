@echo off
setlocal
set VENV=D:\ComfyUI\ComfyUI\.venv\Scripts\python.exe

echo ============================================
echo  小能ComfyUI启动器 - 插件依赖一键修复
echo  包根: D:\ComfyUI
echo ============================================
echo.

echo [1/2] 升级 pip...
"%VENV%" -m pip install --upgrade pip
echo.

echo [2/2] 批量安装 custom_nodes 依赖 (requirements.txt)...
echo.
for /d %%d in ("D:\ComfyUI\ComfyUI\custom_nodes\*") do (
  if exist "%%d\requirements.txt" (
    echo === 安装 %%~nxd ===
    "%VENV%" -m pip install -r "%%d\requirements.txt" || echo [跳过] %%~nxd 安装失败(继续下一个)
  )
)

echo.
echo ============================================
echo  完成。请关闭 ComfyUI 后重新双击 启动.exe
echo ============================================
pause >nul
