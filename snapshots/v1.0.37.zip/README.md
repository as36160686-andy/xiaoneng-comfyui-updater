# 小能ComfyUI启动器（原 小能ComfyUI启动器 / ComfyUI 便携启动器）

把本文件夹整体拷贝到任意一台 **Windows + NVIDIA 显卡** 电脑，双击 `启动.exe`（推荐）即可使用。
软件、Python 运行环境、ComfyUI、常用自定义节点、ComfyUI-Manager、**Git for Windows（PortableGit）** 都已打包在一起，
**目标机无需安装 Python、Git 等任何外部依赖**，解压后双击 `启动.exe` 即可（`启动.vbs` / `启动.bat` 作为备用入口保留）。

启动器只做四件事：
1. **启动 / 监控 ComfyUI** 运行状态
2. **打开 ComfyUI 原生网页**（拖入/导入任意 `.json` 工作流即可运行）
3. **打开本地工作流文件**（选一个 `.json`，自动放进网页 Load 列表并开网页）
4. **更新 ComfyUI**（一键 `git pull` + 更新依赖）
5. **插件管理器**（浏览/搜索/启用/禁用/卸载/检查更新/更新已装插件）

## 目录结构
```
小能ComfyUI启动器/
├─ 启动.exe              # 推荐入口：双击即静默启动，无需任何脚本环境，避免 .vbs 被拦截
├─ 启动.vbs              # 备用入口：无命令行黑窗（部分安全软件会拦截 .vbs）
├─ 启动.bat              # 备用入口（会闪一个命令行黑窗）
├─ 打包.bat              # 把本包压缩成 .7z 方便分发（无 7-Zip 也可直接复制文件夹）
├─ bootstrap.py          # 每次启动的环境准备（修正 venv 路径、自动探测模型目录、装 UI 依赖）
├─ settings.json         # 用户设置（模型目录等，自动生成）
├─ ComfyUI/              # ComfyUI 本体（含 custom_nodes、.venv）
├─ standalone-env/       # 独立 Python 运行环境（venv 的基础解释器）
├─ app/                  # 启动器（PySide6 界面）
├─ models/               # 模型文件（按需放入 checkpoints / loras / vae 等子目录）
└─ outputs/              # 生成结果默认保存目录
```

## 模型（免配置）
**启动时会自动探测模型目录**，无需手动配置：
1. 优先用你之前在设置里选过的目录；
2. 否则自动扫描 `D:/models`、`E:/models`、`C:/models`、`F:/models` 等常见位置；
3. 都找不到 → 回退到包内 `models/`（通常为空），桌面程序会弹出一次向导，
   让你「浏览选择已有模型目录」或「打开网页用 Manager 下载」。

模型不随包捆绑（单个模型几 GB~十几 GB，打包会很臃肿）。把模型按
`models_manifest.json` 放进 `models/<子目录>/`，或在设置里指向你已有的模型目录即可。

## 换机器注意事项
- **必须有 NVIDIA 显卡及驱动**（ComfyUI 跑 CUDA，硬前提）。
- 本包自带 Python 与 ComfyUI，目标机**无需另外安装 Python**。
- 移动本文件夹到任何位置都能用：启动时会把 venv 路径、模型路径自动修正为当前位置，
  不要拆散子目录。
- 若提示缺模型，按 `models_manifest.json` 补全，或用网页端 Manager 下载。

## 分发
- 简单：直接把整个文件夹复制给目标电脑，**双击 `启动.vbs`（无黑窗）**。
- 压缩：运行 `打包.bat`（需 7-Zip）生成 `ComfyUI-Portable.7z`；没有 7-Zip 也可用资源管理器右键压缩，
  或直接复制文件夹（推荐，省去解压时间）。
- 包体约 11GB 软件环境 + 132MB 内置 Git，模型需另放。
- **改名**：复制/解压后，把文件夹随意改名为 `ComfyUI-Portable` 等任意名字都可以——
  启动时会自动把 venv 路径、模型路径修正为当前位置，**不影响使用**。

## 更新 ComfyUI
启动器里点 **「🔄 更新 ComfyUI」**：
- 自动在 `ComfyUI/` 执行 `git pull`；
- 自动用 venv 的 pip 更新 `ComfyUI/requirements.txt`；
- 如果装了 ComfyUI-Manager，会同步更新它。

> 更新前若 ComfyUI 正在运行，启动器会先尝试关闭它；更新完成后需重新点「启动 ComfyUI」。
> 本包已内置 Git，无需在目标机安装 Git for Windows。
> 若 `ComfyUI/` 不是 git 仓库（比如解压时没保留 `.git`），则无法一键更新，需到官网下载新版替换。

## 插件管理器
启动器里点 **「🧩 插件管理器」**：
- **搜索**：按插件名实时过滤已安装节点；
- **启用/禁用**：直接切换插件状态（重启 ComfyUI 生效）；
- **卸载**：删除选中插件目录（带二次确认）；
- **版本号**：列表显示每个插件的本地版本号；
- **检查更新**：点 **「🔍 检查更新」** 后，对有 git 仓库的插件 fetch 远程并显示可更新版本号、`🔄可更新` 标记；
- **更新选中/更新全部**：对标记为可更新的插件执行 `git pull`；
- **打开 Manager 网页**：直接跳转到 ComfyUI-Manager 的节点管理网页，可在线安装新插件。

## 启动 / 停止 / 重启 / 终端
启动器主界面按钮：
- **▶ 启动 ComfyUI**：拉起后端（已运行时自动连接，不重复启动）。
- **⏹ 停止 ComfyUI**：关闭后端。采用「进程树 + 端口兜底」双重停止——即便子进程有 torch 子线程、或后端是手动启动的，也会按监听端口强制结束整棵树，确保服务真正停掉。
- **🔄 重启 ComfyUI**：先停止再重新拉起。
- **💻 命令行终端**：以**管理员权限**打开一个已激活 ComfyUI venv（含内置 git、HF 镜像）的 `cmd`，可直接 `pip install`、`git clone`、`python main.py ...` 手动装插件或调试。

> 停止功能依赖 Windows `taskkill` 与 `netstat`，均为系统自带；终端提权依赖 UAC，点开时若弹出用户账户控制请允许。

> 检查更新 / 更新插件 / Manager 网页安装新节点都需要 **git 且联网**。
> 本包已内置 PortableGit（`tools/PortableGit/`），目标机无需另外安装 Git for Windows；
> 若仍提示未找到 git，请检查 `tools/PortableGit/` 目录是否完整。

## 镜像源切换（Git / HuggingFace）
启动器设置面板提供 **Git 镜像** 与 **HuggingFace 镜像** 选项：
- **Git 镜像**：境外（GitHub 官方）、中国镜像（ghfast.top 加速）。选择中国镜像后，所有 `git pull` / `git fetch` 都会自动走镜像站，无需手动改仓库地址。
- **HuggingFace 镜像**：境外（官方）、中国镜像（hf-mirror.com）。选择中国镜像后，启动器会设置 `HF_ENDPOINT=https://hf-mirror.com`，Manager / 节点下载模型时会自动走国内镜像。

> 镜像源持久化在 `settings.json` 中，切换后立即对后续更新/下载生效。若在国内访问 GitHub / HuggingFace 慢或失败，优先切换到「中国镜像」。

## 常见问题
- **换电脑 / 拷贝后无法启动、弹出 `launch_log.txt`**：本程序是「绿色免安装」的，**必须把整个 `小能ComfyUI启动器` 文件夹一起拷贝，不要只复制 `启动.exe`**。首次在另一台电脑上运行时，启动器会自动把 `ComfyUI/.venv` 里的 Python 路径修正为新位置（这就是之前换电脑失败的根因），并正常启动。若仍失败，会弹出明确的错误提示，详细原因见同目录 `launch_log.txt`。
- **启动时出现命令行黑窗 / `.vbs` 被拦截**：请直接双击 `启动.exe`。它是用 PyInstaller 打包的纯启动器，双击会以隐藏窗口方式调用包内 Python 运行 `bootstrap.py`，**不依赖任何脚本宿主、不会出现黑窗、也不会被安全软件当作 .vbs 拦截**。`启动.vbs` / `启动.bat` 仅作为备用入口保留。
- **`启动.exe` 被杀毒软件误报**：PyInstaller 生成的单文件 exe 偶尔会被个别杀软误判。可将本程序目录加入杀软白名单，或改用 `启动.vbs`（若未被拦截）。
- **需要重新生成 `启动.exe`**：在装有 Python 的环境执行 `pyinstaller --noconsole --onefile --name 启动 _launch_entry.py` 即可（`_launch_entry.py` 为启动器源码，已随包提供，它只负责定位包根并调用包内 Python 启动 `bootstrap.py`）。
- 启动慢/卡在「等待 ComfyUI 就绪」：首次加载模型需 1–3 分钟，属正常。
- 端口冲突自动避让：若 8190 已被其它程序占用，启动器会**自动改用 8191/8192… 空闲端口**并回写配置，自动连上，无需手动处理。
- 网页端导入外部工作流报「节点缺失」：用 Manager 的 `Install missing nodes` 安装即可。
- 网页端导入外部工作流报「模型缺失」：用 Manager 的 `Download missing models` 下载，或把模型放进 `models/` 对应子目录。
- 点击「打开 Manager 网页」后提示「Manager 未加载」：说明 ComfyUI-Manager 后端没有成功启动。常见原因是 ComfyUI 子进程找不到 git。本包已自动注入包内 PortableGit 路径，若仍出现，请点 **🔄 重启 ComfyUI**；也可查看 `ComfyUI/user/comfyui_*.log` 里的报错。
