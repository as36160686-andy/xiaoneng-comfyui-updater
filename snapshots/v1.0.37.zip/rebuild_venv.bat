@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion

:: 小能ComfyUI启动器 - .venv 重建脚本（可移植版）
:: BASE 通过 %~dp0 自动定位，无论包放在哪个文件夹/电脑都能用。
:: 用途：当 .venv 在移动/复制过程中损坏（pip 包源码目录丢失但 dist-info 仍在），
::       或换电脑后路径失效时，彻底重建 ComfyUI\.venv 并重新安装所有依赖。
:: 注意：此脚本会删除并重建 .venv，请确保 ComfyUI 已完全关闭（8190 端口空闲）。

:: 自动定位包根（启动器所在目录）
set "BASE=%~dp0"
if "%BASE%"=="" set "BASE=."

set "COMFY=%BASE%ComfyUI"
set "VENV=%COMFY%\.venv"
set "PYTHON=%BASE%standalone-env\python.exe"

if not exist "%PYTHON%" (
    echo [错误] 找不到便携式 Python：%PYTHON%
    echo 请确认已将整个 ComfyUI 便携包移动到目标位置。
    pause
    exit /b 1
)

:: 端口占用检查：若 8190 仍被旧 ComfyUI 占用，说明 .venv 被锁，不能重建
powershell -NoProfile -Command "if(Get-NetTCPConnection -LocalPort 8190 -ErrorAction SilentlyContinue){exit 1}else{exit 0}"
if not errorlevel 1 (
    echo [错误] 端口 8190 仍被占用（另一个 ComfyUI 正在运行），无法重建 .venv。
    echo 请先完全关闭所有 ComfyUI / 启动器窗口，再重新运行本脚本。
    pause
    exit /b 1
)

echo ============================================
echo  小能ComfyUI启动器 - .venv 重建（可移植）
echo  包根: %BASE%
echo ============================================
echo.
echo [警告] 即将删除并重建 %VENV%
echo [警告] 请确保 ComfyUI 已完全关闭
echo.
pause

:: 离线 wheel 缓存（包内 _pip_whl，若存在则优先用于加速/离线）
set "FL="
if exist "%BASE%_pip_whl" set "FL=-f %BASE%_pip_whl"

:: 1. 删除旧 venv
echo [1/6] 删除损坏的 .venv ...
if exist "%VENV%" (
    rmdir /s /q "%VENV%"
    if exist "%VENV%" (
        echo [错误] 无法删除 %VENV%，请手动删除后重试。
        pause
        exit /b 1
    )
)
echo 完成。

:: 2. 创建新 venv（用 base python）
echo [2/6] 创建新的虚拟环境 ...
"%PYTHON%" -m venv "%VENV%"
if not exist "%VENV%\Scripts\python.exe" (
    echo [错误] 虚拟环境创建失败。
    pause
    exit /b 1
)
set "VENV_PY=%VENV%\Scripts\python.exe"
echo 完成。

:: 3. 升级 pip
echo [3/6] 升级 pip ...
"%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 (
    echo [警告] pip 升级失败，继续 ...
)

:: 4. 安装 torch CUDA 构建（精确锁定 cu130，避免装到不同 CUDA 构建）
echo [4/6] 安装 torch (cu130) ...
"%VENV_PY%" -m pip install torch==2.9.1+cu130 torchvision==0.24.1+cu130 torchaudio==2.9.1+cu130 --extra-index-url https://download.pytorch.org/whl/cu130 %FL%
if errorlevel 1 (
    echo [错误] torch 安装失败（请检查网络或 cu130 索引可用性）。
    pause
    exit /b 1
)

:: 5. 安装 ComfyUI 核心依赖
echo [5/6] 安装 ComfyUI 核心依赖 ...
if exist "%COMFY%\requirements.txt" (
    "%VENV_PY%" -m pip install %FL% -r "%COMFY%\requirements.txt"
    if errorlevel 1 (
        echo [错误] ComfyUI 核心依赖安装失败。
        pause
        exit /b 1
    )
) else (
    echo [警告] 找不到 %COMFY%\requirements.txt，跳过核心依赖。
)

:: 6. 安装各 custom_nodes 依赖
::    逐行安装（而非整文件 -r）：某些插件依赖含「可选但无法从源码构建」的包
::    （如 cupy-wheel 在 cp313 下构建失败），整文件 -r 会在任一包失败时整体回滚，
::    导致同文件内其它正常依赖（einops/kornia/scipy 等）也装不上。逐行安装让坏包
::    单独失败、好包照常装上，与当前「无 cupy 也能跑」的环境表现一致。
echo [6/6] 安装插件依赖 ...
for /d %%D in ("%COMFY%\custom_nodes\*") do (
    if exist "%%D\requirements.txt" (
        echo === 安装 %%~nxD ===
        for /f "usebackq eol=# tokens=* delims=" %%L in ("%%D\requirements.txt") do (
            set "LINE=%%L"
            set "FIRST=!LINE:~0,2!"
            if not "!FIRST!"=="-r" if not "!FIRST!"=="-e" (
                if not "!LINE!"=="" (
                    "%VENV_PY%" -m pip install --no-input %FL% "!LINE!" >nul 2>&1 || echo [跳过] %%~nxD 依赖 "!LINE!" 安装失败（继续）
                )
            )
        )
    )
)

:: 验证关键导入
echo.
echo ============================================
echo  验证关键包 ...
echo ============================================
"%VENV_PY%" -c "import torch, transformers, yaml, requests, PIL; print('核心包导入 OK:', torch.__version__)" || (
    echo [警告] 部分核心包导入失败，请检查上方错误。
)

echo.
echo ============================================
echo  .venv 重建完成。
echo  请关闭本窗口，然后双击 %BASE%启动.exe 启动 ComfyUI。
echo ============================================
pause
