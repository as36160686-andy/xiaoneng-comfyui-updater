@echo off
chcp 65001 >nul
setlocal
set "BASE=%~dp0"

if not exist "%BASE%ComfyUI\.venv\Scripts\python.exe" (
    echo [ERROR] ComfyUI venv not found: ComfyUI\.venv\Scripts\python.exe
    echo Please make sure the package is complete.
    pause
    exit /b 1
)
if not exist "%BASE%standalone-env\python.exe" (
    echo [ERROR] standalone-env not found.
    echo Please make sure the package is complete.
    pause
    exit /b 1
)

:: 如果包内自带 PortableGit，把它加入 PATH，使 ComfyUI-Manager / 启动器都能调用 git
if exist "%BASE%tools\PortableGit\cmd\git.exe" (
    set "PATH=%BASE%tools\PortableGit\cmd;%BASE%tools\PortableGit\mingw64\bin;%BASE%tools\PortableGit\usr\bin;%PATH%"
    set "HOME=%BASE%tools\PortableGit\home"
    set "USERPROFILE=%BASE%tools\PortableGit\home"
    if not exist "%BASE%tools\PortableGit\home" mkdir "%BASE%tools\PortableGit\home"
)

:: 使用 pythonw.exe 启动，避免子进程再弹出一个 Python 控制台窗口
"%BASE%standalone-env\pythonw.exe" -u "%BASE%bootstrap.py" > "%BASE%launch_log.txt" 2>&1
if errorlevel 1 (
    echo.
    echo [LAUNCH FAILED] See launch_log.txt for details.
    echo Opening the log in Notepad...
    start notepad "%BASE%launch_log.txt"
    pause
)
endlocal
