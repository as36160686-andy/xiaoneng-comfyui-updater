# -*- coding: utf-8 -*-
"""启动进度条（Splash）窗口 —— 双击启动器后的即时可见反馈。

存在意义
--------
用户双击 启动.exe 后，真正的主界面要等 venv 的 pythonw 冷启动 + PySide6
导入 + ui_pyside.py 加载（约 2-3 秒）才出现，这段空白会让用户以为
「软件没打开」而反复双击。本模块在 bootstrap 一启动就弹出一个带进度条的
小窗口，把这段等待变成「看得见的启动中」。

为什么用 ctypes 而不是 PySide6
------------------------------
Splash 要覆盖的正是「Qt 还没加载完」的那段时间，所以必须零第三方依赖。
这里直接用 ctypes 调 Win32 API 建窗口 + 进度条，创建耗时可忽略（毫秒级），
且不需要 Qt / tkinter / 任何额外打包依赖。

用法
----
bootstrap 进程（拉起 UI 前，非阻塞）::

    import splash
    splash.show()          # 起一个线程跑 Win32 消息循环，立刻返回

UI 进程（窗口 show() 之后，跨进程关闭）::

    import splash
    splash.close()         # 按窗口类名找到 Splash 并 WM_CLOSE

设计要点
--------
* 窗口类名固定为 ``XiaoNengLauncherSplash``，UI 侧靠它 FindWindow 跨进程关闭。
* 消息循环必须在**独立线程**：bootstrap 主线程要阻塞在 ``subprocess.run``
  拉起 UI，没空跑消息循环。
* 进度条用「定时器驱动 PBM_SETPOS 循环走动」而非 marquee：marquee 动画依赖
  comctl32 v6 视觉样式，未启用时不动；定时推进则任何环境都在动。
* 全程 try/except：Splash 只是体验增强，任何异常都不允许影响启动器主流程。
"""
import os
import sys
import ctypes
import threading

try:
    from ctypes import wintypes
except ImportError:
    # PyInstaller 打包后 ctypes.wintypes 可能不在 PYZ 里：本模块是 bootstrap
    # 运行时动态 import 的，PyInstaller 分析入口脚本时看不见它，自然不会收集
    # 它的依赖（实测报错：cannot import name 'wintypes' from 'ctypes'）。
    # 这里用等价的 ctypes 原生类型兜底，让 Splash 在任何打包环境下都能工作，
    # 不必依赖打包配置是否正确 —— 否则进度条会静默消失，用户完全看不到。
    class _POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

    class _WintypesFallback(object):
        UINT = ctypes.c_uint
        DWORD = ctypes.c_uint32
        BOOL = ctypes.c_int
        ATOM = ctypes.c_ushort
        COLORREF = ctypes.c_uint32
        HANDLE = ctypes.c_void_p
        HWND = ctypes.c_void_p
        HBRUSH = ctypes.c_void_p
        HICON = ctypes.c_void_p
        HINSTANCE = ctypes.c_void_p
        HMENU = ctypes.c_void_p
        HMODULE = ctypes.c_void_p
        LPVOID = ctypes.c_void_p
        LPCWSTR = ctypes.c_wchar_p
        LPARAM = (ctypes.c_longlong if ctypes.sizeof(ctypes.c_void_p) == 8
                  else ctypes.c_long)
        WPARAM = (ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8
                  else ctypes.c_uint)
        POINT = _POINT

    wintypes = _WintypesFallback()

IS_WINDOWS = (os.name == "nt")

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
SPLASH_CLASS = "XiaoNengLauncherSplash"   # UI 侧按此类名 FindWindow

WM_CLOSE = 0x0010
WM_DESTROY = 0x0002
WM_TIMER = 0x0113
WM_SETFONT = 0x0030

WS_CHILD = 0x40000000
WS_VISIBLE = 0x10000000
WS_POPUP = 0x80000000
WS_EX_TOPMOST = 0x00000008
WS_EX_TOOLWINDOW = 0x00000080

SS_CENTER = 0x0001

PROGRESS_CLASS = "msctls_progress32"      # 进度条窗口类
PBM_SETRANGE = 0x0400 + 1                 # 1025
PBM_SETPOS = 0x0400 + 2                   # 1026

IDC_ARROW = 32512
DEFAULT_GUI_FONT = 17                     # GetStockObject 参数
SM_CXSCREEN = 0
SM_CYSCREEN = 1

WIN_W = 380
WIN_H = 132
TIMER_ID = 1
TIMER_MS = 55                             # 进度条步进间隔

# 默认值，可被 show() 覆盖
DEFAULT_TEXT = "正在启动 小能ComfyUI启动器…"
DEFAULT_TITLE = "小能ComfyUI启动器"

# ---------------------------------------------------------------------------
# ctypes 类型（区分 32/64 位，避免 LRESULT/WPARAM/LPARAM 截断）
# ---------------------------------------------------------------------------
if ctypes.sizeof(ctypes.c_void_p) == 8:
    LRESULT = ctypes.c_longlong
    WPARAM_T = ctypes.c_ulonglong
    LPARAM_T = ctypes.c_longlong
else:
    LRESULT = ctypes.c_long
    WPARAM_T = ctypes.c_uint
    LPARAM_T = ctypes.c_long

WNDPROC = ctypes.WINFUNCTYPE(
    LRESULT, ctypes.c_void_p, wintypes.UINT, WPARAM_T, LPARAM_T)


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT),
        ("style", wintypes.UINT),
        ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HICON),
        ("hCursor", wintypes.HANDLE),
        ("hbrBackground", wintypes.HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
        ("hIconSm", wintypes.HICON),
    ]


class MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("message", wintypes.UINT),
        ("wParam", wintypes.WPARAM),
        ("lParam", wintypes.LPARAM),
        ("time", wintypes.DWORD),
        ("pt", wintypes.POINT),
    ]


# ---------------------------------------------------------------------------
# 运行时状态
# ---------------------------------------------------------------------------
_STATE = {
    "hwnd": 0,        # 主窗口句柄
    "pb": 0,          # 进度条句柄
    "pos": 0,         # 当前进度位置
    "thread": None,
    "ready": threading.Event(),
    "error": None,
}

_user32 = None
_kernel32 = None
_gdi32 = None
_comctl32 = None
_WNDPROC_INST = None      # 必须保持全局引用，否则回调被 GC 后窗口崩溃


def _bind():
    """惰性绑定 Win32 API（失败返回 False，Splash 整体降级为不显示）。"""
    global _user32, _kernel32, _gdi32, _comctl32
    if _user32 is not None:
        return True
    try:
        _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        _user32 = ctypes.WinDLL("user32", use_last_error=True)
        _gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
        _comctl32 = ctypes.WinDLL("comctl32", use_last_error=True)

        _kernel32.GetModuleHandleW.restype = wintypes.HMODULE
        _kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]

        _user32.RegisterClassExW.restype = wintypes.ATOM
        _user32.RegisterClassExW.argtypes = [ctypes.POINTER(WNDCLASSEXW)]

        _user32.CreateWindowExW.restype = wintypes.HWND
        _user32.CreateWindowExW.argtypes = [
            wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            wintypes.HWND, wintypes.HMENU, wintypes.HINSTANCE, wintypes.LPVOID]

        _user32.DefWindowProcW.restype = LRESULT
        _user32.DefWindowProcW.argtypes = [
            wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]

        _user32.SendMessageW.restype = LRESULT
        _user32.SendMessageW.argtypes = [
            wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]

        _user32.GetMessageW.restype = wintypes.BOOL
        _user32.GetMessageW.argtypes = [
            ctypes.POINTER(MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]

        _user32.FindWindowW.restype = wintypes.HWND
        _user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]

        _user32.DestroyWindow.restype = wintypes.BOOL
        _user32.DestroyWindow.argtypes = [wintypes.HWND]

        _user32.PostQuitMessage.argtypes = [ctypes.c_int]

        _user32.SetTimer.restype = ctypes.c_void_p
        _user32.SetTimer.argtypes = [
            wintypes.HWND, ctypes.c_void_p, wintypes.UINT, ctypes.c_void_p]

        _user32.KillTimer.restype = wintypes.BOOL
        _user32.KillTimer.argtypes = [wintypes.HWND, ctypes.c_void_p]

        _user32.LoadCursorW.restype = wintypes.HANDLE
        _user32.LoadCursorW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR]

        _user32.GetSystemMetrics.restype = ctypes.c_int
        _user32.GetSystemMetrics.argtypes = [ctypes.c_int]

        _gdi32.CreateSolidBrush.restype = wintypes.HBRUSH
        _gdi32.CreateSolidBrush.argtypes = [wintypes.COLORREF]

        _gdi32.GetStockObject.restype = wintypes.HANDLE
        _gdi32.GetStockObject.argtypes = [ctypes.c_int]

        return True
    except Exception as e:          # pragma: no cover - 环境不支持时静默降级
        _STATE["error"] = repr(e)
        return False


def _wnd_proc(hwnd, msg, wparam, lparam):
    """窗口过程：处理关闭 + 定时器推进进度条。"""
    try:
        if msg == WM_CLOSE:
            _user32.DestroyWindow(hwnd)
            return 0
        if msg == WM_DESTROY:
            _user32.PostQuitMessage(0)
            return 0
        if msg == WM_TIMER:
            pb = _STATE.get("pb")
            if pb:
                # 0→100 循环走动，形成「正在启动」的持续动效
                _STATE["pos"] = (_STATE.get("pos", 0) + 4) % 101
                _user32.SendMessageW(pb, PBM_SETPOS, _STATE["pos"], 0)
            return 0
    except Exception:
        pass
    try:
        return _user32.DefWindowProcW(hwnd, msg, wparam, lparam)
    except Exception:
        return 0


def _splash_worker(text, title):
    """Splash 线程主体：建窗口 + 跑消息循环。"""
    global _WNDPROC_INST
    try:
        if not _bind():
            return
        _WNDPROC_INST = WNDPROC(_wnd_proc)     # 保持引用，防止被 GC

        hinstance = _kernel32.GetModuleHandleW(None)
        brush = _gdi32.CreateSolidBrush(0xFFFFFF)   # 白底（COLORREF）
        try:
            cursor = _user32.LoadCursorW(
                None, ctypes.cast(ctypes.c_void_p(IDC_ARROW), wintypes.LPCWSTR))
        except Exception:
            cursor = None

        wcx = WNDCLASSEXW()
        wcx.cbSize = ctypes.sizeof(WNDCLASSEXW)
        wcx.style = 0
        wcx.lpfnWndProc = _WNDPROC_INST
        wcx.cbClsExtra = 0
        wcx.cbWndExtra = 0
        wcx.hInstance = hinstance
        wcx.hIcon = None
        wcx.hCursor = cursor
        wcx.hbrBackground = brush
        wcx.lpszMenuName = None
        wcx.lpszClassName = SPLASH_CLASS
        wcx.hIconSm = None
        # 已存在同名类（同一进程重复调用）时忽略报错，直接用
        _user32.RegisterClassExW(ctypes.byref(wcx))

        sw = _user32.GetSystemMetrics(SM_CXSCREEN)
        sh = _user32.GetSystemMetrics(SM_CYSCREEN)
        x = max(0, (sw - WIN_W) // 2)
        y = max(0, (sh - WIN_H) // 2)

        hwnd = _user32.CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
            SPLASH_CLASS, title,
            WS_POPUP | WS_VISIBLE,
            x, y, WIN_W, WIN_H,
            None, None, hinstance, None)
        if not hwnd:
            _STATE["error"] = "CreateWindowExW failed"
            _STATE["ready"].set()
            return
        _STATE["hwnd"] = hwnd

        # 说明文字
        lbl = _user32.CreateWindowExW(
            0, "STATIC", text,
            WS_CHILD | WS_VISIBLE | SS_CENTER,
            20, 30, WIN_W - 40, 24, hwnd, None, hinstance, None)
        try:
            hfont = _gdi32.GetStockObject(DEFAULT_GUI_FONT)
            if lbl and hfont:
                _user32.SendMessageW(lbl, WM_SETFONT, hfont, 1)
        except Exception:
            pass

        # 进度条
        pb = _user32.CreateWindowExW(
            0, PROGRESS_CLASS, "",
            WS_CHILD | WS_VISIBLE,
            28, 74, WIN_W - 56, 14, hwnd, None, hinstance, None)
        if pb:
            _STATE["pb"] = pb
            try:
                _user32.SendMessageW(pb, PBM_SETRANGE, 0, (100 << 16))
            except Exception:
                pass
            try:
                _user32.SetTimer(hwnd, ctypes.c_void_p(TIMER_ID), TIMER_MS, None)
            except Exception:
                pass

        _STATE["ready"].set()

        # 消息循环（阻塞，直到窗口收到 WM_CLOSE / WM_DESTROY）
        msg = MSG()
        while _user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            _user32.TranslateMessage(ctypes.byref(msg))
            _user32.DispatchMessageW(ctypes.byref(msg))
    except Exception as e:          # pragma: no cover
        _STATE["error"] = repr(e)
        _STATE["ready"].set()
    finally:
        _STATE["hwnd"] = 0
        _STATE["pb"] = 0


# ---------------------------------------------------------------------------
# 对外接口
# ---------------------------------------------------------------------------
def should_show():
    """是否需要显示 Splash。

    仅在「没有真实控制台」时显示：双击 启动.exe（PyInstaller noconsole）
    或 pythonw 场景下才有意义；用户手动跑 启动.bat（有控制台、能看日志）
    时不弹，避免多余窗口干扰。
    """
    if not IS_WINDOWS:
        return False
    try:
        if getattr(sys, "frozen", False):
            return True
        return sys.stdout is None
    except Exception:
        return False


def show(text=DEFAULT_TEXT, title=DEFAULT_TITLE, wait=3.0):
    """启动 Splash（非阻塞）。返回是否成功创建窗口。

    内部起一个 daemon 线程跑 Win32 消息循环；本函数等待窗口创建完成
    （最多 ``wait`` 秒）后返回，确保调用方继续往下走时窗口已经可见。
    """
    if not IS_WINDOWS:
        return False
    if not _bind():
        return False
    try:
        th = _STATE.get("thread")
        if th is not None and th.is_alive():
            return True
        _STATE["ready"].clear()
        _STATE["hwnd"] = 0
        _STATE["pos"] = 0
        th = threading.Thread(
            target=_splash_worker, args=(text, title),
            daemon=True, name="xn-splash")
        _STATE["thread"] = th
        th.start()
        if not _STATE["ready"].wait(wait):
            return False
        return bool(_STATE.get("hwnd"))
    except Exception:
        return False


def close():
    """关闭 Splash（供 UI 进程跨进程调用）。返回是否找到了窗口。

    按窗口类名 FindWindow 定位到 bootstrap 进程里的 Splash，发 WM_CLOSE。
    找不到（例如 Splash 已被关或 bootstrap 走的控制台模式）返回 False，
    调用方无需关心。
    """
    if not IS_WINDOWS:
        return False
    try:
        if not _bind():
            return False
        hwnd = _user32.FindWindowW(SPLASH_CLASS, None)
        if not hwnd:
            return False
        _user32.SendMessageW(hwnd, WM_CLOSE, 0, 0)
        return True
    except Exception:
        return False


def last_error():
    """返回最近一次 Splash 相关错误（用于排查），无错误返回 None。"""
    return _STATE.get("error")


# ---------------------------------------------------------------------------
# 自测：python app/splash.py   → 显示 3 秒后自动关闭
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    if not IS_WINDOWS:
        print("非 Windows 平台，Splash 不可用")
        sys.exit(0)
    ok = show()
    print("show() ->", ok, "hwnd =", _STATE.get("hwnd"),
          "error =", last_error())
    if ok:
        import time
        time.sleep(3)
        print("close() ->", close())
