"""启动器自动更新节点补丁。

背景：
  comfyui-kjnodes 的 MiniMaxH3/WanVideo/LTX2 显存优化 Sage 注意力节点
  要求 sageattention 的旧内部符号(per_thread_int8_triton 等)，而 pip 上
  能装到的 1.0.6 正式版已移除这些符号，导致节点一执行就崩溃
  (RuntimeError: sageattention is not new enough version ...)。

  comfyui-kjnodes 是启动器「静态捆绑」的节点(非 git/Manager 管理)，
  所以修复应随启动器分发给所有用户，而不只是改本地一份。

策略(安全、幂等、绝不覆盖用户数据)：
  对受管节点文件，按标记判定状态：
    - 含 FIXED_MARKER          -> 已修复，跳过
    - 含 BUGGY_MARKER          -> 旧版带 bug，用受管副本整体覆盖(先备份)
    - 两者皆无(未知版本)       -> 跳过，不覆盖用户的其他/新版节点
  每次启动都跑一次，幂等无副作用。
"""

import os
import shutil
import logging

# 标记串：节点文件被修复后一定含 SAGEATTN_AVAILABLE(模块级定义)；
# 旧版带 bug 的文件一定含这条 RuntimeError 文案。
# 二者互斥 —— 修复版已把 raise 改成 if not SAGEATTN_AVAILABLE: warning+return。
FIXED_MARKER = "SAGEATTN_AVAILABLE"
BUGGY_MARKER = (
    "sageattention is not new enough version or could not determine CUDA architecture"
)

# 受管修复副本：随启动器分发，位于 app/assets/node_patches/<相对名>
_MANAGED = {
    "ComfyUI/custom_nodes/comfyui-kjnodes/nodes/ltxv_nodes.py": (
        "app/assets/node_patches/ltxv_nodes.py"
    ),
}


def apply_node_patches(base_dir):
    """对 base_dir 下的受管节点做安全修复。base_dir 即启动器根(BASE)。"""
    if not base_dir or not os.path.isdir(base_dir):
        return
    for rel_target, rel_managed in _MANAGED.items():
        target = os.path.join(base_dir, *rel_target.split("/"))
        managed = os.path.join(base_dir, *rel_managed.split("/"))
        if not os.path.isfile(target) or not os.path.isfile(managed):
            continue
        try:
            with open(target, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
        except Exception as e:
            logging.warning("节点补丁: 读取 %s 失败: %s", rel_target, e)
            continue

        if FIXED_MARKER in content:
            # 已是修复版，无需动作
            continue
        if BUGGY_MARKER not in content:
            # 未知版本(既无修复标记也无 bug 标记)：不覆盖，避免破坏用户自定义/新版节点
            logging.info("节点补丁: %s 版本未知，跳过自动修复(不覆盖)", rel_target)
            continue

        # 旧版带 bug -> 用受管副本整体覆盖
        try:
            bak = target + ".nodefix_bak"
            if os.path.exists(bak):
                os.remove(bak)
            shutil.copy2(target, bak)
            shutil.copy2(managed, target)
            logging.info(
                "节点补丁: 已自动修复 %s (原文件备份为 %s.nodefix_bak)",
                rel_target, rel_target,
            )
        except Exception as e:
            logging.warning("节点补丁: 修复 %s 失败: %s", rel_target, e)
