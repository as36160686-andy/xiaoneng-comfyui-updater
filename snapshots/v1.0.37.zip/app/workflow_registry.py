# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · 本地工作流登记。

负责记录「最近打开的本地工作流」路径，供主界面「打开本地工作流」使用。
工作流文件通常是：
  - .json  （ComfyUI 导出的 API/完整工作流）
  - .png   （ComfyUI 带嵌入工作流信息的预览图）
登记信息持久化在 包/app/workflows.json。
"""
import os
import json

APP_DIR = os.path.dirname(os.path.abspath(__file__))
_REG_PATH = os.path.join(APP_DIR, "workflows.json")
_MAX_RECENT = 10

VALID_EXT = (".json", ".png", ".latent", ".webp")


def is_workflow_file(path):
    if not path or not os.path.isfile(path):
        return False
    return path.lower().endswith(VALID_EXT)


def _load():
    try:
        if os.path.isfile(_REG_PATH):
            with open(_REG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
    except Exception:
        pass
    return []


def _save(items):
    try:
        with open(_REG_PATH, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def add_recent(path):
    """把工作流路径加入最近列表（去重、置顶）。"""
    if not is_workflow_file(path):
        return
    items = [p for p in _load() if os.path.normcase(p) != os.path.normcase(path)]
    items.insert(0, path)
    _save(items[:_MAX_RECENT])


def list_recent():
    """返回仍存在的本地工作流路径列表。"""
    return [p for p in _load() if is_workflow_file(p)]


def clear_recent():
    _save([])
