# -*- coding: utf-8 -*-
"""小能ComfyUI启动器 · 主界面（PySide6）。

布局：顶部标题+状态一行；下方左右分栏
  - 左侧：竖向主操作按钮（打开ComfyUI / 启动服务 / 重启服务 / 停止服务 /
          更新 / 启动参数 / Git 镜像 / HF 镜像 / 工作流 / 插件 / 终端 / 关于 / 关闭）
  - 右侧：设置网格（ComfyUI 地址 / 模型路径）+ 日志区；模型路径行含「默认 / 选择」按钮
  - 工作流：左侧「工作流」按钮弹出 WorkflowManagerDialog，可查看 / 添加（选
          择外部 .json 文件导入）/ 重命名 / 删除工作流目录下的工作流文件

所有按钮带悬停/按下视觉反馈（apply_button_fx）。
"""
import os
import re
import sys
import shlex
import time
import webbrowser
import subprocess
import shutil
import stat
import json

from PySide6.QtWidgets import (
    QWidget, QLabel, QLineEdit, QPushButton, QComboBox, QPlainTextEdit,
    QGridLayout, QHBoxLayout, QVBoxLayout, QFileDialog, QMessageBox,
    QApplication, QDialog, QListWidget, QListWidgetItem, QAbstractItemView,
    QInputDialog, QGroupBox, QCheckBox, QProgressBar, QSystemTrayIcon, QMenu,
    QTextBrowser,
)
from PySide6.QtCore import Qt, QTimer, QThread, Signal, QSize, QStandardPaths, QUrl
from PySide6.QtGui import QColor, QTextCursor, QIcon

APP_DIR = os.path.dirname(os.path.abspath(__file__))
_PKG_ROOT = os.path.dirname(APP_DIR)
if _PKG_ROOT not in sys.path:
    sys.path.insert(0, _PKG_ROOT)

# ANSI 颜色转义序列；ComfyUI 子进程日志含颜色码，直接 append 到 QPlainTextEdit
# 会显示成 "←[32m" 之类，所以 tail 日志时统一剥掉。
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def _app_icon_path():
    """返回启动器图标路径（PNG/ICO 均可）；找不到则返回空字符串。"""
    for name in ("icon.ico", "icon.png"):
        p = os.path.join(APP_DIR, "assets", name)
        if os.path.isfile(p):
            return p
    return ""


def _apply_windows_taskbar_icon(widget):
    """在 Windows 上把任务栏图标设为 ICO（解决 pythonw 启动时显示通用窗口图标的问题）。

    需要配合模块顶层对 ``SetCurrentProcessExplicitAppUserModelID`` 的调用：
    该 ID 必须在创建任何窗口之前设置，否则任务栏仍会归到 pythonw.exe 组。
    """
    if sys.platform != "win32":
        return
    icon_path = _app_icon_path()
    if not icon_path or not icon_path.lower().endswith(".ico"):
        return
    try:
        import ctypes
        from ctypes import wintypes

        hwnd = widget.winId()
        if not hwnd:
            return
        # LR_LOADFROMFILE 要求 hInst 为 NULL，否则 LoadImageW 会失败
        hinst = ctypes.c_void_p(0)
        IMAGE_ICON = 1
        LR_LOADFROMFILE = 0x00000010
        LR_DEFAULTSIZE = 0x00000040
        LR_SHARED = 0x00008000
        WM_SETICON = 0x80
        ICON_SMALL = 0
        ICON_BIG = 1
        hicon = ctypes.windll.user32.LoadImageW(
            hinst, icon_path, IMAGE_ICON, 0, 0,
            LR_LOADFROMFILE | LR_DEFAULTSIZE | LR_SHARED)
        if hicon:
            ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, hicon)
            ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, hicon)
    except Exception:
        pass


def _set_process_app_user_model_id():
    """在进程级设置 Windows AppUserModelID，必须在 QApplication/窗口创建前调用。"""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "XiaoNengComfyUI.Launcher")
    except Exception:
        pass


# 模块导入时即设置 AUMID，保证后续 QApplication 创建前已完成分组
_set_process_app_user_model_id()


def open_folder_in_explorer(path):
    """在系统文件管理器中打开指定目录（Windows 下用资源管理器定位）。

    返回 True 表示已尝试打开；目录不存在或打开失败时弹窗提示并返回 False。
    无 GUI（如测试）时可 monkeypatch os.startfile 捕获调用，不影响逻辑。
    """
    path = os.path.abspath(path)
    if not os.path.isdir(path):
        QMessageBox.warning(None, "打开失败", "目录不存在：\n%s" % path)
        return False
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.run(["open", path], check=False)
        else:
            subprocess.run(["xdg-open", path], check=False)
        return True
    except Exception as e:
        QMessageBox.warning(None, "打开失败", "无法打开文件夹：\n%s\n%s" % (path, e))
        return False


import config
import comfy_launch
import updater


# ---------------------------------------------------------------------------
# 插件仓库解析：不依赖本地 .git 也能定位仓库地址与当前版本
# （对齐 ComfyUI-Manager：节点数据库 custom-node-list.json 匹配 +
#  pyproject.toml 的 project.version / project.urls）
# ---------------------------------------------------------------------------
_CN_DB_CACHE = None


def _norm_key(s):
    """把插件名 / 标题 / 仓库名归一化，便于模糊匹配。"""
    s = (s or "").lower()
    s = re.sub(r'^comfyui[_-]?', '', s)
    s = re.sub(r'[_-]?customnodes?$', '', s)
    s = re.sub(r'[-_\s]+', '-', s).strip('-')
    return s


def _load_cn_db():
    """加载 ComfyUI-Manager 的 custom-node-list.json，返回 归一化key -> node。"""
    global _CN_DB_CACHE
    if _CN_DB_CACHE is not None:
        return _CN_DB_CACHE
    mapping = {}
    candidates = [
        os.path.join(comfy_launch.COMFY_DIR, "..", "standalone-env", "Lib",
                     "site-packages", "comfyui_manager", "custom-node-list.json"),
        os.path.join(_PKG_ROOT, "standalone-env", "Lib", "site-packages",
                     "comfyui_manager", "custom-node-list.json"),
        os.path.join(comfy_launch.COMFY_DIR, ".venv", "Lib", "site-packages",
                     "comfyui_manager", "custom-node-list.json"),
    ]
    for p in candidates:
        p = os.path.normpath(p)
        if not os.path.isfile(p):
            continue
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            continue
        for node in data.get("custom_nodes", []):
            ref = node.get("reference", "") or (node.get("files") or [""])[0]
            base = os.path.basename(ref.rstrip("/")) if ref else ""
            keys = set()
            for k in (node.get("id", ""), node.get("title", ""), base):
                if k:
                    keys.add(_norm_key(k))
                    keys.add(_norm_key(k).replace("comfyui-", ""))
            for k in keys:
                if k:
                    mapping.setdefault(k, node)
        _CN_DB_CACHE = mapping
        return mapping
    _CN_DB_CACHE = mapping
    return mapping


def _cn_reference_for(folder_name):
    e = _load_cn_db().get(_norm_key(folder_name))
    if e:
        ref = e.get("reference", "") or (e.get("files") or [""])[0]
        if ref:
            return ref
    return ""


def _read_pyproject(folder):
    """解析 pyproject.toml，返回 (repo_url, version)。

    version 优先用 tomllib（标准 [project] 表），URL 用正则兜底——
    因为不少插件的 [project.urls] 键名大小写不统一（如 Repository），
    tomllib 大小写敏感会漏掉，正则 re.I 更稳。
    """
    url = ""
    ver = ""
    pyproject = os.path.join(folder, "pyproject.toml")
    if not os.path.isfile(pyproject):
        return url, ver
    try:
        txt = open(pyproject, "r", encoding="utf-8", errors="ignore").read()
    except Exception:
        return url, ver
    try:
        import tomllib
        with open(pyproject, "rb") as f:
            data = tomllib.load(f)
        proj = data.get("project", {}) or {}
        ver = str(proj.get("version", "") or "")
        urls = proj.get("urls", {}) or {}
        for key in ("repository", "homepage", "documentation", "url"):
            if urls.get(key):
                url = urls[key]
                break
        if not url and isinstance(proj.get("repository"), str):
            url = proj["repository"]
        if not url and isinstance(proj.get("homepage"), str):
            url = proj["homepage"]
    except Exception:
        pass
    # 正则兜底（覆盖 tomllib 未命中 url / 非标准结构 / 大小写差异）
    m = re.findall(r'(?:homepage|repository|url|documentation|project_url)\s*[:=]\s*["\']([^"\']+)', txt, re.I)
    if not url and m:
        url = m[0]
    if not ver:
        v = re.findall(r'version\s*[:=]\s*["\']([^"\']+)', txt)
        if v:
            ver = v[0]
    return url, ver


def _git_remote_url(folder):
    git_config = os.path.join(folder, ".git", "config")
    if not os.path.isfile(git_config):
        return ""
    try:
        import configparser
        cp = configparser.ConfigParser(strict=False)
        cp.read(git_config)
        for sec in cp.sections():
            if sec.startswith("remote "):
                u = cp.get(sec, "url", fallback="")
                if u:
                    return u
    except Exception:
        pass
    return ""


def _mirror_url(url):
    """按用户设置的 Git 镜像改写 github.com 地址（境内走 ghfast.top）。"""
    if not url:
        return url
    if "github.com" in url and config.get_git_mirror() == "china":
        return "https://ghfast.top/" + url.lstrip("/")
    return url


def force_rmtree(path):
    """删除目录树；Windows 下 .git 对象文件是只读的，需先清掉只读属性。

    shutil.rmtree(ignore_errors=True) 遇到只读文件会静默失败并留下垃圾目录，
    因此这里用 onerror 回调补 chmod 后重试。返回是否彻底删除。
    """
    if not path or not os.path.exists(path):
        return True

    def _on_error(func, fpath, exc_info):
        try:
            os.chmod(fpath, stat.S_IWRITE)
        except Exception:
            pass
        try:
            func(fpath)
        except Exception:
            pass

    try:
        shutil.rmtree(path, onerror=_on_error)
    except Exception:
        pass
    # 个别情况下（文件被占用）仍未删掉时再试一次
    if os.path.exists(path):
        try:
            shutil.rmtree(path, onerror=_on_error)
        except Exception:
            pass
    return not os.path.exists(path)


def _kill_process_tree(pid):
    """Windows 下强制结束进程树。

    git 会派生子进程（git-remote-https 等）继承输出管道，只 kill 父进程时
    subprocess 的 communicate() 会一直等管道关闭而卡死，必须整树杀掉。
    """
    try:
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                       timeout=15)
        return
    except Exception:
        pass
    try:
        os.kill(pid, getattr(__import__("signal"), "SIGTERM", 15))
    except Exception:
        pass


def git_run(args, cwd=None, timeout=300, env=None):
    """执行 git 命令并强制超时，返回 (returncode, output)。

    相比 subprocess.run(timeout=...)，这里在超时时会杀掉整棵进程树，
    避免 Windows 上因孙进程持有管道导致的永久阻塞。
    """
    env = env or comfy_launch._comfy_env()
    if cwd and not os.path.isdir(cwd):
        cwd = None
    try:
        p = subprocess.Popen(
            args, cwd=cwd, env=env, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, errors="replace",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as e:
        return 1, "git 启动失败：%s" % e
    try:
        out, err = p.communicate(timeout=timeout)
        return p.returncode, ((out or "") + (err or ""))
    except subprocess.TimeoutExpired:
        _kill_process_tree(p.pid)
        try:
            out, err = p.communicate(timeout=10)
        except Exception:
            out, err = "", ""
        msg = ((out or "") + (err or "")).strip()
        return 1, (msg + "\n[超时] 操作超过 %d 秒已终止" % timeout).strip()


# git 操作超时（秒）
NET_TIMEOUT = 60     # ls-remote 等网络查询
GIT_TIMEOUT = 300    # fetch / pull / checkout
CLONE_TIMEOUT = 900  # 完整克隆（大仓库较慢）


def _remote_latest_tag(url, timeout=None):
    """查询远程最新 tag（按数字段排序）；无 tag 返回空串。"""
    if not url:
        return ""
    rc, out = git_run([comfy_launch.GIT_EXE, "ls-remote", "--tags", url],
                      timeout=timeout or NET_TIMEOUT)
    if rc != 0:
        return ""
    tags = []
    for line in (out or "").splitlines():
        parts = line.split()
        if len(parts) < 2:
            continue
        ref = parts[1]
        if not ref.startswith("refs/tags/"):
            continue
        t = ref[len("refs/tags/"):]
        if t.endswith("^{}"):
            t = t[:-3]
        if t and t not in tags:
            tags.append(t)
    if not tags:
        return ""
    def key(v):
        nums = re.findall(r"\d+", v)
        return tuple(int(x) for x in nums) if nums else (0,)
    return sorted(tags, key=key, reverse=True)[0]


def clone_swap_plugin(path, repo_url="", ref="", log=None):
    """把「没有本地 .git」的插件目录替换为指定版本的全新克隆。

    便携包剥离了 .git，直接 git init + checkout 会因「未跟踪文件将被覆盖」
    而失败，因此采用与 ComfyUI-Manager 相同的「新克隆替换」策略：
    克隆到临时目录 → 旧目录改名备份 → 新目录就位 → 删除备份；任一步失败
    都会回滚，保证原目录不被破坏。

    ref 为空表示取远程最新版本（优先最新 tag，无 tag 则默认分支 HEAD）。
    返回 (ok, detail)。
    """
    def emit(msg):
        if log:
            try:
                log(msg)
            except Exception:
                pass

    git = comfy_launch.GIT_EXE
    url = repo_url or _git_remote_url(path)
    if not url:
        return False, "未识别仓库地址"
    if not ref:
        ref = _remote_latest_tag(url)
    name = os.path.basename(path.rstrip("\\/"))
    parent = os.path.dirname(path.rstrip("\\/"))
    stamp = str(os.getpid())
    tmp = os.path.join(parent, ".__tmp_%s_%s" % (name, stamp))
    bak = os.path.join(parent, ".__bak_%s_%s" % (name, stamp))
    for d in (tmp, bak):
        if os.path.isdir(d):
            force_rmtree(d)
    moved = False
    try:
        if ref:
            emit("正在拉取版本 %s …" % ref)
            rc, out = git_run([git, "clone", "--depth", "1", "--branch", ref, url, tmp],
                              timeout=CLONE_TIMEOUT)
            if rc != 0:
                force_rmtree(tmp)
                emit("浅克隆失败，改用完整克隆 …")
                rc, out = git_run([git, "clone", url, tmp], timeout=CLONE_TIMEOUT)
                if rc == 0:
                    rc, out = git_run([git, "checkout", "-f", ref], cwd=tmp, timeout=GIT_TIMEOUT)
        else:
            emit("正在克隆最新版本 …")
            rc, out = git_run([git, "clone", "--depth", "1", url, tmp], timeout=CLONE_TIMEOUT)
        if rc != 0 or not os.path.isdir(os.path.join(tmp, ".git")):
            return False, (out or "克隆失败")[:300]
        if os.path.isdir(path):
            os.rename(path, bak)
            moved = True
        try:
            os.rename(tmp, path)
        except Exception as e:
            if moved and not os.path.isdir(path):
                os.rename(bak, path)
                moved = False
            return False, "替换目录失败：%s" % e
        return True, ref or "最新"
    finally:
        force_rmtree(tmp)
        if os.path.isdir(bak):
            force_rmtree(bak)


def resolve_plugin_repo(folder):
    """返回 (repo_url, current_version, is_git)。

    - repo_url：优先本地 .git remote，其次 pyproject，再次 CM 节点数据库
    - current_version：本地 git describe → pyproject version → ''
    - is_git：目录是否含 .git
    """
    is_git = os.path.isdir(os.path.join(folder, ".git")) or os.path.isfile(os.path.join(folder, ".git"))
    repo_url = _git_remote_url(folder)
    cur = ""
    if is_git:
        try:
            rc, out = git_run([comfy_launch.GIT_EXE, "describe", "--tags", "--always"],
                              cwd=folder, timeout=20)
            cur = out.strip() or "unknown"
        except Exception:
            cur = "unknown"
    pu, pv = _read_pyproject(folder)
    if not repo_url:
        repo_url = pu
    if not cur and pv:
        cur = pv
    if not repo_url:
        repo_url = _cn_reference_for(os.path.basename(folder.rstrip(os.sep)))
    return repo_url, cur, is_git


# ---------------------------------------------------------------------------
# 按钮视觉反馈工具
# ---------------------------------------------------------------------------
def _parse_hex(s):
    s = (s or "").strip().lstrip("#")
    if len(s) == 3:
        s = "".join(c * 2 for c in s)
    if len(s) != 6:
        return None
    try:
        return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return None


def _to_hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(v))) for v in rgb)


def _lighten(hexcol, amt):
    c = _parse_hex(hexcol)
    if not c:
        return hexcol
    return _to_hex([v + (255 - v) * amt for v in c])


def _darken(hexcol, amt):
    c = _parse_hex(hexcol)
    if not c:
        return hexcol
    return _to_hex([v * (1 - amt) for v in c])


def _extract_prop(ss, prop):
    m = re.search(r"%s\s*:\s*([^;]+)" % re.escape(prop), ss or "")
    return m.group(1).strip() if m else None


def _btn_fx_stylesheet(existing):
    """根据既有样式自动派生带 :hover / :pressed 的样式。"""
    base = _extract_prop(existing, "background")
    color = _extract_prop(existing, "color") or "#ffffff"
    if base and _parse_hex(base):
        hover = _lighten(base, 0.18)
        press = _darken(base, 0.18)
        return (
            "QPushButton{background:%s;color:%s;font-weight:bold;"
            "padding:8px 18px;border-radius:6px;border:none;}"
            "QPushButton:hover{background:%s;}"
            "QPushButton:pressed{background:%s;padding-top:10px;padding-bottom:6px;}"
            "QPushButton:disabled{background:#9aa3ad;color:#f0f0f0;}"
        ) % (base, color, hover, press)
    # 无底色：浅灰底 + 悬停浅蓝 + 按下深蓝
    return (
        "QPushButton{background:#e8edf2;color:#1f3a5f;border-radius:6px;"
        "padding:5px 12px;}"
        "QPushButton:hover{background:#d6e4f0;}"
        "QPushButton:pressed{background:#bcd2e6;padding-top:7px;padding-bottom:3px;}"
        "QPushButton:disabled{color:#9aa0a6;}"
    )


def apply_button_fx(widget):
    """给 widget 下所有 QPushButton 加悬停/按下反馈与手型光标。"""
    for btn in widget.findChildren(QPushButton):
        btn.setStyleSheet(_btn_fx_stylesheet(btn.styleSheet()))
        btn.setCursor(Qt.PointingHandCursor)


# ---------------------------------------------------------------------------
# 停止工作线程
# ---------------------------------------------------------------------------
class StopComfyWorker(QThread):
    finished_sig = Signal(bool)
    log_sig = Signal(str)

    def run(self):
        def cb(m):
            self.log_sig.emit(m)
        try:
            ok = comfy_launch.stop_comfyui(timeout=5, logger=cb)
        except Exception as e:
            self.log_sig.emit("停止异常：%s" % e)
            ok = False
        self.finished_sig.emit(ok)


class StartupProbeWorker(QThread):
    """启动后探测 ComfyUI 状态、清理包内残留进程（**工作线程**执行）。

    为什么必须在线程里跑：这里含 HTTP 探测、端口探测，以及 WMI 全进程扫描
    （``_package_runtime_procs``），整体耗时可达数秒。若在主线程执行会阻塞
    Qt 事件循环，用户看到的就是「窗口刚显示出来，一拖动就提示未响应」。

    所有日志/状态都通过信号送回主线程，绝不在工作线程直接碰 Qt 控件
    （Qt 要求 UI 操作只能在主线程，跨线程直接操作会崩溃或渲染异常）。
    """

    log_sig = Signal(str)
    status_sig = Signal(bool)

    def run(self):
        def cb(m):
            self.log_sig.emit(m)
        try:
            url = config.get_comfy_url()
            if comfy_launch.is_ready(url):
                cb("✅ ComfyUI 已在运行：%s" % url)
                self.status_sig.emit(True)
                return
            self.status_sig.emit(False)
            # 关键：仅靠 HTTP 探测失败不足以判定「有残留」。
            # 若服务端口仍在被监听，说明 ComfyUI 很可能还在跑（或正在启动中），
            # 此时不应把包内 .venv 进程当残留清理，否则会误杀活着的 ComfyUI 服务。
            # 只有「端口无人监听 + 存在包内 .venv 进程」才是真正的残留。
            _, port = comfy_launch._host_port(url)
            if comfy_launch._port_in_use(port):
                cb("ℹ️ 端口 %s 已被占用，ComfyUI 可能仍在运行或正在启动，"
                   "跳过残留进程清理（不误杀活服务）。" % port)
                return
            # 过滤掉启动器自身进程（其 UI 也运行在 .venv 的 python 下），
            # 只保留真正的 ComfyUI 残留
            all_procs = comfy_launch._package_runtime_procs()
            stray = [(pid, name, cmd) for (pid, name, cmd) in all_procs
                     if not comfy_launch._is_launcher_proc(cmd)
                     and pid not in comfy_launch._launcher_pids()]
            if stray:
                for pid, name, cmd in stray:
                    cb("🧹 检测到包内残留进程 PID=%s NAME=%s CMD=%s"
                       % (pid, name, (cmd or "")[:120]))
                txt = ",".join(str(p[0]) for p in stray)
                cb("⚠ 服务未运行且端口 %s 无进程监听，发现 %d 个包内残留进程"
                   "（PID=%s），正在自动清理…" % (port, len(stray), txt))
                comfy_launch.kill_stray_comfy_processes(logger=cb)
                skip = comfy_launch._launcher_pids()
                remain = [p for p in comfy_launch._package_runtime_pids()
                          if p not in skip]
                if not remain:
                    cb("✅ 包内残留进程已清理，custom_nodes 文件占用已释放，"
                       "可安全复制/替换插件。")
                else:
                    cb("⚠ 残留进程 PID=%s 仍未能结束，请点「停止服务」或到任务管理器"
                       "结束后再复制/替换插件。" % ",".join(str(p) for p in remain))
            else:
                cb("ℹ️ ComfyUI 未运行，且无包内残留进程，无需清理。")
        except Exception as e:
            cb("后端探测异常：%s" % e)
            self.status_sig.emit(False)


# ---------------------------------------------------------------------------
# 插件依赖注册（pip 线程）
# ---------------------------------------------------------------------------
class PluginDepWorker(QThread):
    """扫描「实际生效的插件目录」下所有插件的依赖声明，并安装缺失的依赖。

    - 插件目录固定为包内真实目录 ComfyUI/custom_nodes（不再使用外部映射）。
      启动时若包内仍存在旧版目录联接(junction)，会先 sync_plugin_dir 恢复为真实目录。
    - install=False 时只检查不安装（用于快速确认新插件是否被注册）。
    - 结果逐条通过 log_sig 输出，便于用户确认每个新插件的注册状态。
    """

    log_sig = Signal(str)
    done_sig = Signal(bool, str, list)   # ok, 汇总文本, [(插件, 状态, 详情)]

    def __init__(self, install=True, parent=None):
        super().__init__(parent)
        self.install = install

    # ---- 工具 ----
    def _emit(self, msg):
        self.log_sig.emit(msg)

    @staticmethod
    def _norm(spec):
        return comfy_launch._pkg_name(spec).lower().replace("_", "-")

    # ---- 主流程 ----
    def run(self):
        results = []
        try:
            comfy_launch.sync_plugin_dir(logger=self._emit)
            pdir = comfy_launch.effective_plugin_dir()
            self._emit("🧩 插件依赖注册 · 生效目录：%s" % pdir)

            pairs = comfy_launch.scan_plugin_requirements(pdir)
            if not pairs:
                self._emit("ℹ 目录下未发现插件或插件均未声明依赖")
                self.done_sig.emit(True, "无需注册：未发现依赖声明", [])
                return

            all_specs = []
            for _n, reqs, _u in pairs:
                for r in reqs:
                    if r not in all_specs:
                        all_specs.append(r)

            missing, qerr = comfy_launch.missing_packages(all_specs)
            if qerr:
                self._emit("❌ 依赖查询失败（venv 探测异常）：%s" % qerr)
                self._emit("   ⚠ 未做任何安装/改动，请检查 ComfyUI venv 是否完整（可重装环境后重试）。")
                self.done_sig.emit(False, "依赖查询失败：%s" % qerr, results)
                return
            missing, conflicts = comfy_launch.dedupe_specs(missing)
            for a, b in conflicts:
                self._emit("   ⚠ 版本冲突，已保留 %s（忽略 %s），如需请手动调整" % (a, b))
            # 可选依赖（如 cupy-wheel）单独归类：不计入待注册、不阻塞安装
            optional_missing = [m for m in missing if comfy_launch._is_optional_pkg(m)]
            missing = [m for m in missing if m not in optional_missing]
            if optional_missing:
                self._emit("   ⚙ 可选依赖（跳过安装，不影响核心功能）：%s"
                           % "、".join(sorted(set(optional_missing))))
            missing_keys = {self._norm(m) for m in missing}

            missing_set = set(missing)
            for name, reqs, urls in pairs:
                if not reqs and not urls:
                    results.append((name, "无依赖声明", ""))
                    continue
                miss = [r for r in reqs if r in missing_set]
                dropped = [r for r in reqs
                           if r not in missing_set and self._norm(r) in missing_keys]
                if dropped:
                    miss = miss + ["(冲突忽略:%s)" % ", ".join(dropped)]
                if miss:
                    results.append((name, "待注册", ", ".join(miss)))
                else:
                    extra = ("；另有 %d 项需手动安装：%s" % (len(urls), "、".join(urls))) if urls else ""
                    results.append((name, "已注册", "依赖 %d 项%s" % (len(reqs), extra)))

            self._emit("📋 共 %d 个插件，%d 项可自动安装的依赖；待注册 %d 项。" % (
                len(pairs), len(all_specs), len(missing)))
            for name, status, detail in results:
                if status == "已注册":
                    self._emit("   ✅ %s：已注册（%s）" % (name, detail))
                elif status == "待注册":
                    self._emit("   ➕ %s：待注册 → %s" % (name, detail))
                else:
                    self._emit("   － %s：%s" % (name, status))
            for name, reqs, urls in pairs:
                if urls:
                    self._emit("   ⚠ %s：含 %d 项 VCS/URL 依赖，需手动安装 → %s" % (
                        name, len(urls), "、".join(urls)))

            if not missing:
                self.done_sig.emit(
                    True,
                    "✅ 插件依赖检查完成：%d 个插件的依赖均已注册，无需安装" % len(pairs),
                    results)
                return

            if not self.install:
                self.done_sig.emit(
                    True,
                    "⚠ 有 %d 项依赖未注册（仅检查模式，未安装）：%s" % (
                        len(missing), ", ".join(missing)),
                    results)
                return

            ok, detail = comfy_launch.install_packages(missing, logger=self._emit)
            if not ok:
                self._emit("❌ 依赖安装失败：%s" % detail)
                self.done_sig.emit(
                    False,
                    "❌ 依赖注册失败（%d 项未完成）：%s" % (len(missing), detail),
                    results)
                return

            # 安装后复核
            still, _ = comfy_launch.missing_packages(missing)
            still_keys = {self._norm(s) for s in still}
            ok_cnt = fail_cnt = 0
            final = []
            for name, status, detail2 in results:
                if status != "待注册":
                    final.append((name, status, detail2))
                    continue
                miss = [r for r in self._reqs_of(pairs, name)
                        if self._norm(r) in still_keys]
                if miss:
                    fail_cnt += 1
                    final.append((name, "注册失败", ", ".join(miss)))
                else:
                    ok_cnt += 1
                    final.append((name, "新注册", detail2))
            if still:
                self._emit("⚠ 仍有 %d 项未注册：%s" % (len(still), ", ".join(still)))
            self.done_sig.emit(
                not still,
                "✅ 依赖注册完成：新增注册 %d 个插件 / %d 项依赖%s" % (
                    ok_cnt, len(missing) - len(still),
                    ("，失败 %d 项" % fail_cnt) if fail_cnt else ""),
                final)
        except Exception as e:
            self._emit("❌ 依赖注册异常：%s" % e)
            self.done_sig.emit(False, "❌ 依赖注册异常：%s" % e, results)

    @staticmethod
    def _reqs_of(pairs, name):
        for item in pairs:
            if item[0] == name:
                return item[1]
        return []


# ---------------------------------------------------------------------------
# 插件版本管理（git 线程）
# ---------------------------------------------------------------------------
class PluginVersionWorker(QThread):
    """在后台执行单个插件目录的 git 操作。

    支持两类插件：
      - 含本地 .git 的（正常 git 流程）
      - 不含 .git 的（由便携包剥离）：自动 git init 并关联远程，使其同样可被
        版本管理（与 ComfyUI-Manager 的「重新克隆」行为一致）。
    """
    log_sig = Signal(str)
    done_sig = Signal(bool, str, str)  # (ok, action, detail)

    def __init__(self, path, action, ref="", repo_url=""):
        super().__init__()
        self.path = path
        self.action = action  # "fetch" | "pull" | "checkout" | "ls-remote" | "upgrade"
        self.ref = ref
        self.repo_url = repo_url  # 镜像化后的远程地址

    @staticmethod
    def _semver_max(tags):
        def key(v):
            nums = re.findall(r"\d+", v)
            return tuple(int(x) for x in nums) if nums else (0,)
        return sorted(tags, key=key, reverse=True)[0]

    # 超时（秒）：网络查询短一些，克隆允许较久；避免网络异常时永久卡死
    NET_TIMEOUT = 60     # 网络查询（ls-remote）
    GIT_TIMEOUT = 300    # fetch / pull / checkout
    CLONE_TIMEOUT = 900  # clone_swap_plugin 内部使用模块常量，这里仅作记录

    def _run(self, args, cwd=None, timeout=None):
        env = comfy_launch._comfy_env()
        work_dir = cwd or self.path
        # 空字符串 / 不存在的 cwd 会让 Windows 抛 WinError 123，必须兜底
        if not work_dir or not os.path.isdir(work_dir):
            try:
                work_dir = os.getcwd()
            except Exception:
                work_dir = None
        rc, out = git_run(args, cwd=work_dir, timeout=timeout or self.GIT_TIMEOUT)
        out = out.strip()
        if out:
            self.log_sig.emit(out[-800:])
        return rc == 0, out

    def _remote_origin(self):
        ok, out = self._run([comfy_launch.GIT_EXE, "remote", "-v"])
        if ok:
            for line in out.splitlines():
                parts = line.split()
                if len(parts) >= 2 and "fetch" in line:
                    return parts[1]
        return ""

    def _is_git(self):
        git_dir = os.path.join(self.path, ".git")
        return os.path.isdir(git_dir) or os.path.isfile(git_dir)

    def _clone_swap(self, ref):
        """无本地 .git 时的版本切换（详见 clone_swap_plugin）。"""
        return clone_swap_plugin(self.path, self.repo_url, ref, self.log_sig.emit)

    def run(self):
        try:
            git = comfy_launch.GIT_EXE
            if self.action == "ls-remote":
                url = self.repo_url or self._remote_origin()
                if not url:
                    self.done_sig.emit(False, "ls-remote", "未识别仓库地址")
                    return
                ok, out = self._run([git, "ls-remote", "--tags", url],
                                    timeout=self.NET_TIMEOUT)
                self.done_sig.emit(ok, "ls-remote", out)
                return

            # 以下动作需要本地仓库；无 .git 的插件改用「克隆替换」
            if not self._is_git():
                if self.action == "upgrade":
                    ref = _remote_latest_tag(self.repo_url or self._remote_origin())
                    if ref:
                        self.log_sig.emit("远程最新版本：%s" % ref)
                    ok, detail = self._clone_swap(ref)
                    self.done_sig.emit(ok, "upgrade", detail)
                elif self.action == "checkout":
                    ok, detail = self._clone_swap(self.ref)
                    self.done_sig.emit(ok, "checkout", detail)
                else:
                    self.done_sig.emit(False, self.action, "该插件无本地 git 仓库，请先执行升级/切换以重建仓库")
                return

            if self.action == "fetch":
                ok, _ = self._run([git, "fetch", "--tags", "--prune"])
                self.done_sig.emit(ok, "fetch", "")
            elif self.action == "pull":
                ok, _ = self._run([git, "pull", "--ff-only"])
                self.done_sig.emit(ok, "pull", "")
            elif self.action == "upgrade":
                self._run([git, "fetch", "--tags", "--prune"])
                ok, out = self._run([git, "tag", "-l"])
                tags = [t for t in out.splitlines() if t]
                if tags:
                    latest = self._semver_max(tags)
                    ok2, _ = self._run([git, "checkout", "-f", latest])
                    self.done_sig.emit(ok2, "upgrade", latest)
                else:
                    ok2, _ = self._run([git, "pull", "--ff-only"])
                    latest = self._run([git, "rev-parse", "--short", "HEAD"])[1].strip()
                    self.done_sig.emit(ok2, "upgrade", latest or "最新")
            elif self.action == "checkout":
                self._run([git, "fetch", "--tags", "origin"])
                ok, _ = self._run([git, "checkout", "-f", self.ref])
                self.done_sig.emit(ok, "checkout", self.ref)
        except Exception as e:
            self.log_sig.emit("错误：%s" % e)
            self.done_sig.emit(False, "error", str(e))


# ---------------------------------------------------------------------------
# 批量插件管理线程（检查所有更新 / 更新所有 / 同步 ComfyUI-Manager）
# ---------------------------------------------------------------------------
class PluginBatchWorker(QThread):
    """批量扫描或更新多个插件，避免阻塞 UI。"""
    log_sig = Signal(str)
    progress_sig = Signal(str, str, bool)  # (name, status, has_update)
    done_sig = Signal(bool, str)  # (ok, action)

    def __init__(self, plugin_dir, action, names=None, manager_map=None):
        super().__init__()
        self.plugin_dir = plugin_dir
        self.action = action  # "check_all" | "update_all" | "sync_manager"
        self.names = names or []
        self.manager_map = manager_map or {}  # name -> {"reference": url, ...}

    # 批量操作超时（秒）；网络类调用短一些，避免单个插件卡死整批
    NET_TIMEOUT = 60
    GIT_TIMEOUT = 300

    def _git(self, path, args, timeout=None):
        if timeout is None:
            # ls-remote 属网络查询，其余按普通 git 操作计时
            timeout = self.NET_TIMEOUT if "ls-remote" in args else self.GIT_TIMEOUT
        rc, out = git_run([comfy_launch.GIT_EXE] + args, cwd=path, timeout=timeout)
        return out.strip(), rc

    def _is_git_repo(self, path):
        git_dir = os.path.join(path, ".git")
        return os.path.isdir(git_dir) or os.path.isfile(git_dir)

    def _remote_url(self, path):
        out, rc = self._git(path, ["remote", "-v"])
        if rc != 0:
            return ""
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 2 and "fetch" in line:
                return parts[1]
        return ""

    def _ver_key(self, v):
        nums = re.findall(r"\d+", v or "")
        return tuple(int(x) for x in nums) if nums else (0,)

    def _latest_local_tag(self, path):
        out, rc = self._git(path, ["tag", "-l"])
        if rc != 0:
            return ""
        tags = [t for t in out.splitlines() if t]
        if not tags:
            return ""
        return sorted(tags, key=self._ver_key, reverse=True)[0]

    def _latest_remote_tag(self, path):
        out, rc = self._git(path, ["ls-remote", "--tags", "origin"])
        if rc != 0:
            return ""
        tags = []
        for line in out.splitlines():
            parts = line.split()
            if len(parts) < 2:
                continue
            ref = parts[1]
            if ref.startswith("refs/tags/"):
                tag = ref[len("refs/tags/"):]
                if tag.endswith("^{}"):
                    tag = tag[:-3]
                if tag not in tags:
                    tags.append(tag)
        if not tags:
            return ""
        return sorted(tags, key=self._ver_key, reverse=True)[0]

    def _current_ref(self, path):
        out, rc = self._git(path, ["describe", "--tags", "--always"])
        return out if rc == 0 else ""

    def run(self):
        if self.action == "check_all":
            self._run_check_all()
        elif self.action == "update_all":
            self._run_update_all()
        elif self.action == "sync_manager":
            self._run_sync_manager()

    @staticmethod
    def _latest_from_lsremote(out):
        tags = []
        for line in (out or "").splitlines():
            parts = line.split()
            if len(parts) < 2:
                continue
            ref = parts[1]
            if ref.startswith("refs/tags/"):
                t = ref[len("refs/tags/"):]
                if t.endswith("^{}"):
                    t = t[:-3]
                if t and t not in tags:
                    tags.append(t)
        if not tags:
            return ""
        def key(v):
            nums = re.findall(r"\d+", v)
            return tuple(int(x) for x in nums) if nums else (0,)
        return sorted(tags, key=key, reverse=True)[0]


    def _run_check_all(self):
        total = len(self.names)
        for idx, name in enumerate(self.names, 1):
            path = os.path.join(self.plugin_dir, name)
            repo_url, cur, is_git = resolve_plugin_repo(path)
            if not repo_url:
                self.progress_sig.emit(name, "未识别仓库", False)
                continue
            self.log_sig.emit("[%d/%d] 检查 %s …" % (idx, total, name))
            has_update = False
            latest = ""
            if is_git:
                self._git(path, ["fetch", "--tags", "--prune"])
                latest = self._latest_remote_tag(path)
                if latest:
                    has_update = (latest != cur)
                else:
                    out, rc = self._git(path, ["rev-list", "HEAD..origin/HEAD", "--count"])
                    try:
                        has_update = rc == 0 and int((out or "0").strip() or "0") > 0
                    except Exception:
                        has_update = False
            else:
                url = _mirror_url(repo_url)
                out, rc = self._git(path, ["ls-remote", "--tags", url])
                if rc == 0:
                    latest = self._latest_from_lsremote(out)
                    if latest and cur:
                        has_update = self._ver_key(latest) != self._ver_key(cur)
            status = "当前 %s" % (cur or "?")
            if latest:
                status += " ｜ 最新 %s" % latest
            if has_update:
                status += " ｜ 可更新"
            self.progress_sig.emit(name, status, has_update)
        self.log_sig.emit("批量检查完成。")
        self.done_sig.emit(True, "check_all")

    def _run_update_all(self):
        total = len(self.names)
        ok_count = 0
        for idx, name in enumerate(self.names, 1):
            path = os.path.join(self.plugin_dir, name)
            repo_url, cur, is_git = resolve_plugin_repo(path)
            if not repo_url:
                continue
            self.log_sig.emit("[%d/%d] 更新 %s …" % (idx, total, name))
            url = _mirror_url(repo_url)
            if is_git:
                branch = self._git(path, ["symbolic-ref", "--short", "-q", "HEAD"])[0].strip()
                if branch:
                    out, rc = self._git(path, ["pull", "--ff-only"])
                    if rc == 0:
                        ok_count += 1
                        self.progress_sig.emit(name, "已更新", False)
                    else:
                        self.progress_sig.emit(name, "更新失败：%s" % out[:80], False)
                else:
                    # 处于分离 HEAD（切换过指定版本），pull 会报
                    # “You are not currently on a branch”，改为切到最新 tag
                    self._git(path, ["fetch", "--tags", "--prune"])
                    latest = self._latest_remote_tag(path) or self._latest_local_tag(path)
                    if not latest:
                        self.progress_sig.emit(name, "无可用版本标签", False)
                    else:
                        out, rc = self._git(path, ["checkout", "-f", latest])
                        if rc == 0:
                            ok_count += 1
                            self.progress_sig.emit(name, "已更新到 %s" % latest, False)
                        else:
                            self.progress_sig.emit(name, "切换失败：%s" % out[:80], False)
            else:
                # 无本地仓库（便携包剥离 .git）：克隆最新版后整目录替换
                latest = _remote_latest_tag(url)
                ok, detail = clone_swap_plugin(path, url, latest, self.log_sig.emit)
                if ok:
                    ok_count += 1
                    self.progress_sig.emit(name, "已更新到 %s" % (detail or "最新"), False)
                else:
                    self.progress_sig.emit(name, "更新失败：%s" % detail[:80], False)
        self.log_sig.emit("批量更新完成：%d/%d 成功。" % (ok_count, total))
        self.done_sig.emit(True, "update_all")

    def _run_sync_manager(self):
        """用 ComfyUI-Manager 的节点数据库匹配本地插件，查询每个插件的最新 tag。"""
        total = len(self.names)
        matched = 0
        for idx, name in enumerate(self.names, 1):
            path = os.path.join(self.plugin_dir, name)
            repo_url, cur, is_git = resolve_plugin_repo(path)
            if not repo_url:
                self.progress_sig.emit(name, "未识别仓库", False)
                continue
            info = self.manager_map.get(_norm_key(name))
            if not info:
                for k, v in self.manager_map.items():
                    if name.lower() in k.lower() or k.lower() in name.lower():
                        info = v
                        break
            url = ""
            if info:
                url = info.get("reference", "") or (info.get("files") or [""])[0]
            if not url:
                url = repo_url
            url = _mirror_url(url)
            matched += 1
            self.log_sig.emit("[%d/%d] Manager 同步 %s -> %s" % (idx, total, name, url))
            out, rc = self._git(path, ["ls-remote", "--tags", url])
            latest = self._latest_from_lsremote(out) if rc == 0 else ""
            has_update = bool(latest) and self._ver_key(latest) != self._ver_key(cur or "")
            status = "当前 %s" % (cur or "?")
            if latest:
                status += " ｜ Manager 最新 %s" % latest
            if has_update:
                status += " ｜ 可更新"
            self.progress_sig.emit(name, status, has_update)
        self.log_sig.emit("Manager 同步完成：匹配 %d/%d。" % (matched, total))
        self.done_sig.emit(True, "sync_manager")


# ---------------------------------------------------------------------------
# 插件管理器：列出 custom_nodes 下插件目录，支持 删除/刷新，显示版本号，
#            批量检查/更新/与 ComfyUI-Manager 同步，单个插件可升降级版本。
#            （不提供新建/重命名：插件目录名即 ComfyUI 的模块名，改动会导致
#             已保存工作流里的节点失效，故仅保留删除。）
# ---------------------------------------------------------------------------
class PluginManagerDialog(QDialog):
    """管理 ComfyUI 自定义节点目录（custom_nodes）下的插件。
    与 ComfyUI-Manager 同步：优先读取 Manager 的 custom-node-list.json 数据库，
    通过 git ls-remote 查询每个插件仓库的最新 tag/版本。
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🧩 插件管理")
        self.setMinimumWidth(620)
        self.setMinimumHeight(520)
        icon = _app_icon_path()
        if icon:
            self.setWindowIcon(QIcon(icon))

        self.dir_path = config.get_plugin_dir()
        try:
            os.makedirs(self.dir_path, exist_ok=True)
        except Exception:
            pass

        # name -> {"current", "branch", "dirty", "latest", "has_update", "is_git", "repo_url"}
        self._plugin_info = {}
        self._manager_map = {}  # name -> node info from custom-node-list.json
        self._batch_worker = None
        self._dep_worker = None

        root = QVBoxLayout(self)
        root.setSpacing(8)

        # 目录路径（固定包内默认，不做外部映射）
        hdr = QHBoxLayout()
        hdr.setSpacing(6)
        self.dir_label = QLabel("插件目录（自定义节点，包内固定）：%s" % self.dir_path)
        self.dir_label.setWordWrap(True)
        self.dir_label.setStyleSheet("color:#5a6a7e;font-size:11px;")
        hdr.addWidget(self.dir_label, 1)
        self.open_dir_btn = QPushButton("📂 打开插件目录")
        self.open_dir_btn.setToolTip("在资源管理器中打开插件所在目录（custom_nodes）")
        self.open_dir_btn.setStyleSheet("font-size:11px;padding:2px 8px;")
        self.open_dir_btn.clicked.connect(
            lambda: open_folder_in_explorer(self.dir_path))
        hdr.addWidget(self.open_dir_btn)
        root.addLayout(hdr)

        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.list_widget.itemSelectionChanged.connect(self._on_selected)
        self.list_widget.setStyleSheet(
            "background:#fff;color:#1f3a5f;border:1px solid #d0d7de;"
            "border-radius:4px;font-size:12px;")
        root.addWidget(self.list_widget, 1)

        # 批量操作栏
        batch_row = QHBoxLayout()
        batch_row.setSpacing(8)
        self.check_all_btn = QPushButton("🔍 检查所有更新")
        self.update_all_btn = QPushButton("⬆ 更新所有")
        self.sync_mgr_btn = QPushButton("🔄 与 ComfyUI-Manager 同步")
        self.check_all_btn.clicked.connect(self._check_all_updates)
        self.update_all_btn.clicked.connect(self._update_all)
        self.sync_mgr_btn.clicked.connect(self._sync_with_manager)
        batch_row.addWidget(self.check_all_btn)
        batch_row.addWidget(self.update_all_btn)
        batch_row.addWidget(self.sync_mgr_btn)
        batch_row.addStretch(1)
        root.addLayout(batch_row)

        # 版本管理分组（git 仓库 / 无 .git 但能识别仓库地址的插件均可）
        self.ver_group = QGroupBox("版本管理（支持无 .git 的插件）")
        vlay = QVBoxLayout(self.ver_group)
        self.ver_info = QLabel("未选择插件")
        self.ver_info.setWordWrap(True)
        self.ver_info.setStyleSheet("color:#5a6a7e;font-size:11px;")
        vlay.addWidget(self.ver_info)

        ver_ctrl = QHBoxLayout()
        ver_ctrl.setSpacing(6)
        self.ver_combo = QComboBox()
        self.ver_combo.setMinimumWidth(150)
        self.check_update_btn = QPushButton("🔄 检查更新")
        self.upgrade_btn = QPushButton("⬆ 升级到最新")
        self.switch_btn = QPushButton("⬇ 切换到选中版本")
        self.check_update_btn.clicked.connect(self._check_update)
        self.upgrade_btn.clicked.connect(self._upgrade)
        self.switch_btn.clicked.connect(self._switch_version)
        ver_ctrl.addWidget(self.ver_combo)
        ver_ctrl.addWidget(self.check_update_btn)
        ver_ctrl.addWidget(self.upgrade_btn)
        ver_ctrl.addWidget(self.switch_btn)
        vlay.addLayout(ver_ctrl)

        self.ver_log = QPlainTextEdit()
        self.ver_log.setReadOnly(True)
        self.ver_log.setMaximumHeight(110)
        self.ver_log.setStyleSheet(
            "background:#0e1117;color:#d4d4d4;font-family:Consolas,monospace;font-size:12px;")
        vlay.addWidget(self.ver_log)
        root.addWidget(self.ver_group)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        self.dep_btn = QPushButton("🔌 注册依赖")
        self.dep_btn.setToolTip(
            "扫描当前插件目录下所有插件的 requirements.txt / pyproject 依赖，\n"
            "缺失的自动 pip 安装到包内 venv，并逐条显示注册状态")
        self.dep_btn.clicked.connect(self._register_deps)
        self.del_btn = QPushButton("🗑 删除")
        self.refresh_btn = QPushButton("🔄 刷新")
        self.open_sel_btn = QPushButton("📂 打开此插件")
        self.open_sel_btn.setToolTip("在资源管理器中打开当前选中的插件文件夹")
        self.open_sel_btn.setEnabled(False)
        self.open_sel_btn.clicked.connect(self._open_selected_plugin)
        self.del_btn.setEnabled(False)
        self.del_btn.clicked.connect(self._delete)
        self.refresh_btn.clicked.connect(self._refresh)
        btn_row.addWidget(self.dep_btn)
        btn_row.addWidget(self.del_btn)
        btn_row.addWidget(self.open_sel_btn)
        btn_row.addStretch(1)
        btn_row.addWidget(self.refresh_btn)
        root.addLayout(btn_row)

        close_row = QHBoxLayout()
        close_row.addStretch(1)
        self.close_btn = QPushButton("关闭")
        self.close_btn.clicked.connect(self.accept)
        close_row.addWidget(self.close_btn)
        root.addLayout(close_row)

        apply_button_fx(self)
        self._refresh()

    # ---- 依赖注册 ----
    def _register_deps(self):
        if self._dep_worker is not None and self._dep_worker.isRunning():
            return
        self.ver_log.setPlainText("🔌 开始检查并注册插件依赖…")
        self._dep_worker = PluginDepWorker(install=True)
        self._dep_worker.log_sig.connect(self._dep_log)
        self._dep_worker.done_sig.connect(self._on_dep_done)
        self.dep_btn.setEnabled(False)
        self._dep_worker.start()

    def _dep_log(self, msg):
        self.ver_log.appendPlainText(msg)
        self.ver_log.moveCursor(QTextCursor.End)

    def _on_dep_done(self, ok, summary, results):
        self.ver_log.appendPlainText("")
        self.ver_log.appendPlainText(summary)
        self.ver_log.moveCursor(QTextCursor.End)
        self.dep_btn.setEnabled(True)
        if ok:
            QMessageBox.information(self, "插件依赖注册", summary)
        else:
            QMessageBox.warning(self, "插件依赖注册", summary)

    def _refresh_dir_hint(self):
        """提示当前插件目录位置；若包内 custom_nodes 仍是目录联接(junction)，给出说明。

        自 v1.0.2 起插件目录固定为包内真实目录、不再做外部映射；若旧配置残留了
        联接，启动服务或点击「注册依赖」时会自动恢复为真实目录，复制/替换不再被
        外部 ComfyUI 进程占用。
        """
        base = "插件目录（自定义节点，包内固定）：%s" % self.dir_path
        try:
            linked = comfy_launch.is_plugin_dir_linked()
        except Exception:
            linked = None
        if linked:
            base += ("\n⚠ 检测到包内 custom_nodes 仍为目录联接(指向外部目录)，"
                     "启动服务或点击「注册依赖」时会自动恢复为包内真实目录，"
                     "此后复制/替换插件不再受外部 ComfyUI 进程占用影响。")
        self.dir_label.setText(base)

    # ---- 扫描目录 ----
    def _refresh(self):
        self._refresh_dir_hint()
        self.list_widget.clear()
        old_info = self._plugin_info
        self._plugin_info = {}
        items = []
        try:
            for name in os.listdir(self.dir_path):
                full = os.path.join(self.dir_path, name)
                if os.path.isdir(full):
                    items.append(name)
                    info = self._scan_plugin_info(full)
                    # 保留批量操作时获得的最新版本/可更新标记，避免网络信息被本地扫描覆盖
                    old = old_info.get(name, {})
                    if old.get("latest"):
                        info["latest"] = old["latest"]
                        info["has_update"] = old.get("has_update", False)
                    self._plugin_info[name] = info
        except Exception as e:
            QMessageBox.warning(self, "读取失败", "无法读取插件目录：\n%s" % e)
            return
        items.sort(key=lambda s: s.lower())
        for name in items:
            info = self._plugin_info.get(name, {})
            display = name
            if info.get("managed"):
                cur = info.get("current", "")
                if cur:
                    display += "  [%s]" % cur
                if info.get("has_update"):
                    display += " ⬆"
            self.list_widget.addItem(display)
        self._on_selected()

    def _scan_plugin_info(self, path):
        """快速扫描单个插件目录的元信息（不访问网络）。

        即使目录不含 .git，也能通过 pyproject.toml / Manager 数据库解析出
        仓库地址与当前版本，从而支持版本管理（对齐 ComfyUI-Manager）。
        """
        info = {"is_git": False, "current": "", "branch": "", "dirty": False,
                "latest": "", "has_update": False, "repo_url": "", "managed": False}
        repo_url, cur, is_git = resolve_plugin_repo(path)
        info["is_git"] = is_git
        info["repo_url"] = repo_url
        info["current"] = cur
        info["managed"] = bool(repo_url)
        if is_git:
            info["branch"] = self._git(path, ["rev-parse", "--abbrev-ref", "HEAD"])
            info["dirty"] = bool(self._git(path, ["status", "--porcelain"]))
        return info

    def _on_selected(self):
        has = len(self.list_widget.selectedItems()) > 0
        self.del_btn.setEnabled(has)
        self.open_sel_btn.setEnabled(has)
        self._scan_version()

    def _selected_name(self):
        sel = self.list_widget.selectedItems()
        if not sel:
            return None
        text = sel[0].text()
        # 去掉后面附加的版本标记
        if "  [" in text:
            return text.split("  [")[0]
        return text

    def _open_selected_plugin(self):
        """在资源管理器中打开当前选中的插件文件夹。"""
        name = self._selected_name()
        if not name:
            return
        path = os.path.join(self.dir_path, name)
        open_folder_in_explorer(path)

    # ---- 版本管理（git） ----
    @staticmethod
    def _ver_key(v):
        nums = re.findall(r"\d+", v or "")
        return tuple(int(x) for x in nums) if nums else (0,)

    def _git(self, path, args, timeout=30):
        """UI 线程内的同步 git 查询，必须带超时，避免界面卡死。"""
        try:
            rc, out = git_run([comfy_launch.GIT_EXE] + args, cwd=path, timeout=timeout)
            return out.strip()
        except Exception as e:
            return "git 执行失败：%s" % e

    def _set_ver_enabled(self, ok):
        self.ver_combo.setEnabled(ok)
        self.check_update_btn.setEnabled(ok)
        self.upgrade_btn.setEnabled(ok)
        self.switch_btn.setEnabled(ok)

    def _scan_version(self):
        name = self._selected_name()
        if not name:
            self.ver_info.setText("未选择插件")
            self.ver_combo.clear()
            self._set_ver_enabled(False)
            return
        path = os.path.join(self.dir_path, name)
        info = self._plugin_info.get(name, {})
        if not info.get("managed"):
            self.ver_info.setText("「%s」无法识别版本仓库（无 .git / pyproject / Manager 数据库匹配），暂不支持版本管理。" % name)
            self.ver_combo.clear()
            self._set_ver_enabled(False)
            return
        repo_url = info.get("repo_url", "")
        cur = info.get("current", "")
        branch = info.get("branch", "")
        dirty = info.get("dirty", False)
        latest = info.get("latest", "")
        lines = ["当前：%s" % (cur or "已安装")]
        if repo_url:
            lines.append("仓库：%s" % repo_url)
        if branch:
            lines.append("分支：%s" % branch)
        if latest:
            lines.append("最新：%s" % latest)
        if dirty:
            lines.append("（有未提交修改）")
        if info.get("has_update"):
            lines.append("【可更新】")
        self.ver_info.setText(" ｜ ".join(lines))

        # 版本下拉：本地有 tag 直接用；无本地仓库则异步拉取远程 tag
        self.ver_combo.clear()
        if info.get("is_git"):
            tags = [t for t in self._git(path, ["tag", "-l"]).splitlines() if t]
            if tags:
                tags_sorted = sorted(set(tags), key=self._ver_key, reverse=True)
                self.ver_combo.addItems(tags_sorted)
                if cur in tags:
                    idx = self.ver_combo.findText(cur)
                    if idx >= 0:
                        self.ver_combo.setCurrentIndex(idx)
            else:
                self.ver_combo.addItem("（无本地 tag，请点「检查更新」）")
        else:
            batch_running = bool(getattr(self, "_batch_worker", None) and self._batch_worker.isRunning())
            if batch_running:
                self.ver_combo.addItem("（批量操作中，稍后点「检查更新」获取版本）")
            else:
                self.ver_combo.addItem("（正在获取远程版本…）")
                self._fetch_remote_tags(name, _mirror_url(repo_url))
        self._set_ver_enabled(True)

    @staticmethod
    def _parse_latest(out):
        tags = []
        for line in (out or "").splitlines():
            parts = line.split()
            if len(parts) < 2:
                continue
            ref = parts[1]
            if ref.startswith("refs/tags/"):
                t = ref[len("refs/tags/"):]
                if t.endswith("^{}"):
                    t = t[:-3]
                if t and t not in tags:
                    tags.append(t)
        if not tags:
            return ""
        return sorted(tags, key=PluginManagerDialog._ver_key, reverse=True)[0]

    def _fetch_remote_tags(self, name, repo_url):
        if not repo_url:
            self.ver_combo.clear()
            self.ver_combo.addItem("（无仓库地址）")
            return
        self._tag_worker = PluginVersionWorker("", "ls-remote", repo_url=repo_url)
        self._tag_worker.log_sig.connect(self.ver_log.appendPlainText)
        self._tag_worker.done_sig.connect(
            lambda ok, a, out: self._on_remote_tags(ok, name, out))
        self._tag_worker.start()

    def _on_remote_tags(self, ok, name, out):
        if self._selected_name() != name:
            return
        self.ver_combo.clear()
        if not ok:
            self.ver_combo.addItem("（获取远程版本失败）")
            return
        tags = []
        for line in (out or "").splitlines():
            parts = line.split()
            if len(parts) < 2:
                continue
            ref = parts[1]
            if ref.startswith("refs/tags/"):
                t = ref[len("refs/tags/"):]
                if t.endswith("^{}"):
                    t = t[:-3]
                if t and t not in tags:
                    tags.append(t)
        if tags:
            tags_sorted = sorted(set(tags), key=self._ver_key, reverse=True)
            self.ver_combo.addItems(tags_sorted)
            cur = self._plugin_info.get(name, {}).get("current", "")
            if cur in tags_sorted:
                idx = self.ver_combo.findText(cur)
                if idx >= 0:
                    self.ver_combo.setCurrentIndex(idx)
        else:
            self.ver_combo.addItem("（远程无版本标签）")

    def _busy(self, busy):
        for w in (self.check_update_btn, self.upgrade_btn, self.switch_btn,
                  self.check_all_btn, self.update_all_btn, self.sync_mgr_btn,
                  self.del_btn, self.refresh_btn):
            w.setEnabled(not busy)

    def _check_update(self):
        name = self._selected_name()
        if not name:
            return
        info = self._plugin_info.get(name, {})
        repo_url = _mirror_url(info.get("repo_url", ""))
        if not repo_url:
            QMessageBox.information(self, "提示", "未识别到该插件的仓库地址，无法检查更新。")
            return
        path = os.path.join(self.dir_path, name)
        self._busy(True)
        self.ver_log.appendPlainText("🔄 正在检查更新（查询远程最新版本）…")
        self._ver_worker = PluginVersionWorker(path, "ls-remote", repo_url=repo_url)
        self._ver_worker.log_sig.connect(self.ver_log.appendPlainText)
        self._ver_worker.done_sig.connect(self._on_check_update_done)
        self._ver_worker.start()

    def _on_check_update_done(self, ok, action, out):
        self._busy(False)
        name = self._selected_name()
        if not name:
            return
        if not ok:
            self.ver_log.appendPlainText("❌ 检查更新失败：%s" % out[:200])
            return
        latest = self._parse_latest(out)
        cur = self._plugin_info.get(name, {}).get("current", "")
        has_update = bool(latest) and self._ver_key(latest) != self._ver_key(cur or "")
        self._plugin_info[name]["latest"] = latest
        self._plugin_info[name]["has_update"] = has_update
        self.ver_log.appendPlainText(
            "远程最新版本：%s ｜ 当前：%s%s" % (latest, cur or "?", " ｜ 可更新" if has_update else " ｜ 已是最新"))
        self._refresh()
        self._scan_version()

    def _upgrade(self):
        name = self._selected_name()
        if not name:
            return
        info = self._plugin_info.get(name, {})
        repo_url = _mirror_url(info.get("repo_url", ""))
        if not repo_url:
            QMessageBox.information(self, "提示", "未识别到该插件的仓库地址，无法升级。")
            return
        path = os.path.join(self.dir_path, name)
        if not info.get("is_git"):
            ret = QMessageBox.question(
                self, "确认升级",
                "「%s」当前没有本地 git 仓库（便携包已剥离 .git）。\n"
                "升级将从远程仓库重新拉取整份文件并覆盖该目录，"
                "目录内你手动修改或新增的文件会丢失。\n\n是否继续？" % name,
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ret != QMessageBox.Yes:
                return
        self._busy(True)
        self.ver_log.appendPlainText("⬆ 正在升级到最新版本…")
        self._ver_worker = PluginVersionWorker(path, "upgrade", repo_url=repo_url)
        self._ver_worker.log_sig.connect(self.ver_log.appendPlainText)
        self._ver_worker.done_sig.connect(self._on_ver_done)
        self._ver_worker.start()

    def _switch_version(self):
        name = self._selected_name()
        if not name:
            return
        ref = self.ver_combo.currentText().strip()
        if not ref or ref.startswith("（"):
            QMessageBox.information(self, "提示", "请先在版本下拉框选择一个目标版本。")
            return
        info = self._plugin_info.get(name, {})
        repo_url = _mirror_url(info.get("repo_url", ""))
        if not repo_url:
            QMessageBox.information(self, "提示", "未识别到该插件的仓库地址，无法切换版本。")
            return
        path = os.path.join(self.dir_path, name)
        if not info.get("is_git"):
            ret = QMessageBox.question(
                self, "确认切换版本",
                "「%s」当前没有本地 git 仓库（便携包已剥离 .git）。\n"
                "切换到 %s 将从远程仓库重新拉取整份文件并覆盖该目录，"
                "目录内你手动修改或新增的文件会丢失。\n\n是否继续？" % (name, ref),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ret != QMessageBox.Yes:
                return
        self._busy(True)
        self.ver_log.appendPlainText("⬇ 正在切换到版本：%s …" % ref)
        self._ver_worker = PluginVersionWorker(path, "checkout", ref, repo_url=repo_url)
        self._ver_worker.log_sig.connect(self.ver_log.appendPlainText)
        self._ver_worker.done_sig.connect(self._on_ver_done)
        self._ver_worker.start()

    def _on_ver_done(self, ok, action, detail):
        self._busy(False)
        if ok:
            # 重新扫描当前插件信息
            name = self._selected_name()
            if name:
                full = os.path.join(self.dir_path, name)
                self._plugin_info[name] = self._scan_plugin_info(full)
            self._refresh()
            if action == "fetch":
                self.ver_log.appendPlainText("✅ 检查更新完成。")
            elif action == "pull":
                self.ver_log.appendPlainText("✅ 升级到最新完成，请重启 ComfyUI 加载新版本。")
            elif action == "upgrade":
                self.ver_log.appendPlainText("✅ 已升级到最新版本 %s，请重启 ComfyUI 加载新版本。" % (detail or ""))
            elif action.startswith("checkout"):
                self.ver_log.appendPlainText("✅ 已切换到版本 %s，请重启 ComfyUI 加载该版本。" % (detail or ""))
        else:
            self.ver_log.appendPlainText("❌ 操作失败：%s" % action)
        self._scan_version()

    # ---- 批量操作 ----
    def _plugin_names(self):
        return [self._selected_name_from_text(self.list_widget.item(i).text())
                for i in range(self.list_widget.count())]

    def _selected_name_from_text(self, text):
        if "  [" in text:
            return text.split("  [")[0]
        return text

    def _check_all_updates(self):
        names = self._plugin_names()
        if not names:
            QMessageBox.information(self, "提示", "当前没有插件。")
            return
        self._busy(True)
        self.ver_log.clear()
        self.ver_log.appendPlainText("🔍 开始批量检查所有插件更新…")
        self._batch_worker = PluginBatchWorker(self.dir_path, "check_all", names)
        self._batch_worker.log_sig.connect(self.ver_log.appendPlainText)
        self._batch_worker.progress_sig.connect(self._on_batch_progress)
        self._batch_worker.done_sig.connect(self._on_batch_done)
        self._batch_worker.start()

    def _update_all(self):
        names = self._plugin_names()
        if not names:
            QMessageBox.information(self, "提示", "当前没有插件。")
            return
        ret = QMessageBox.question(
            self, "批量更新", "确定对所有 git 插件执行 git pull 更新到最新？",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if ret != QMessageBox.Yes:
            return
        self._busy(True)
        self.ver_log.clear()
        self.ver_log.appendPlainText("⬆ 开始批量更新所有插件…")
        self._batch_worker = PluginBatchWorker(self.dir_path, "update_all", names)
        self._batch_worker.log_sig.connect(self.ver_log.appendPlainText)
        self._batch_worker.progress_sig.connect(self._on_batch_progress)
        self._batch_worker.done_sig.connect(self._on_batch_done)
        self._batch_worker.start()

    def _load_manager_node_list(self):
        """加载 ComfyUI-Manager 的 custom-node-list.json（已归一化 key）。

        返回 归一化key -> node，便于按插件目录名直接匹配。
        """
        try:
            return _load_cn_db()
        except Exception as e:
            self.ver_log.appendPlainText("⚠ 读取 Manager 数据库失败：%s" % e)
            return {}

    def _sync_with_manager(self):
        names = self._plugin_names()
        if not names:
            QMessageBox.information(self, "提示", "当前没有插件。")
            return
        self._manager_map = self._load_manager_node_list()
        if not self._manager_map:
            QMessageBox.information(
                self, "未找到 Manager 数据库",
                "未找到 ComfyUI-Manager 的 custom-node-list.json。\n"
                "请先在 ComfyUI 中安装 ComfyUI-Manager，或确保启动器包内包含该数据库。")
            return
        self._busy(True)
        self.ver_log.clear()
        self.ver_log.appendPlainText("🔄 开始与 ComfyUI-Manager 同步版本信息…")
        self._batch_worker = PluginBatchWorker(
            self.dir_path, "sync_manager", names, self._manager_map)
        self._batch_worker.log_sig.connect(self.ver_log.appendPlainText)
        self._batch_worker.progress_sig.connect(self._on_batch_progress)
        self._batch_worker.done_sig.connect(self._on_batch_done)
        self._batch_worker.start()

    def _on_batch_progress(self, name, status, has_update):
        self._plugin_info.setdefault(name, {})
        self._plugin_info[name]["latest"] = ""
        self._plugin_info[name]["has_update"] = has_update
        # 从 status 里提取最新版本
        if "最新" in status:
            parts = status.split("最新")
            if len(parts) > 1:
                self._plugin_info[name]["latest"] = parts[1].split()[0].strip()
        self._refresh()
        # 保持选中当前项
        for i in range(self.list_widget.count()):
            text = self.list_widget.item(i).text()
            if text.startswith(name + "  [") or text == name:
                self.list_widget.setCurrentRow(i)
                break

    def _on_batch_done(self, ok, action):
        self._busy(False)
        self.ver_log.appendPlainText("✅ 批量操作完成：%s" % action)
        self._refresh()

    # ---- 删除 ----
    def _delete(self):
        old = self._selected_name()
        if not old:
            return
        ret = QMessageBox.question(
            self, "删除插件",
            "确定删除插件「%s」及其全部文件？此操作不可恢复。" % old,
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if ret != QMessageBox.Yes:
            return
        try:
            import shutil
            force_rmtree(os.path.join(self.dir_path, old))
        except Exception as e:
            QMessageBox.warning(self, "删除失败", "无法删除：\n%s" % e)
            return
        self._refresh()

# ---------------------------------------------------------------------------
# 环境更新子对话框：参考 ComfyUI 桌面版，选择 PyTorch 版本与 CUDA 后端
# ---------------------------------------------------------------------------
class EnvironmentUpdateDialog(QDialog):
    """手动选择 PyTorch 版本与 CUDA 后端。"""

    # 稳定版源实际可用的 CUDA 后端；cu121 源已废弃，故不列出。
    CUDA_BACKEND_LABELS = {
        "cu128": "CUDA 12.8 (cu128)",
        "cu126": "CUDA 12.6 (cu126)",
        "cu124": "CUDA 12.4 (cu124)",
        "cu118": "CUDA 11.8 (cu118)",
        "cu130": "CUDA 13.0 (cu130，仅 nightly)",
    }

    # 稳定版 PyTorch 三件套版本对应表：torch -> (torchvision, torchaudio)
    # 三者版本必须严格对齐，否则会出现
    # 「无法定位程序输入点 torch_library_impl 于 _torchaudio.pyd」这类 DLL 错误。
    TORCH_TRIPLE_MAP = {
        "2.11.0": ("0.26.0", "2.11.0"),
        "2.10.0": ("0.25.0", "2.10.0"),
        "2.9.1":  ("0.24.1", "2.9.1"),
        "2.9.0":  ("0.24.0", "2.9.0"),
        "2.8.0":  ("0.23.0", "2.8.0"),
        "2.7.1":  ("0.22.1", "2.7.1"),
        "2.7.0":  ("0.22.0", "2.7.0"),
        "2.6.0":  ("0.21.0", "2.6.0"),
    }

    # 稳定版 PyTorch 版本与 CUDA 后端对照表（按官方 download.pytorch.org 实际可用版本维护）。
    # 注意：cu121 源已基本废弃，不再列出。
    PYTORCH_VERSIONS = [
        ("2.11.0", "cu128"),
        ("2.11.0", "cu126"),
        ("2.10.0", "cu128"),
        ("2.10.0", "cu126"),
        ("2.9.1", "cu128"),
        ("2.9.1", "cu126"),
        ("2.9.0", "cu128"),
        ("2.9.0", "cu126"),
        ("2.8.0", "cu128"),
        ("2.8.0", "cu126"),
        ("2.7.1", "cu128"),
        ("2.7.1", "cu126"),
        ("2.7.1", "cu118"),
        ("2.7.0", "cu128"),
        ("2.7.0", "cu126"),
        ("2.7.0", "cu118"),
        ("2.6.0", "cu126"),
        ("2.6.0", "cu124"),
        ("2.6.0", "cu118"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("更新环境依赖（PyTorch / CUDA）")
        self.setMinimumWidth(420)
        self._build_ui()
        apply_button_fx(self)

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(12)

        self.current_torch, self.current_cuda = self._detect_current_torch()
        driver_cuda = self._detect_driver_cuda()
        info_text = "当前环境：PyTorch %s（CUDA %s）" % (self.current_torch, self.current_cuda)
        if driver_cuda:
            info_text += " — 驱动支持 CUDA %s" % driver_cuda
        info = QLabel(info_text)
        info.setStyleSheet("color:#5a6a7e;")
        root.addWidget(info)

        # 更新通道，默认稳定版
        row_channel = QHBoxLayout()
        row_channel.addWidget(QLabel("更新通道"))
        self.channel_combo = QComboBox()
        self.channel_combo.addItem("稳定版", False)
        self.channel_combo.addItem("预览版 / nightly", True)
        self.channel_combo.setCurrentIndex(0)
        self.channel_combo.currentIndexChanged.connect(self._on_channel_changed)
        row_channel.addWidget(self.channel_combo)
        root.addLayout(row_channel)

        # 后端 — CUDA
        backend_title = QLabel("后端")
        backend_title.setStyleSheet("font-weight:bold;color:#1f3a5f;")
        root.addWidget(backend_title)

        self.cuda_combo = QComboBox()
        for tag in self.CUDA_BACKEND_LABELS:
            self.cuda_combo.addItem(self.CUDA_BACKEND_LABELS[tag], tag)
        default_tag = self._detect_best_cuda_tag()
        idx = self.cuda_combo.findData(default_tag)
        self.cuda_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.cuda_combo.currentIndexChanged.connect(self._on_cuda_changed)
        root.addWidget(self.cuda_combo)

        # PyTorch 版本
        pytorch_title = QLabel("PyTorch")
        pytorch_title.setStyleSheet("font-weight:bold;color:#1f3a5f;")
        root.addWidget(pytorch_title)

        self.pytorch_combo = QComboBox()
        self.pytorch_combo.currentIndexChanged.connect(self._on_pytorch_changed)
        root.addWidget(self.pytorch_combo)

        # 说明文字
        self.desc_label = QLabel("")
        self.desc_label.setWordWrap(True)
        self.desc_label.setStyleSheet("color:#7a8a9e;font-size:12px;")
        root.addWidget(self.desc_label)

        # 按钮
        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        self.ok_btn = QPushButton("确认更新")
        self.ok_btn.clicked.connect(self.accept)
        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.ok_btn)
        root.addLayout(btn_row)

        # 初始化选项与同步
        self._refresh_pytorch_list()

    def _detect_current_torch(self):
        """返回当前 PyTorch 版本与 CUDA 版本字符串。"""
        torch_ver = "unknown"
        cuda_ver = "unknown"
        try:
            if os.path.isfile(comfy_launch.COMFY_PYTHON):
                r = subprocess.run(
                    [comfy_launch.COMFY_PYTHON, "-c",
                     "import torch; print(torch.__version__); "
                     "print(torch.version.cuda or 'cpu')"],
                    capture_output=True, text=True,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    cwd=comfy_launch.COMFY_DIR)
                parts = r.stdout.strip().splitlines()
                if parts:
                    torch_ver = parts[0]
                if len(parts) >= 2:
                    cuda_ver = parts[1]
        except Exception:
            pass
        return torch_ver, cuda_ver

    def _detect_driver_cuda(self):
        """尝试从 nvidia-smi 获取驱动支持的 CUDA 版本（如 12.8）。

        新版 nvidia-smi（>= 560）输出格式已改为
            ``| NVIDIA-SMI 616.56   KMD Version: 616.56   CUDA UMD Version: 13.4  |``
        旧格式是 ``CUDA Version: 12.4``，故正则需兼容两种写法。
        """
        try:
            r = subprocess.run(
                ["nvidia-smi"], capture_output=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            # 中文 Windows 下 nvidia-smi 输出为 GBK，按字节读取后解码，
            # 直接 text=True（UTF-8）会抛 UnicodeDecodeError。
            out = r.stdout.decode("gbk", errors="replace")
            # 优先匹配新格式 CUDA UMD Version，再回退旧格式 CUDA Version
            m = re.search(r"CUDA\s+UMD\s+Version:\s*(\d+\.\d+)", out)
            if not m:
                m = re.search(r"CUDA\s+Version:\s*(\d+\.\d+)", out)
            if m:
                return m.group(1)
        except Exception:
            pass
        return None

    def _detect_best_cuda_tag(self):
        """选择默认 CUDA 后端。

        原则：不跟随当前已安装的 torch 后端（可能是 nightly cu130），
        而是优先选「驱动支持」且「官方稳定版有完整三件套」的最高版本。
        稳定版 PyTorch 目前最高支持 cu128，故驱动支持 12.8+ 时默认 cu128。
        """
        # 候选按「新 -> 旧」排列，只保留稳定版源实际可用的后端
        candidates = ["cu128", "cu126", "cu124", "cu118"]
        driver = self._detect_driver_cuda()
        if driver and "." in driver:
            try:
                major, minor = (int(x) for x in driver.split(".")[:2])
                for tag in candidates:
                    if tag not in self.CUDA_BACKEND_LABELS:
                        continue
                    need = int(tag[2:4]), int(tag[4:6])
                    if (major, minor) >= need:
                        return tag
            except Exception:
                pass
        # 解析失败时的保守默认
        return "cu128"

    def _parse_torch_version(self, s):
        """从 '2.9.1+cu130' 中解析出 (version, cu_tag)。"""
        s = s or ""
        if "+" in s:
            ver, cu = s.split("+", 1)
            return ver, cu
        return s, ""

    def _build_pytorch_items(self):
        """按当前 CUDA 选择构建稳定版三件套列表 [(label, torch_ver), ...]。"""
        current_ver, _ = self._parse_torch_version(self.current_torch)
        selected_cuda = self.cuda_tag()
        items = []
        for ver, cu in self.PYTORCH_VERSIONS:
            if cu != selected_cuda:
                continue
            vis, aud = self.TORCH_TRIPLE_MAP.get(ver, (None, None))
            label = "PyTorch %s + torchvision %s + torchaudio %s" % (
                ver, vis or "自动", aud or "自动")
            if ver == current_ver:
                label += "  — 与当前一致"
            items.append((label, ver))
        if not items:
            items.append(("该后端无稳定版三件套，建议改用 cu128", None))
        return items

    def _refresh_pytorch_list(self):
        """根据当前 CUDA 选择与通道，重建 PyTorch 版本下拉列表。"""
        is_nightly = self.channel_combo.currentData()
        current_ver, _ = self._parse_torch_version(self.current_torch)
        self.pytorch_combo.blockSignals(True)
        self.pytorch_combo.clear()

        if is_nightly:
            self.pytorch_combo.addItem("最新 nightly 预览版（三件套均取 nightly）", None)
            self.pytorch_combo.setEnabled(False)
        else:
            for label, ver in self._build_pytorch_items():
                self.pytorch_combo.addItem(label, ver)
            self.pytorch_combo.setEnabled(True)
            # 默认选中与当前 torch 版本号一致的项，保证升级后兼容性不变
            if current_ver:
                idx = self.pytorch_combo.findData(current_ver)
                if idx >= 0:
                    self.pytorch_combo.setCurrentIndex(idx)

        self.pytorch_combo.blockSignals(False)
        self._update_desc()

    def _on_channel_changed(self, idx):
        self._refresh_pytorch_list()

    def _on_cuda_changed(self, idx):
        if self.channel_combo.currentData():
            # nightly 模式只需更新说明
            self._update_desc()
            return
        # 稳定版：按新 CUDA 后端重建三件套列表
        current_ver, _ = self._parse_torch_version(self.current_torch)
        self.pytorch_combo.blockSignals(True)
        self.pytorch_combo.clear()
        for label, ver in self._build_pytorch_items():
            self.pytorch_combo.addItem(label, ver)
        if current_ver:
            i = self.pytorch_combo.findData(current_ver)
            if i >= 0:
                self.pytorch_combo.setCurrentIndex(i)
        self.pytorch_combo.blockSignals(False)
        self._update_desc()

    def _on_pytorch_changed(self, idx):
        # PyTorch 版本变化时，同步 CUDA 后端
        ver = self.pytorch_combo.currentData()
        if ver:
            for v, cu in self.PYTORCH_VERSIONS:
                if v == ver:
                    self.cuda_combo.blockSignals(True)
                    idx_cu = self.cuda_combo.findData(cu)
                    if idx_cu >= 0:
                        self.cuda_combo.setCurrentIndex(idx_cu)
                    self.cuda_combo.blockSignals(False)
                    break
        self._update_desc()

    def _update_desc(self):
        is_nightly = self.channel_combo.currentData()
        cuda_tag = self.cuda_tag()
        cuda_label = self.CUDA_BACKEND_LABELS.get(cuda_tag, cuda_tag)
        if is_nightly:
            text = "torch / torchvision / torchaudio 均取 nightly · %s — " \
                   "从 PyTorch nightly 源安装。" \
                   "注意：nightly 三件套版本可能不对齐，存在 DLL 报错风险（预览版慎用）。" % cuda_label
        else:
            torch_v, vis_v, aud_v = self.torch_triple()
            if torch_v:
                text = "将安装 torch==%s + torchvision==%s + torchaudio==%s · %s — " \
                       "三件套版本严格对齐，避免出现 DLL 入口点错误。" % (
                           torch_v, vis_v or "自动", aud_v or "自动", cuda_label)
            else:
                text = "将安装 torch / torchvision / torchaudio · %s — " \
                       "未锁定版本，pip 可能装到互不匹配的组合，建议选具体版本。" % cuda_label
        self.desc_label.setText(text)

    def cuda_tag(self):
        return self.cuda_combo.currentData()

    def torch_version(self):
        """返回选中的 PyTorch 版本号；nightly 模式返回 None。"""
        return self.pytorch_combo.currentData()

    def torch_triple(self):
        """返回严格对齐的 (torch, torchvision, torchaudio) 版本号三元组。

        找不到对应关系时返回 (torch_ver, None, None)，
        调用方应至少锁定 torch 版本，避免 pip 装到不匹配的 torchaudio。
        """
        ver = self.torch_version()
        if not ver:
            return (None, None, None)
        vis, aud = self.TORCH_TRIPLE_MAP.get(ver, (None, None))
        return (ver, vis, aud)

    def is_nightly(self):
        return self.channel_combo.currentData()


# ---------------------------------------------------------------------------
# 更新对话框 / 后台更新工作器
# ---------------------------------------------------------------------------
class UpdateDialog(QDialog):
    """让用户选择更新类型：内核正式版 / 内核开发版 / 环境依赖。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("更新设置")
        self.setMinimumWidth(340)
        self._choice = None
        self._env_details = None  # ((torch, torchvision, torchaudio), cuda_tag, is_nightly)
        self._kernel_target = None  # 内核更新选定的版本 ref（tag 或 commit sha）
        root = QVBoxLayout(self)
        root.setSpacing(10)

        tip = QLabel("请选择要执行的更新：")
        tip.setStyleSheet("font-weight:bold;color:#1f3a5f;")
        root.addWidget(tip)

        self.launcher_btn = QPushButton("🔄 启动器自身更新（检查 / 历史版本）")
        self.launcher_btn.setToolTip(
            "更新启动器本体（含历史版本回退）；按 Git 镜像自动选择境内/境外更新源，无需手动填写")
        self.launcher_btn.clicked.connect(self._open_launcher)
        root.addWidget(self.launcher_btn)

        sep = QLabel("— ComfyUI 相关更新 —")
        sep.setStyleSheet("color:#94a3b8;font-size:11px;margin-top:4px;")
        root.addWidget(sep)

        self.kernel_stable_btn = QPushButton("⚙ 更新 ComfyUI 内核（正式版）")
        self.kernel_stable_btn.setToolTip("弹出版本列表，选择要切换到的正式版（可升级/降级）")
        self.kernel_stable_btn.clicked.connect(lambda: self._pick_kernel(False))
        root.addWidget(self.kernel_stable_btn)

        self.kernel_dev_btn = QPushButton("⚙ 更新 ComfyUI 内核（开发版）")
        self.kernel_dev_btn.setToolTip("弹出版本列表，选择要切换到的开发版提交（可升级/降级）")
        self.kernel_dev_btn.clicked.connect(lambda: self._pick_kernel(True))
        root.addWidget(self.kernel_dev_btn)

        self.env_btn = QPushButton("🔧 更新环境依赖（PyTorch / CUDA）")
        self.env_btn.setToolTip("手动选择 CUDA 版本与 PyTorch 通道，安装 torch / torchvision / torchaudio")
        self.env_btn.clicked.connect(lambda: self._pick("env"))
        root.addWidget(self.env_btn)

        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.clicked.connect(self.reject)
        root.addWidget(self.cancel_btn)

        apply_button_fx(self)

    def _pick(self, choice):
        if choice == "env":
            dlg = EnvironmentUpdateDialog(self)
            if dlg.exec() != QDialog.Accepted:
                return
            # 传递严格对齐的三件套版本，避免 pip 装到不匹配的 torchaudio
            self._env_details = (dlg.torch_triple(), dlg.cuda_tag(), dlg.is_nightly())
        self._choice = choice
        self.accept()

    def _pick_kernel(self, dev):
        """先弹出版本选择框，让用户选具体版本（可升级/降级），再确认。"""
        dlg = KernelVersionDialog(self, dev=dev)
        if dlg.exec() != QDialog.Accepted:
            return
        self._kernel_target = dlg.target()
        self._choice = "kernel_dev" if dev else "kernel_stable"
        self.accept()

    def choice(self):
        return self._choice, self._env_details, self._kernel_target

    def _open_launcher(self):
        """从「更新」页面打开启动器自身更新对话框（含历史版本选择）。"""
        self.reject()  # 关闭「更新设置」，避免两个模态框叠加
        parent = self.parent() or self
        dlg = LauncherUpdateDialog(parent, None)
        dlg.setWindowTitle("启动器更新")
        dlg.title_lbl.setText("正在检查更新…")
        dlg.update_btn.setEnabled(False)
        fetch = LauncherFetchWorker()
        # 直连对话框方法：对话框销毁后 Qt 自动断开连接，避免回调已销毁对象
        fetch.result_sig.connect(dlg._on_fetch)
        # 关键：把 worker 挂到长期存活的容器上，避免方法返回后局部 QThread 仍在运行时
        # 被 GC 销毁导致闪退；线程结束后自动清理引用并 deleteLater。
        _LAUNCHER_FETCH_HOLDER.append(fetch)

        def _cleanup():
            try:
                _LAUNCHER_FETCH_HOLDER.remove(fetch)
            except Exception:
                pass
            fetch.deleteLater()

        fetch.finished.connect(_cleanup)
        fetch.start()
        dlg.exec()


class KernelVersionDialog(QDialog):
    """点击「内核正式版 / 内核开发版」后弹出：让用户选择具体版本（可升降级）。

    布局：左侧版本列表 + 右侧更新日志预览。选中版本即在右侧展示该版本的
    更新日志（正式版来自 GitHub Release body，开发版来自 commit 完整信息）。
    """

    def __init__(self, parent=None, dev=False):
        super().__init__(parent)
        self.dev = dev
        self._target = None
        self._changelogs = {}  # ref(标签名/sha) -> 更新日志文本
        channel = "开发版" if dev else "正式版"
        self.setWindowTitle("选择 ComfyUI 内核版本（%s）" % channel)
        self.setMinimumSize(880, 480)
        layout = QVBoxLayout(self)
        tip = QLabel("选择要更新到的版本（可升级也可降级）。选中版本后，右侧显示该版本更新日志。"
                     "括号内为发布 / 提交时间。")
        tip.setStyleSheet("color:#1f3a5f;")
        layout.addWidget(tip)

        # 中间：左右分栏（列表 | 更新日志）
        mid = QHBoxLayout()
        self.list_widget = QListWidget()
        self.list_widget.setMinimumWidth(340)
        self.list_widget.setStyleSheet(
            "QListWidget{background:white;color:#1f3a5f;border:1px solid #d0d7de;}"
            "QListWidget::item{padding:6px 8px;height:28px;}"
            "QListWidget::item:selected{background:#d6e4f0;color:#1f3a5f;}"
            "QListWidget::item:hover{background:#eef4fa;color:#1f3a5f;}"
        )
        self.list_widget.currentItemChanged.connect(self._on_select)
        mid.addWidget(self.list_widget, 1)

        self.changelog_browser = QTextBrowser()
        self.changelog_browser.setOpenExternalLinks(True)
        self.changelog_browser.setStyleSheet(
            "QTextBrowser{background:#fbfcfe;color:#1f3a5f;border:1px solid #d0d7de;"
            "padding:8px;}")
        mid.addWidget(self.changelog_browser, 2)
        layout.addLayout(mid, 1)

        self.status_lbl = QLabel("正在获取版本列表…")
        self.status_lbl.setStyleSheet("color:#5a6a7e;")
        layout.addWidget(self.status_lbl)
        btn_row = QHBoxLayout()
        self.ok_btn = QPushButton("确认更新")
        self.cancel_btn = QPushButton("取消")
        self.ok_btn.clicked.connect(self._on_ok)
        self.cancel_btn.clicked.connect(self.reject)
        btn_row.addStretch()
        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.ok_btn)
        layout.addLayout(btn_row)

        # 主线程同步加载版本列表（对话框显示后触发），避免子线程 subprocess 死锁。
        # 正式版用单次 git for-each-ref 取全部 tag+日期，开发版用单次 git log，
        # 本地数据秒回，不再联网 fetch，弹窗不会长时间空白。
        QTimer.singleShot(0, self._load)

    def _load(self):
        """同步获取版本列表与更新日志并填充。"""
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            env = comfy_launch._comfy_env()
            items = []
            if self.dev:
                # 开发版：master 最新置顶 + 本地最近 50 个提交（带日期与说明）
                items.append(("★ master 最新（开发版）", "master"))
                # 一次取 sha + 日期 + 完整 message，供列表显示与更新日志复用
                r = subprocess.run(
                    [comfy_launch.GIT_EXE, "-C", comfy_launch.COMFY_DIR,
                     "log", "-50", "--format=%H%x1f%ci%x1f%B%x1e"],
                    capture_output=True, text=True, timeout=40,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    env=env)
                for block in r.stdout.split("\x1e"):
                    block = block.strip("\x1e")
                    if not block:
                        continue
                    parts = block.split("\x1f", 2)
                    if len(parts) < 3:
                        continue
                    sha, date, body = parts
                    subject = body.strip().splitlines()[0] if body.strip() else ""
                    items.append(
                        ("%s  |  %s" % (date[:10], subject.strip()[:48]), sha))
                    self._changelogs[sha] = body.strip()
                # master 项：展示最新 commit 完整信息
                try:
                    self._changelogs["master"] = comfy_launch.fetch_commit_message(
                        "master", env=env)
                except Exception:
                    pass
            else:
                # 正式版：先 fetch 最新标签（修复「检测到 v0.34.3 但列表只到 v0.34.2」的本地缓存滞后），
                # 再单次命令取回全部 vX.Y.Z 标签及其创建日期（可升级/降级）。
                try:
                    subprocess.run(
                        [comfy_launch.GIT_EXE, "-C", comfy_launch.COMFY_DIR,
                         "fetch", "--tags", "origin"],
                        capture_output=True, text=True, timeout=30,
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                        env=env)
                except Exception:
                    pass  # 网络/超时不影响后续取列表，继续用本地标签
                r = subprocess.run(
                    [comfy_launch.GIT_EXE, "-C", comfy_launch.COMFY_DIR,
                     "for-each-ref", "--sort=-creatordate",
                     "--format=%(refname:short)|%(creatordate:short)",
                     "refs/tags"],
                    capture_output=True, text=True, timeout=40,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    env=env)
                for line in r.stdout.splitlines():
                    if "|" not in line:
                        continue
                    name, date = line.split("|", 1)
                    if re.match(r"^v\d+\.\d+\.\d+$", name):
                        items.append(("%s  |  %s" % (name, date), name))
                # 拉取 GitHub Release 更新日志（带本地缓存，网络失败用过期缓存兜底）
                try:
                    self._changelogs.update(
                        comfy_launch.fetch_releases_changelog(timeout=12) or {})
                except Exception:
                    pass
            self._on_items(items)
        except subprocess.TimeoutExpired:
            self.status_lbl.setText("获取版本列表超时，请稍后重试")
        except Exception as e:
            self.status_lbl.setText("获取失败：%s" % e)
        finally:
            QApplication.restoreOverrideCursor()

    def _on_items(self, items):
        self.list_widget.clear()
        if not items:
            self.status_lbl.setText("未获取到可用版本")
            self.changelog_browser.setPlainText("")
            return
        self.status_lbl.setText("共 %d 个版本（选中后右侧显示更新日志）" % len(items))
        for display, ref in items:
            item = QListWidgetItem(display)
            item.setData(Qt.UserRole, ref)
            item.setToolTip(display)
            item.setSizeHint(QSize(400, 28))
            self.list_widget.addItem(item)
        self.list_widget.setCurrentRow(0)
        self._on_select(self.list_widget.item(0), None)

    def _on_select(self, current, previous=None):
        if current is None:
            self.changelog_browser.setPlainText("")
            return
        ref = current.data(Qt.UserRole)
        log = self._changelogs.get(ref, "")
        if not log:
            if self.dev:
                self.changelog_browser.setPlainText(
                    "（该提交暂无扩展更新日志，列表项已显示其提交说明）")
            else:
                self.changelog_browser.setPlainText(
                    "（该版本暂无更新日志，可能是本地标签未发布 Release，\n"
                    " 或网络受限未能获取 GitHub Release。可稍后重试切换镜像。）")
            return
        # 优先按 Markdown 渲染（GitHub Release body 为 markdown）
        try:
            self.changelog_browser.setMarkdown(log)
        except Exception:
            self.changelog_browser.setPlainText(log)
        self.changelog_browser.moveCursor(QTextCursor.Start)

    def _on_error(self, msg):
        self.status_lbl.setText("获取失败：%s" % msg)

    def _on_ok(self):
        item = self.list_widget.currentItem()
        if not item or item.data(Qt.UserRole) is None:
            QMessageBox.information(self, "提示", "请选择一个版本")
            return
        self._target = item.data(Qt.UserRole)
        self.accept()

    def target(self):
        return self._target


class UpdateWorker(QThread):
    log_sig = Signal(str)
    done_sig = Signal(bool, str)

    def __init__(self, kind, env_details=None, kernel_target=None):
        super().__init__()
        self.kind = kind
        # env_details = ((torch, torchvision, torchaudio), cuda_tag, is_nightly)
        self.env_details = env_details or ((None, None, None), "cu128", False)
        self.kernel_target = kernel_target  # 内核更新选定的版本 ref（tag / commit sha）

    def _update_env(self):
        """环境更新：按用户选择的 CUDA 后端安装严格对齐的 torch 三件套。

        关键：torch / torchvision / torchaudio 三者版本必须一致，
        否则会出现「无法定位程序输入点 torch_library_impl 于 _torchaudio.pyd」。
        因此稳定版一律显式锁定三个版本号，绝不让 pip 自由解析。
        """
        triple, cuda_tag, is_nightly = self.env_details
        if not triple:
            triple = (None, None, None)
        torch_v, vis_v, aud_v = triple
        if not os.path.isfile(comfy_launch.COMFY_PYTHON):
            return False, "未找到包内 Python：%s" % comfy_launch.COMFY_PYTHON
        env = comfy_launch._comfy_env()
        env.pop("PYTHONNOUSERSITE", None)

        base_url = "https://download.pytorch.org/whl"
        if is_nightly:
            index_url = "%s/nightly/%s" % (base_url, cuda_tag)
            self.log_sig.emit("安装 nightly 三件套（CUDA=%s）" % cuda_tag)
            self.log_sig.emit("  注意：nightly 版本可能不对齐，有 DLL 报错风险")
            cmd = [
                comfy_launch.COMFY_PYTHON, "-m", "pip", "install", "--pre", "-U",
                "torch", "torchvision", "torchaudio", "--index-url", index_url,
            ]
        elif torch_v:
            index_url = "%s/%s" % (base_url, cuda_tag)
            # 必须带 +cuXXX 后缀，原因有二：
            # 1) 保证三件套 CUDA 后端完全一致（否则 torch+cu130 配
            #    torchaudio+cu128 会因符号不匹配导致 DLL 加载失败）；
            # 2) 强制 pip 下载该后端——若只写 torch==2.9.1，pip 会认为
            #    已安装的 2.9.1+cu130 满足条件而直接跳过。
            pkgs = ["torch==%s+%s" % (torch_v, cuda_tag)]
            if vis_v:
                pkgs.append("torchvision==%s+%s" % (vis_v, cuda_tag))
            if aud_v:
                pkgs.append("torchaudio==%s+%s" % (aud_v, cuda_tag))
            self.log_sig.emit("安装稳定版三件套（CUDA=%s）：%s" % (
                cuda_tag, " ".join(pkgs)))
            cmd = [
                comfy_launch.COMFY_PYTHON, "-m", "pip", "install", "-U",
            ] + pkgs + ["--index-url", index_url]
        else:
            index_url = "%s/%s" % (base_url, cuda_tag)
            self.log_sig.emit("安装最新稳定版 PyTorch（CUDA=%s）" % cuda_tag)
            self.log_sig.emit("  警告：未锁定版本，三件套可能不匹配")
            cmd = [
                comfy_launch.COMFY_PYTHON, "-m", "pip", "install", "-U",
                "torch", "torchvision", "torchaudio", "--index-url", index_url,
            ]

        rc, _ = self._run_stream(
            cmd, comfy_launch.COMFY_DIR, env,
            "安装 PyTorch 三件套（CUDA=%s）" % cuda_tag)
        if rc != 0:
            return False, "环境依赖安装失败（CUDA=%s，返回码 %s）" % (cuda_tag, rc)

        # 安装后校验三件套版本是否对齐，避免再次出现 DLL 入口点错误
        self._verify_torch_alignment()
        if is_nightly:
            return True, "环境依赖已更新：nightly PyTorch（CUDA=%s）" % cuda_tag
        return True, "环境依赖已更新：PyTorch %s（CUDA=%s）" % (
            torch_v or "最新稳定版", cuda_tag)

    def _verify_torch_alignment(self):
        """校验 torch / torchvision / torchaudio 的版本与 CUDA 后端是否一致。

        注意：torchvision 版本号与 torch 不同源（torch 2.9.1 对应
        torchvision 0.24.1），不能简单比较 major.minor，必须查官方对应表。
        """
        try:
            r = subprocess.run(
                [comfy_launch.COMFY_PYTHON, "-c",
                 "import torch, torchvision, torchaudio;"
                 "print(torch.__version__);print(torchvision.__version__);"
                 "print(torchaudio.__version__)"],
                capture_output=True, text=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                cwd=comfy_launch.COMFY_DIR)
            parts = r.stdout.strip().splitlines()
            if len(parts) < 3:
                self.log_sig.emit("⚠ 无法读取三件套版本，跳过对齐校验")
                return
            t, v, a = parts[0], parts[1], parts[2]
            self.log_sig.emit("已安装：torch=%s | torchvision=%s | torchaudio=%s" % (t, v, a))

            def _split(ver):
                """拆分为 (基础版本号, CUDA 后端标签)。"""
                if "+" in ver:
                    base, cu = ver.split("+", 1)
                    return base, cu
                return ver, ""

            def _minor(ver):
                m = re.match(r"^(\d+)\.(\d+)", ver or "")
                return (int(m.group(1)), int(m.group(2))) if m else None

            tb, tc = _split(t)
            vb, vc = _split(v)
            ab, ac = _split(a)

            problems = []
            # 1) CUDA 后端必须一致——这是 DLL 入口点错误最主要的原因
            if tc and (vc != tc or ac != tc):
                problems.append(
                    "CUDA 后端不一致：torch=%s / torchvision=%s / torchaudio=%s"
                    % (tc, vc or "无", ac or "无"))
            # 2) torch 与 torchaudio 版本号应一致（两者同步发版）
            if _minor(tb) and _minor(ab) and _minor(tb) != _minor(ab):
                problems.append("torch 与 torchaudio 版本不匹配：%s vs %s" % (tb, ab))
            # 3) torchvision 应匹配官方对应表
            expect_v, expect_a = EnvironmentUpdateDialog.TORCH_TRIPLE_MAP.get(
                tb, (None, None))
            if expect_v and vb != expect_v:
                problems.append("torchvision 应为 %s，实际为 %s" % (expect_v, vb))
            if expect_a and ab != expect_a:
                problems.append("torchaudio 应为 %s，实际为 %s" % (expect_a, ab))

            if problems:
                for p in problems:
                    self.log_sig.emit("⚠ " + p)
                self.log_sig.emit(
                    "  建议重新执行一次环境更新，选择同一 CUDA 后端与版本号。")
            else:
                self.log_sig.emit("✅ 三件套版本与 CUDA 后端均对齐")
        except Exception as e:
            self.log_sig.emit("版本校验跳过：%s" % e)

    def _run_stream(self, cmd, cwd, env, label=""):
        """流式执行子进程：实时把每行输出经 log_sig 推给 UI，避免长任务（如 pip
        下载几个 GB 的 PyTorch wheel）在缓冲期间表现为「卡死 / 无进度」。

        返回 (returncode, 末尾若干行列表)，供需要回看错误的调用方使用。
        """
        if label:
            self.log_sig.emit("▶ " + label)
        lines = []
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,   # 合并 stderr，避免只读一端而死锁
                text=True,
                bufsize=1,
                encoding="utf-8",
                errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                env=env,
                cwd=cwd,
            )
        except Exception as e:
            self.log_sig.emit("⚠ 启动命令失败：%s" % e)
            return -1, []
        if proc.stdout:
            for raw in proc.stdout:
                s = raw.rstrip("\r\n")
                if s.strip():
                    self.log_sig.emit("  " + s)
                lines.append(s)
        rc = proc.wait()
        return rc, lines[-30:]

    def _run_git(self, args, cwd, env):
        self.log_sig.emit("git %s" % " ".join(args))
        rc, lines = self._run_stream(
            [comfy_launch.GIT_EXE] + args, cwd, env)
        return rc == 0, "\n".join(lines)

    def _backup_dirty(self, env):
        """若 ComfyUI 工作区有修改，自动备份到带时间戳的分支。"""
        ok, out = self._run_git(["status", "--short"], comfy_launch.COMFY_DIR, env)
        dirty = out.strip()
        if not dirty:
            return True
        import datetime
        branch = "backup_branch_%s" % datetime.datetime.now().strftime("%Y-%m-%d_%H_%M_%S")
        self.log_sig.emit("检测到本地修改，自动备份到分支：%s" % branch)
        ok, _ = self._run_git(["checkout", "-b", branch], comfy_launch.COMFY_DIR, env)
        if not ok:
            return False
        ok, _ = self._run_git(["add", "-A"], comfy_launch.COMFY_DIR, env)
        if ok:
            self._run_git(
                ["commit", "-m", "Backup of local changes before update"],
                comfy_launch.COMFY_DIR, env)
        return True

    def _latest_stable_tag(self, env):
        """获取 ComfyUI 最新正式版标签（形如 v0.34.0，排除 beta/rc 等预览版）。"""
        self._run_git(["fetch", "--tags", "origin"], comfy_launch.COMFY_DIR, env)
        r = subprocess.run(
            [comfy_launch.GIT_EXE, "-C", comfy_launch.COMFY_DIR, "tag", "-l", "v*"],
            capture_output=True, text=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            env=env, cwd=comfy_launch.COMFY_DIR)
        tags = [t for t in r.stdout.split() if re.match(r"^v\d+\.\d+\.\d+$", t)]
        if not tags:
            return None

        def _key(t):
            return tuple(int(x) for x in t[1:].split("."))
        return sorted(tags, key=_key)[-1]

    def _update_kernel(self, dev=False, target=None):
        """内核更新：升级/降级 ComfyUI 程序本体到指定版本。
        dev=False → 正式版（target 为 tag，如 v0.34.0；None=最新稳定 tag）；
        dev=True  → 开发版（target 为 commit sha 或 "master"；None=master 最新）。"""
        env = comfy_launch._comfy_env()
        # 1. 备份脏工作区
        if not self._backup_dirty(env):
            return False, "备份本地修改失败"

        if dev:
            if target and target != "master":
                # 开发版：切换到用户选定的历史提交（可降级到旧开发点）
                self.log_sig.emit("切换到开发版指定提交：%s" % target[:12])
                ok, _ = self._run_git(["checkout", "-B", "dev", target],
                                      comfy_launch.COMFY_DIR, env)
                if not ok:
                    return False, "切换到开发版提交 %s 失败" % target[:12]
                msg = "ComfyUI 内核已更新到开发版提交 %s" % target[:12]
            else:
                # 开发版：拉取 master 最新代码
                self.log_sig.emit("切换到开发版（master 最新）…")
                ok, _ = self._run_git(["checkout", "master"], comfy_launch.COMFY_DIR, env)
                if not ok:
                    return False, "切换 master 分支失败"
                ok, out = self._run_git(["pull", "origin", "master", "--ff-only"],
                                        comfy_launch.COMFY_DIR, env)
                if not ok:
                    ok, out = self._run_git(["pull", "origin", "master"],
                                            comfy_launch.COMFY_DIR, env)
                if not ok:
                    return False, "拉取最新开发代码失败"
                msg = "ComfyUI 内核已更新到开发版（master 最新）"
        else:
            if target:
                # 正式版：切换到用户选定的稳定 tag（可升级也可降级）
                self.log_sig.emit("切换到正式版：%s" % target)
                ok, _ = self._run_git(["checkout", "-B", "release", target],
                                      comfy_launch.COMFY_DIR, env)
                if not ok:
                    return False, "切换到正式版 %s 失败" % target
                msg = "ComfyUI 内核已更新到正式版 %s" % target
            else:
                # 正式版：切换到最新稳定 tag（如 v0.34.0）
                tag = self._latest_stable_tag(env)
                if not tag:
                    return False, "未找到可用的正式版标签"
                self.log_sig.emit("切换到正式版：%s" % tag)
                ok, _ = self._run_git(["checkout", "-B", "release", tag],
                                      comfy_launch.COMFY_DIR, env)
                if not ok:
                    return False, "切换到正式版 %s 失败" % tag
                msg = "ComfyUI 内核已更新到正式版 %s" % tag

        # 2. 同步该版本对应的依赖
        req = os.path.join(comfy_launch.COMFY_DIR, "requirements.txt")
        if os.path.isfile(req) and os.path.isfile(comfy_launch.COMFY_PYTHON):
            env2 = comfy_launch._comfy_env()
            env2.pop("PYTHONNOUSERSITE", None)
            self.log_sig.emit("同步该版本依赖 requirements.txt…")
            self._run_stream(
                [comfy_launch.COMFY_PYTHON, "-m", "pip", "install", "-r", req],
                comfy_launch.COMFY_DIR, env2, "同步该版本依赖 requirements.txt")
        return True, msg

    def run(self):
        try:
            if self.kind == "env":
                ok, msg = self._update_env()
            elif self.kind == "kernel_stable":
                ok, msg = self._update_kernel(dev=False, target=self.kernel_target)
            elif self.kind == "kernel_dev":
                ok, msg = self._update_kernel(dev=True, target=self.kernel_target)
            else:
                ok, msg = False, "未知更新类型"
        except Exception as e:
            ok, msg = False, "更新异常：%s" % e
            import traceback
            self.log_sig.emit(traceback.format_exc())
        self.done_sig.emit(ok, msg)


# ---------------------------------------------------------------------------
# 启动参数 / 镜像 设置弹窗（左侧按钮触发）
# ---------------------------------------------------------------------------
class LaunchArgsDialog(QDialog):
    """设置额外启动参数（如 --cuda-device 1 --preview-method auto）。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("⚙ 启动参数设置")
        self.setMinimumWidth(520)
        root = QVBoxLayout(self)
        root.setSpacing(8)

        tip = QLabel("输入 ComfyUI 启动参数，多个参数以空格分隔；留空表示不附加任何参数。\n"
                     "修改后下次启动服务时生效。")
        tip.setWordWrap(True)
        tip.setStyleSheet("color:#5a6a7e;")
        root.addWidget(tip)

        self.edit = QLineEdit(config.get_extra_args())
        self.edit.setPlaceholderText("如：--cuda-device 1 --preview-method auto")
        self.edit.setStyleSheet(
            "border:1px solid #d0d7de;padding:6px 8px;border-radius:4px;")
        root.addWidget(self.edit)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        self.cancel_btn = QPushButton("取消")
        self.ok_btn = QPushButton("确定")
        self.ok_btn.setStyleSheet("background:#3a8a3a;color:white;font-weight:bold;")
        self.cancel_btn.clicked.connect(self.reject)
        self.ok_btn.clicked.connect(self.accept)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.ok_btn)
        root.addLayout(btn_row)

        apply_button_fx(self)

    def value(self):
        return self.edit.text().strip()


class MirrorDialog(QDialog):
    """选择 Git / HuggingFace 镜像源（kind: 'git' | 'hf'）。"""

    def __init__(self, parent=None, kind="git"):
        super().__init__(parent)
        self.kind = kind
        if kind == "git":
            self._data = config.GIT_MIRRORS
            self._current = config.get_git_mirror()
            self.setWindowTitle("🔀 Git 镜像设置")
            tip_text = "选择拉取 ComfyUI 内核 / 插件时使用的 Git 镜像源。"
        else:
            self._data = config.HF_MIRRORS
            self._current = config.get_hf_mirror()
            self.setWindowTitle("🤗 HuggingFace 镜像设置")
            tip_text = "选择下载模型 / 数据集时使用的 HuggingFace 镜像源。"

        self.setMinimumWidth(460)
        root = QVBoxLayout(self)
        root.setSpacing(8)

        tip = QLabel(tip_text)
        tip.setWordWrap(True)
        tip.setStyleSheet("color:#5a6a7e;")
        root.addWidget(tip)

        self.combo = QComboBox()
        for key, info in self._data.items():
            self.combo.addItem(info["name"], key)
        idx = self.combo.findData(self._current)
        self.combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.combo.setStyleSheet(
            "border:1px solid #d0d7de;padding:6px 8px;border-radius:4px;")
        root.addWidget(self.combo)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        self.cancel_btn = QPushButton("取消")
        self.ok_btn = QPushButton("确定")
        self.ok_btn.setStyleSheet("background:#3a8a3a;color:white;font-weight:bold;")
        self.cancel_btn.clicked.connect(self.reject)
        self.ok_btn.clicked.connect(self.accept)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.ok_btn)
        root.addLayout(btn_row)

        apply_button_fx(self)

    def value(self):
        return self.combo.currentData()

    def text(self):
        return self.combo.currentText()


class WorkflowManagerDialog(QDialog):
    """管理工作流目录下的工作流文件：查看 / 添加（导入外部 .json）/ 重命名 / 删除。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🗂 工作流管理")
        self.setMinimumWidth(520)
        self.setMinimumHeight(420)
        icon = _app_icon_path()
        if icon:
            self.setWindowIcon(QIcon(icon))

        self.dir_path = config.get_workflow_dir()
        # 目录不存在则创建，避免打开即报错
        try:
            os.makedirs(self.dir_path, exist_ok=True)
        except Exception:
            pass

        root = QVBoxLayout(self)
        root.setSpacing(8)

        # 蓝色拖拽提示框（用户能直接看到"可拖入 .json"）
        drop_hint = QLabel(
            "\U0001f4e5  把 <b>.json 工作流文件拖到本对话框任意位置</b>即可导入。"
        )
        drop_hint.setWordWrap(True)
        drop_hint.setStyleSheet(
            "background:#e3f2fd;color:#0d47a1;border:1px solid #90caf9;"
            "border-radius:6px;padding:8px 10px;font-size:12px;")
        root.addWidget(drop_hint)

        # 目录路径行（动态派生）+ 在资源管理器中打开按钮（无绝对路径硬编码）
        hdr = QHBoxLayout()
        hdr.setSpacing(6)
        self.dir_label = QLabel("工作流目录（启动器所在目录动态派生）：%s" % self.dir_path)
        self.dir_label.setWordWrap(True)
        self.dir_label.setStyleSheet("color:#5a6a7e;font-size:11px;")
        self.dir_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        hdr.addWidget(self.dir_label, 1)
        open_dir_btn = QPushButton("📂 在资源管理器中打开")
        open_dir_btn.setToolTip("用 Windows 资源管理器定位到工作流目录，方便手动复制文件")
        open_dir_btn.clicked.connect(
            lambda: open_folder_in_explorer(self.dir_path))
        hdr.addWidget(open_dir_btn)
        root.addLayout(hdr)

        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.list_widget.itemSelectionChanged.connect(self._on_selected)
        # 列表区也接受拖拽，并把事件转发给 dialog 的 dropEvent
        self.list_widget.setAcceptDrops(True)
        self.list_widget.setAcceptDropsOnAction(True) if hasattr(
            QListWidget, "setAcceptDropsOnAction") else None
        # 重写事件转发（避免被 QListWidget 内部吞掉）
        self.list_widget.dragEnterEvent = self._list_drag_enter
        self.list_widget.dragMoveEvent = self._list_drag_move
        self.list_widget.dropEvent = self._list_drop
        self.list_widget.setStyleSheet(
            "background:#fff;color:#1f3a5f;border:1px solid #d0d7de;"
            "border-radius:4px;font-size:12px;")
        root.addWidget(self.list_widget, 1)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        self.rename_btn = QPushButton("✏️ 重命名")
        self.del_btn = QPushButton("🗑 删除")
        self.refresh_btn = QPushButton("🔄 刷新")
        self.rename_btn.setEnabled(False)
        self.del_btn.setEnabled(False)
        self.rename_btn.clicked.connect(self._rename)
        self.del_btn.clicked.connect(self._delete)
        self.refresh_btn.clicked.connect(self._refresh)
        btn_row.addWidget(self.rename_btn)
        btn_row.addWidget(self.del_btn)
        btn_row.addStretch(1)
        btn_row.addWidget(self.refresh_btn)
        root.addLayout(btn_row)

        close_row = QHBoxLayout()
        close_row.addStretch(1)
        self.close_btn = QPushButton("关闭")
        self.close_btn.clicked.connect(self.accept)
        close_row.addWidget(self.close_btn)
        root.addLayout(close_row)

        apply_button_fx(self)
        self.setAcceptDrops(True)
        self._refresh()

    # ---- 拖拽支持：把外部 .json 工作流拖入窗口任意位置即可导入 ----
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls() and any(
                u.toLocalFile().lower().endswith(".json")
                for u in event.mimeData().urls()):
            event.acceptProposedAction()
            return
        event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            return
        event.ignore()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        paths = []
        for u in urls:
            local = u.toLocalFile()
            if local and os.path.isfile(local) and local.lower().endswith(".json"):
                paths.append(local)
        if paths:
            event.acceptProposedAction()
            self._import_files(paths)
        else:
            event.ignore()

    # ---- 转发：把拖到 QListWidget 上的事件也路由到 dialog 的 dropEvent ----
    def _list_drag_enter(self, event):
        self.dragEnterEvent(event)

    def _list_drag_move(self, event):
        self.dragMoveEvent(event)

    def _list_drop(self, event):
        self.dropEvent(event)

    # ---- 扫描目录 ----
    def _refresh(self):
        self.list_widget.clear()
        items = []
        try:
            for name in os.listdir(self.dir_path):
                full = os.path.join(self.dir_path, name)
                if os.path.isfile(full):
                    items.append(name)
        except Exception as e:
            QMessageBox.warning(self, "读取失败", "无法读取工作流目录：\n%s" % e)
            return
        items.sort(key=lambda s: s.lower())
        self.list_widget.addItems(items)
        self._on_selected()

    def _on_selected(self):
        has = len(self.list_widget.selectedItems()) > 0
        self.rename_btn.setEnabled(has)
        self.del_btn.setEnabled(has)

    def _selected_name(self):
        sel = self.list_widget.selectedItems()
        return sel[0].text() if sel else None

    # ---- 添加（选择外部 .json 工作流文件导入到工作流目录） ----
    def _import_files(self, files):
        """核心导入逻辑（对话框/拖拽共用）。files：磁盘 .json 绝对路径列表。"""
        try:
            os.makedirs(self.dir_path, exist_ok=True)
        except Exception as e:
            QMessageBox.warning(self, "目录不可用",
                                "无法访问工作流目录：\n%s\n\n%s" % (self.dir_path, e))
            return

        def _sanitize_name(fname):
            """清洗文件名并统一 .json 扩展名（不处理重名）。"""
            fname = re.sub(r'[\\/:*?"<>|]', "_", os.path.basename(fname)).strip()
            if not fname:
                fname = "workflow.json"
            if not fname.lower().endswith(".json"):
                fname += ".json"
            return fname

        def _safe_dst(fname):
            """返回不重名的目标路径（重名时自动追加 (1)(2)…）。"""
            name = _sanitize_name(fname)
            dst = os.path.join(self.dir_path, name)
            if not os.path.exists(dst):
                return dst, name
            base, ext = os.path.splitext(name)
            n = 1
            while True:
                cand = os.path.join(self.dir_path, "%s (%d)%s" % (base, n, ext))
                if not os.path.exists(cand):
                    return cand, os.path.basename(cand)
                n += 1

        def _same_path(a, b):
            try:
                return (os.path.normcase(os.path.abspath(a))
                        == os.path.normcase(os.path.abspath(b)))
            except Exception:
                return False

        added, skipped, invalid_json, failed = [], [], [], []
        for sp in files:
            fname = os.path.basename(sp)
            try:
                # 先按「去重前的原始目标路径」判断，否则会把自己复制成 xx (1).json
                raw_dst = os.path.join(self.dir_path, _sanitize_name(fname))
                if _same_path(sp, raw_dst):
                    skipped.append("%s（已在该目录中）" % fname)
                    continue
                dst, new_name = _safe_dst(fname)
            except Exception as e:
                failed.append("%s：%s" % (fname, e))
                continue
            try:
                shutil.copy2(sp, dst)
            except Exception as e:
                failed.append("%s：%s" % (fname, e))
                continue
            # 复制成功后再尝试解析 JSON；解析失败不阻止导入，仅记录到 invalid_json
            try:
                with open(dst, "r", encoding="utf-8") as f:
                    json.load(f)
            except Exception as e:
                invalid_json.append("%s（已复制，但 JSON 解析失败：%s）" % (new_name, e))
                added.append(new_name)  # 仍然算作「已添加」，只是保留下来供用户自行检查
                continue
            added.append(new_name)

        self._refresh()
        if added:
            for i in range(self.list_widget.count()):
                if self.list_widget.item(i).text() == added[0]:
                    self.list_widget.setCurrentRow(i)
                    break

        parts = []
        if added:
            parts.append("已添加 %d 个：\n· %s" % (len(added), "\n· ".join(added)))
        if skipped:
            parts.append("已跳过 %d 个：\n· %s" % (len(skipped), "\n· ".join(skipped)))
        if invalid_json:
            # 已复制，仅 JSON 解析失败 —— 提示用户，标题不标红
            parts.append("已添加但 JSON 无法解析 %d 个（请检查文件内容）：\n· %s"
                         % (len(invalid_json), "\n· ".join(invalid_json)))
        if failed:
            parts.append("失败 %d 个：\n· %s" % (len(failed), "\n· ".join(failed)))
        text = "\n\n".join(parts) or "未添加任何工作流。"
        if failed:
            QMessageBox.warning(self, "添加完成（有失败项）", text)
        elif invalid_json and not (added or skipped):
            QMessageBox.warning(self, "添加完成（JSON 无法识别）", text)
        else:
            QMessageBox.information(self, "添加完成", text)

    # ---- 重命名 ----
    def _rename(self):
        old = self._selected_name()
        if not old:
            return
        base, ext = os.path.splitext(old)
        new_name, ok = QInputDialog.getText(
            self, "重命名工作流", "输入新名称：", text=base)
        if not ok or not new_name.strip():
            return
        nb = new_name.strip()
        # 保留原扩展名；若用户输入了扩展名则以其为准
        if os.path.splitext(nb)[1]:
            target = nb
        else:
            target = nb + ext
        if target == old:
            return
        src = os.path.join(self.dir_path, old)
        dst = os.path.join(self.dir_path, target)
        if os.path.exists(dst):
            QMessageBox.warning(self, "已存在", "目标名称「%s」已存在。" % target)
            return
        try:
            os.rename(src, dst)
        except Exception as e:
            QMessageBox.warning(self, "重命名失败", "无法重命名：\n%s" % e)
            return
        self._refresh()
        for i in range(self.list_widget.count()):
            if self.list_widget.item(i).text() == target:
                self.list_widget.setCurrentRow(i)
                break

    # ---- 删除 ----
    def _delete(self):
        old = self._selected_name()
        if not old:
            return
        ret = QMessageBox.question(
            self, "删除工作流",
            "确定删除工作流「%s」？此操作不可恢复。" % old,
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if ret != QMessageBox.Yes:
            return
        try:
            os.remove(os.path.join(self.dir_path, old))
        except Exception as e:
            QMessageBox.warning(self, "删除失败", "无法删除：\n%s" % e)
            return
        self._refresh()

# ---------------------------------------------------------------------------
# 启动器自身增量更新（区别于 ComfyUI 内核/环境更新 UpdateWorker）
# ---------------------------------------------------------------------------
# 长期持有正在运行的更新检查线程引用，防止对话框关闭后局部 QThread 仍运行时
# 被 Python GC 销毁而闪退（线程必须在结束后才能 deleteLater）。
_LAUNCHER_FETCH_HOLDER = []


class LauncherCheckWorker(QThread):
    """后台检查是否有新版本。found_sig(info, err)：info 为 None 表示已是最新。"""
    found_sig = Signal(object, str)

    def run(self):
        try:
            info, err = updater.check_for_update()
            self.found_sig.emit(info, err or "")
        except Exception as e:
            self.found_sig.emit(None, str(e))


class LauncherFetchWorker(QThread):
    """后台同时拉取「最新版本」与「历史版本列表」，供更新对话框展示与选择。

    result_sig(latest_info, versions, err)：
      latest_info：check_for_update 的结果（可能 None 表示已是最新）；
      versions   ：list_versions 的结果（可能 None 表示网络失败，或 [] 表示仓库未提供历史）；
      err        ：致命错误（仅在两者都拿不到时才有值）。
    """
    result_sig = Signal(object, object, str)

    def run(self):
        try:
            latest, err = updater.check_for_update()
            versions, verr = updater.list_versions()
            if versions is None and verr:
                # 历史版本列表不可用时仅用最新版，不阻断
                versions = []
            self.result_sig.emit(latest, versions, err or "")
        except Exception as e:
            self.result_sig.emit(None, None, str(e))


class KernelCheckWorker(QThread):
    """后台检测 ComfyUI 内核是否有新版本（仅提示，不自动更新）。"""
    result_sig = Signal(object, str)  # info dict, err

    @staticmethod
    def _current_kernel_version():
        """返回当前 ComfyUI 内核版本字符串（如 v0.34.2）。"""
        ver_file = os.path.join(comfy_launch.COMFY_DIR, "comfyui_version.py")
        try:
            if os.path.isfile(ver_file):
                ns = {}
                with open(ver_file, "r", encoding="utf-8") as f:
                    exec(compile(f.read(), ver_file, "exec"), ns)
                v = ns.get("__version__", "")
                if v:
                    return "v" + v if not v.startswith("v") else v
        except Exception:
            pass
        try:
            env = comfy_launch._comfy_env()
            r = subprocess.run(
                [comfy_launch.GIT_EXE, "-C", comfy_launch.COMFY_DIR,
                 "describe", "--tags", "--always"],
                capture_output=True, text=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                env=env, cwd=comfy_launch.COMFY_DIR)
            return r.stdout.strip() or "unknown"
        except Exception:
            return "unknown"

    @staticmethod
    def _latest_remote_tag():
        """从 origin 远程取最新 vX.Y.Z 标签。"""
        try:
            env = comfy_launch._comfy_env()
            rc, out = git_run(
                [comfy_launch.GIT_EXE, "ls-remote", "--tags", "origin"],
                cwd=comfy_launch.COMFY_DIR, timeout=NET_TIMEOUT, env=env)
            if rc != 0:
                return ""
            tags = []
            for line in (out or "").splitlines():
                parts = line.split()
                if len(parts) < 2:
                    continue
                ref = parts[1]
                if ref.startswith("refs/tags/"):
                    t = ref[len("refs/tags/"):]
                    if t.endswith("^{}"):
                        t = t[:-3]
                    if re.match(r"^v\d+\.\d+\.\d+$", t) and t not in tags:
                        tags.append(t)
            if not tags:
                return ""
            return sorted(tags, key=lambda x: updater.parse_ver(x))[-1]
        except Exception:
            return ""

    def run(self):
        try:
            current = self._current_kernel_version()
            latest = self._latest_remote_tag()
            if not latest:
                self.result_sig.emit(None, "无法获取远程内核版本")
                return
            if updater.ver_gt(latest, current):
                self.result_sig.emit({
                    "current": current,
                    "latest": latest,
                }, "")
            else:
                self.result_sig.emit(None, "")
        except Exception as e:
            self.result_sig.emit(None, str(e))


class LauncherUpdateWorker(QThread):
    """后台执行下载 + 应用补丁（或完整包）。"""
    progress_sig = Signal(int, int, str)   # done, total, msg（total=0 表示不确定）
    log_sig = Signal(str)
    done_sig = Signal(bool, str, bool)      # ok, err, exe_staged

    def __init__(self, info):
        super().__init__()
        self.info = info

    def _dl_cb(self, done, total, msg):
        self.progress_sig.emit(done, total, msg)

    def _ap_cb(self, done, total, msg):
        self.progress_sig.emit(done, total, msg)

    def run(self):
        import tempfile
        import os as _os
        info = self.info
        try:
            # 多源：updater.download_update 会在主源失败时自动切换到下一个源
            srcs = info.get("sources") or []
            if len(srcs) > 1:
                self.log_sig.emit("更新源 %d 个，已按 Git 镜像自动选择，失败自动切换。" % len(srcs))
            fd, pkg_path = tempfile.mkstemp(suffix=".zip", prefix="xiao_upd_")
            _os.close(fd)
            if info.get("patch"):
                self.log_sig.emit("正在下载增量补丁…")
            else:
                self.log_sig.emit("正在下载完整更新包（体积较大，请稍候）…")
            ok, err, kind = updater.download_update(
                info, pkg_path, progress_cb=self._dl_cb)
            if not ok:
                self.done_sig.emit(False, err or "下载失败", False)
                return
            if kind == "patch":
                self.log_sig.emit("正在应用补丁…")
                ok, err, exe = updater.apply_patch(
                    _PKG_ROOT, pkg_path, progress_cb=self._ap_cb)
            else:
                self.log_sig.emit("正在解压并覆盖…")
                ok, err, exe = updater.apply_full_zip(
                    _PKG_ROOT, pkg_path, progress_cb=self._ap_cb)
            try:
                _os.remove(pkg_path)
            except Exception:
                pass
            self.done_sig.emit(ok, err, exe)
        except Exception as e:
            self.done_sig.emit(False, "更新异常：%s" % e, False)


class LauncherUpdateDialog(QDialog):
    """启动器更新对话框：展示版本差异、下载进度、应用结果，并支持重启。"""

    def __init__(self, parent=None, info=None):
        super().__init__(parent)
        self.setWindowTitle("启动器更新")
        icon = _app_icon_path()
        if icon:
            self.setWindowIcon(QIcon(icon))
        self.info = info
        self.worker = None
        self._versions = []
        self._latest_info = None

        root = QVBoxLayout(self)
        root.setSpacing(10)
        root.setContentsMargins(20, 18, 20, 18)
        self.setMinimumWidth(420)
        self.setMaximumWidth(560)

        self.title_lbl = QLabel("")
        self.title_lbl.setStyleSheet("font-size:15px;font-weight:bold;color:#1f3a5f;")
        self.title_lbl.setWordWrap(True)
        root.addWidget(self.title_lbl)

        # 版本选择器（可回退到历史版本）
        self.ver_combo = QComboBox()
        self.ver_combo.setStyleSheet("font-size:12px;")
        self.ver_combo.setEnabled(False)
        self.ver_combo.setVisible(False)
        self.ver_combo.currentIndexChanged.connect(self._on_combo)
        root.addWidget(self.ver_combo)

        self.notes = QPlainTextEdit()
        self.notes.setReadOnly(True)
        self.notes.setMaximumHeight(110)
        self.notes.setStyleSheet("background:#f8fafc;font-size:12px;")
        root.addWidget(self.notes)

        self.bar = QProgressBar()
        self.bar.setRange(0, 0)
        self.bar.setVisible(False)   # 仅在真正下载时显示，已是最新/出错时不滚动
        root.addWidget(self.bar)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(110)
        self.log.setStyleSheet(
            "background:#0e1117;color:#d4d4d4;font-family:Consolas,monospace;font-size:11px;")
        root.addWidget(self.log)

        self.status_lbl = QLabel("")
        self.status_lbl.setWordWrap(True)
        self.status_lbl.setStyleSheet("color:#64748b;font-size:12px;")
        root.addWidget(self.status_lbl)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        self.update_btn = QPushButton("立即更新")
        self.update_btn.setStyleSheet("background:#2563eb;color:white;font-weight:bold;")
        self.update_btn.clicked.connect(self._start)
        btn_row.addWidget(self.update_btn)
        self.restart_btn = QPushButton("立即重启")
        self.restart_btn.setVisible(False)
        self.restart_btn.setStyleSheet("background:#16a34a;color:white;font-weight:bold;")
        self.restart_btn.clicked.connect(self._restart)
        btn_row.addWidget(self.restart_btn)
        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(self.cancel_btn)
        root.addLayout(btn_row)

        apply_button_fx(self)
        if info:
            self._show_info(info)
        else:
            self.title_lbl.setText("正在检查更新…")
            self.update_btn.setEnabled(False)

    def _show_info(self, info):
        self.info = info
        self.bar.setVisible(False)
        self.title_lbl.setText("目标版本：%s（当前 %s）" % (info["version"], config.APP_VERSION))
        self.notes.setPlainText(info.get("notes", ""))
        # 不向用户展示具体仓库地址（隐私保护）：仅提示已按镜像自动选择、失败自动切换
        src_txt = " 更新源已按 Git 镜像自动选择，失败自动切换。"
        mode = info.get("_mode", "patch" if info.get("patch") else "snapshot")
        if mode == "patch":
            self.status_lbl.setText("可用增量补丁，下载量很小，推荐更新。" + src_txt)
        else:
            self.status_lbl.setText("将下载该版本完整快照（含全部文件，体积较大）。" + src_txt)
        self.update_btn.setEnabled(True)

    def set_no_update(self):
        self.title_lbl.setText("已是最新版本（%s）" % config.APP_VERSION)
        self.notes.clear()
        self.status_lbl.setText("无需更新。")
        self.update_btn.setEnabled(False)
        self.bar.setVisible(False)
        self.cancel_btn.setText("确定")

    def set_error(self, msg):
        self.title_lbl.setText("检查/更新失败")
        self.status_lbl.setText(msg)
        self.update_btn.setEnabled(True)
        self.bar.setRange(0, 1)
        self.bar.setValue(0)
        self.bar.setVisible(False)

    def set_checking(self):
        self.title_lbl.setText("正在检查更新…")
        self.update_btn.setEnabled(False)
        self.bar.setVisible(False)

    def _busy(self, msg):
        self.status_lbl.setText(msg)
        self.bar.setVisible(True)
        self.bar.setRange(0, 0)
        self.update_btn.setEnabled(False)

    # ---- 版本历史：拉取、填充下拉、选择目标 ----
    def _on_fetch(self, latest, versions, err):
        """LauncherFetchWorker 回调：填充版本下拉并默认选中最新版。"""
        self._latest_info = latest if isinstance(latest, dict) else None
        self._versions = versions or []
        if not self._latest_info and not self._versions:
            if err:
                self.set_error("检查失败：%s" % err)
            else:
                self.set_no_update()
            return
        self._populate_versions(self._latest_info)
        # 默认选中最新一项（下拉第 0 项）
        self._on_combo(self.ver_combo.currentIndex())

    def _populate_versions(self, latest):
        self.ver_combo.blockSignals(True)
        self.ver_combo.clear()
        vers = []
        seen = set()
        if latest:
            vers.append(latest["version"])
            seen.add(latest["version"])
        for v in self._versions:
            if v.get("version") not in seen:
                vers.append(v["version"])
                seen.add(v["version"])
        vers.sort(key=lambda x: updater.parse_ver(x), reverse=True)
        for v in vers:
            label = v + ("（当前）" if v == config.APP_VERSION else "")
            self.ver_combo.addItem(label, v)
        self.ver_combo.blockSignals(False)
        self.ver_combo.setEnabled(True)
        self.ver_combo.setVisible(True)
        if self.ver_combo.count():
            self.ver_combo.setCurrentIndex(0)

    def _on_combo(self, idx):
        if idx < 0:
            return
        target = self.ver_combo.itemData(idx)
        if not target:
            return
        if target == config.APP_VERSION:
            self.set_no_update()
            self.update_btn.setEnabled(False)
            return
        info, err = updater.build_target_info(
            target, self._versions, self._latest_info,
            config.APP_VERSION, updater.resolve_sources())
        if err or not info:
            self.title_lbl.setText("无法更新到 %s" % target)
            self.status_lbl.setText(err or "无可用更新包")
            self.update_btn.setEnabled(False)
            self.bar.setVisible(False)
            return
        self._show_info(info)

    def _log(self, m):
        self.log.appendPlainText(m)

    def _start(self):
        if not self.info:
            return
        try:
            running = comfy_launch.is_ready(config.get_comfy_url())
        except Exception:
            running = False
        if running:
            self.set_error("ComfyUI 服务正在运行，无法覆盖文件。请先停止服务后再更新。")
            return
        try:
            stray = comfy_launch._package_runtime_pids()
        except Exception:
            stray = []
        if stray:
            try:
                comfy_launch.kill_stray_comfy_processes(logger=self._log)
                self._log("已清理包内残留进程，可安全覆盖文件。")
            except Exception as e:
                self._log("清理残留进程失败：%s" % e)
        self._busy("准备更新…")
        self.worker = LauncherUpdateWorker(self.info)
        self.worker.progress_sig.connect(self._on_progress)
        self.worker.log_sig.connect(self._log)
        self.worker.done_sig.connect(self._on_done)
        self.worker.start()

    def _on_progress(self, done, total, msg):
        if total and total > 0:
            self.bar.setRange(0, total)
            self.bar.setValue(done)
        else:
            self.bar.setRange(0, 0)
        if msg:
            self._log(msg)

    def _on_done(self, ok, err, exe_staged):
        self.bar.setRange(0, 1)
        self.bar.setValue(1)
        if ok:
            self.update_btn.setEnabled(False)
            self.cancel_btn.setText("关闭")
            if exe_staged:
                self.status_lbl.setText(
                    "已更新到 %s。启动器核心已暂存，请点击「立即重启」完成替换。"
                    % self.info["version"])
            else:
                self.status_lbl.setText("已更新到 %s，请重启软件以生效。" % self.info["version"])
            self.restart_btn.setVisible(True)
        else:
            self.set_error(err or "更新失败")
            self._log("❌ " + (err or "更新失败"))

    def _restart(self):
        # 先尝试「powershell 辅助进程」方案：等当前 app 进程退出后，
        # 由独立进程完成 启动_new.exe→启动.exe 替换并以干净环境重拉起，
        # 从而彻底避免「旧进程退出后新进程被进程组回收 / 运行中 exe 文件锁」问题。
        try:
            import updater
            if updater.schedule_restart_after_update(_PKG_ROOT, os.getpid()):
                QApplication.instance().quit()
                return
        except Exception as e:
            self._log("安排重启失败：%s" % e)
        # 兜底：直接以脱离进程组 + 干净环境拉起（不带 swap，仅保证重启）
        try:
            import subprocess as _sp
            import updater
            exe = os.path.join(_PKG_ROOT, "启动.exe")
            si = _sp.STARTUPINFO()
            si.dwFlags |= _sp.STARTF_USESHOWWINDOW
            si.wShowWindow = 0
            _sp.Popen([exe], close_fds=True, startupinfo=si,
                      creationflags=_sp.DETACHED_PROCESS | _sp.CREATE_NEW_PROCESS_GROUP,
                      env=updater._clean_env_for_launch())
        except Exception:
            pass
        QApplication.instance().quit()


# 关于对话框
# ---------------------------------------------------------------------------
class AboutDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("关于 小能ComfyUI启动器")
        icon = _app_icon_path()
        if icon:
            self.setWindowIcon(QIcon(icon))
        self.setMinimumWidth(360)
        self.setMaximumWidth(480)

        root = QVBoxLayout(self)
        root.setSpacing(14)
        root.setContentsMargins(24, 20, 24, 20)

        title = QLabel("小能ComfyUI启动器")
        title.setStyleSheet(
            "font-size:18px;font-weight:bold;color:#1f3a5f;")
        title.setAlignment(Qt.AlignCenter)
        root.addWidget(title)

        # 信息行：每行独立标签 + 行间额外间距，保证行距可控
        info_box = QWidget()
        info_lay = QVBoxLayout(info_box)
        info_lay.setContentsMargins(0, 0, 0, 0)
        info_lay.setSpacing(14)
        for _k, _v in (
            ("版本号：", config.APP_VERSION),
            ("VX：", "ai-xiaoneng"),
            ("抖音/B站：", "小能的Ai"),
            ("QQ群：", "298108127"),
            ("邮箱：", "36160686@163.com"),
            ("夸克网盘：", '<a href="https://pan.quark.cn/s/bd946eaf148d">https://pan.quark.cn/s/bd946eaf148d</a>'),
        ):
            lab = QLabel("<b>%s</b>%s" % (_k, _v))
            lab.setTextFormat(Qt.RichText)
            lab.setStyleSheet("font-size:13px;color:#334155;")
            lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
            lab.setOpenExternalLinks(True)
            lab.setWordWrap(True)
            info_lay.addWidget(lab)
        root.addWidget(info_box)

        root.addStretch(1)

        ok = QPushButton("确定")
        ok.setDefault(True)
        ok.clicked.connect(self.accept)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(ok)
        row.addStretch(1)
        root.addLayout(row)

        apply_button_fx(self)


# 赞助对话框
# ---------------------------------------------------------------------------
class SponsorDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("赞助支持")
        icon = _app_icon_path()
        if icon:
            self.setWindowIcon(QIcon(icon))
        self.setMinimumWidth(420)
        self.setMaximumWidth(520)

        root = QVBoxLayout(self)
        root.setSpacing(12)
        root.setContentsMargins(20, 18, 20, 18)

        title = QLabel("❤ 感谢赞助支持")
        title.setStyleSheet(
            "font-size:18px;font-weight:bold;color:#1f3a5f;")
        title.setAlignment(Qt.AlignCenter)
        root.addWidget(title)

        # 二维码已移除（改为在「关于」中展示联系方式），提示语不再提「扫码」
        hint = QLabel("感谢支持小能ComfyUI启动器持续更新。")
        hint.setStyleSheet("font-size:13px;color:#334155;")
        hint.setAlignment(Qt.AlignCenter)
        hint.setWordWrap(False)
        root.addWidget(hint)

        ok = QPushButton("关闭")
        ok.setDefault(True)
        ok.clicked.connect(self.accept)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(ok)
        row.addStretch(1)
        root.addLayout(row)

        apply_button_fx(self)


# ---------------------------------------------------------------------------
# 主窗口
# ---------------------------------------------------------------------------
class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        icon = _app_icon_path()
        if icon:
            self.setWindowIcon(QIcon(icon))
            # 同步设置应用级图标，任务栏/弹窗均继承
            QApplication.instance().setWindowIcon(QIcon(icon))
        self._poll_timer = QTimer()
        self._poll_timer.setInterval(1000)
        self._poll_timer.timeout.connect(self._comfy_poll_tick)
        # ComfyUI 子进程日志实时 tail：按 UTF-8 读取 comfyui_subprocess.log，
        # 同步输出到右侧日志区，避免用户用 GBK 工具打开日志看到乱码。
        self._log_tail_timer = QTimer()
        self._log_tail_timer.setInterval(1000)
        self._log_tail_timer.timeout.connect(self._tail_comfy_log)
        self._log_tail_pos = 0
        # 顶部更新提示条（启动器 / 内核）
        self._update_banner = None
        self._kernel_chk = None
        self._launcher_chk = None
        self._pending_update_info = {}  # {"launcher": info|None, "kernel": info|None}
        self._start_time = 0
        self._stop_worker = None
        self._upd_worker = None
        self._dep_worker = None
        self._dep_then_start = False
        self._is_restarting = False  # 标记「重启中」，用于区分启动/重启视觉状态
        self._build_ui()
        apply_button_fx(self)
        # 关键：不要在这里同步跑 _auto_start_comfy()。
        # 它内部会做 HTTP 探测 + socket 探测 + WMI 全进程扫描，耗时可达 1 秒以上；
        # 而这些全部阻塞在窗口首次显示之前（入口是「构造完 MainWindow 才 show()」），
        # 表现就是「双击后要等一会界面才出来」。改为窗口显示之后再执行，
        # 让主界面先秒出，状态随后刷新。
        QTimer.singleShot(50, self._auto_start_comfy)
        # 启动后静默检查启动器自身更新与 ComfyUI 内核更新，有可用版本时在顶部提示条展示
        QTimer.singleShot(2000, self._auto_check_launcher_update)
        QTimer.singleShot(2500, self._auto_check_kernel_update)

    def showEvent(self, event):
        super().showEvent(event)
        # 窗口显示后再应用一次 Windows 任务栏图标（pythonw 启动时常需要显式设置）
        _apply_windows_taskbar_icon(self)

    # ===== UI 构造 =====
    def _build_ui(self):
        self.setWindowTitle("小能ComfyUI启动器")
        self.resize(680, 520)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 8, 10, 8)
        outer.setSpacing(8)

        title = QLabel("🚀 小能ComfyUI启动器")
        title.setStyleSheet("font-size:16px;font-weight:bold;color:#1f3a5f;")
        outer.addWidget(title)

        status_frame = QHBoxLayout()
        self.status_label = QLabel("⏹ ComfyUI 未运行")
        self.status_label.setStyleSheet("font-weight:bold;color:#888;")
        status_frame.addWidget(self.status_label)
        status_frame.addStretch()
        self.version_label = QLabel(self._comfy_version() + " ｜ 启动器 %s" % config.APP_VERSION)
        self.version_label.setStyleSheet("color:#5a6a7e;")
        status_frame.addWidget(self.version_label)
        outer.addLayout(status_frame)

        # ---- 顶部更新提示条 ----
        self._update_banner = QLabel("")
        self._update_banner.setWordWrap(True)
        self._update_banner.setCursor(Qt.PointingHandCursor)
        self._update_banner.setAlignment(Qt.AlignCenter)
        self._update_banner.setStyleSheet(
            "QLabel{background:#fff7ed;color:#9a3412;border:1px solid #fdba74;"
            "border-radius:6px;padding:6px 10px;font-size:12px;}"
            "QLabel:hover{background:#ffedd5;}")
        self._update_banner.setVisible(False)
        self._update_banner.mousePressEvent = lambda _evt: self._on_update_banner_click()
        outer.addWidget(self._update_banner)

        body = QHBoxLayout()
        body.setSpacing(10)

        # ---- 左侧：按钮栏（固定宽度）----
        left_widget = QWidget()
        left_widget.setFixedWidth(150)
        left = QVBoxLayout(left_widget)
        left.setContentsMargins(0, 0, 0, 0)
        left.setSpacing(6)

        self.webui_btn = QPushButton("🌐 打开ComfyUI")
        self.webui_btn.setStyleSheet(
            "background:#2a6f97;color:white;font-weight:bold;")
        self.webui_btn.clicked.connect(self._open_webui)
        left.addWidget(self.webui_btn)

        self.start_comfy_btn = QPushButton("▶ 启动服务")
        self.start_comfy_btn.setStyleSheet(
            "background:#3a8a3a;color:white;font-weight:bold;")
        self.start_comfy_btn.clicked.connect(self._begin_start_comfy)
        left.addWidget(self.start_comfy_btn)

        self.restart_comfy_btn = QPushButton("🔄 重启服务")
        self.restart_comfy_btn.setStyleSheet(
            "background:#c77800;color:white;font-weight:bold;")
        self.restart_comfy_btn.clicked.connect(self._restart_comfy)
        left.addWidget(self.restart_comfy_btn)

        self.stop_comfy_btn = QPushButton("⏹ 停止服务")
        self.stop_comfy_btn.setStyleSheet(
            "background:#b23b3b;color:white;font-weight:bold;")
        self.stop_comfy_btn.clicked.connect(self._stop_comfy)
        self.stop_comfy_btn.setEnabled(False)  # 未运行时禁用
        left.addWidget(self.stop_comfy_btn)

        self.update_btn = QPushButton("🔄 更新")
        self.update_btn.setStyleSheet(
            "background:#2a6f97;color:white;font-weight:bold;")
        self.update_btn.clicked.connect(self._open_update_dialog)
        left.addWidget(self.update_btn)

        self.args_btn = QPushButton("⚙ 启动参数")
        self.args_btn.setStyleSheet(
            "background:#2a6f97;color:white;font-weight:bold;")
        self.args_btn.clicked.connect(self._open_args_dialog)
        left.addWidget(self.args_btn)

        self.git_mirror_btn = QPushButton("🔀 Git 镜像")
        self.git_mirror_btn.setStyleSheet(
            "background:#2a6f97;color:white;font-weight:bold;")
        self.git_mirror_btn.clicked.connect(lambda: self._open_mirror_dialog("git"))
        left.addWidget(self.git_mirror_btn)

        self.hf_mirror_btn = QPushButton("🤗 HF 镜像")
        self.hf_mirror_btn.setStyleSheet(
            "background:#2a6f97;color:white;font-weight:bold;")
        self.hf_mirror_btn.clicked.connect(lambda: self._open_mirror_dialog("hf"))
        left.addWidget(self.hf_mirror_btn)

        self.workflow_btn = QPushButton("🗂 工作流")
        self.workflow_btn.setStyleSheet(
            "background:#7a4ea3;color:white;font-weight:bold;")
        self.workflow_btn.clicked.connect(self._open_workflow_manager)
        left.addWidget(self.workflow_btn)

        self.plugin_btn = QPushButton("🧩 插件")
        self.plugin_btn.setStyleSheet(
            "background:#7a4ea3;color:white;font-weight:bold;")
        self.plugin_btn.clicked.connect(self._open_plugin_manager)
        left.addWidget(self.plugin_btn)

        self.terminal_btn = QPushButton("💻 终端")
        self.terminal_btn.setStyleSheet(
            "background:#444;color:white;font-weight:bold;")
        self.terminal_btn.setToolTip(
            "以管理员权限打开已激活 venv + 内置 git 的 cmd，便于手动安装插件 / 调试")
        self.terminal_btn.clicked.connect(self._open_terminal)
        left.addWidget(self.terminal_btn)

        self.sponsor_btn = QPushButton("❤ 赞助")
        self.sponsor_btn.setStyleSheet(
            "background:#ec4899;color:white;font-weight:bold;")
        self.sponsor_btn.setToolTip("点击查看赞助二维码")
        self.sponsor_btn.clicked.connect(self._open_sponsor)
        left.addWidget(self.sponsor_btn)

        self.about_btn = QPushButton("ℹ 关于")
        self.about_btn.setStyleSheet(
            "background:#6b7280;color:white;font-weight:bold;")
        self.about_btn.clicked.connect(self._open_about)
        left.addWidget(self.about_btn)

        self.close_btn = QPushButton("⏻ 关闭")
        self.close_btn.clicked.connect(self.close)
        left.addWidget(self.close_btn)

        left.addStretch(1)
        body.addWidget(left_widget)

        # ---- 右侧：设置 + 日志 ----
        right = QVBoxLayout()
        right.setSpacing(8)
        right.setContentsMargins(0, 0, 0, 0)

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)

        grid.addWidget(QLabel("ComfyUI 地址"), 0, 0)
        self.url_edit = QLineEdit(config.get_comfy_url())
        grid.addWidget(self.url_edit, 0, 1)
        self.test_btn = QPushButton("测试")
        self.test_btn.clicked.connect(self._test_connection)
        grid.addWidget(self.test_btn, 0, 2)

        grid.addWidget(QLabel("模型路径"), 1, 0)
        self.model_dir_edit = QLineEdit(config.get_model_dir_display())
        grid.addWidget(self.model_dir_edit, 1, 1)
        self.model_default = QPushButton("默认")
        self.model_default.setToolTip("恢复 ComfyUI 默认路径（软件内 ComfyUI\\models，跟随软件移动）")
        self.model_default.clicked.connect(self._reset_model_dir)
        grid.addWidget(self.model_default, 1, 2)
        self.model_browse = QPushButton("选择")
        self.model_browse.clicked.connect(self._pick_model_dir)
        grid.addWidget(self.model_browse, 1, 3)
        # 变更后自动保存（失焦 / 回车）；点「选择」也会在 _pick_model_dir 里保存
        self.model_dir_edit.editingFinished.connect(self._apply_model_dir)

        grid.addWidget(QLabel("INPUT 目录"), 2, 0)
        self.input_dir_edit = QLineEdit(config.get_input_dir_display())
        self.input_dir_edit.setToolTip(
            "ComfyUI 的 INPUT 目录（如 Load Image 节点默认读取位置）。\n"
            "选择「默认」则使用 ComfyUI/input（随启动器所在位置变化）；"
            "选择「选择」可自定义外部目录。")
        grid.addWidget(self.input_dir_edit, 2, 1)
        self.input_default = QPushButton("默认")
        self.input_default.setToolTip("恢复默认路径：%s" % config.INPUT_DIR_DISPLAY_DEFAULT)
        self.input_default.clicked.connect(self._reset_input_dir)
        grid.addWidget(self.input_default, 2, 2)
        self.input_browse = QPushButton("选择")
        self.input_browse.clicked.connect(self._pick_input_dir)
        grid.addWidget(self.input_browse, 2, 3)
        self.input_dir_edit.editingFinished.connect(self._apply_input_dir)

        grid.addWidget(QLabel("OUTPUT 目录"), 3, 0)
        self.output_dir_edit = QLineEdit(config.get_output_dir_display())
        self.output_dir_edit.setToolTip(
            "ComfyUI 的 OUTPUT 目录（图片/视频默认保存位置）。\n"
            "选择「默认」则使用 ComfyUI/output（随启动器所在位置变化）；"
            "选择「选择」可自定义外部目录。")
        grid.addWidget(self.output_dir_edit, 3, 1)
        self.output_default = QPushButton("默认")
        self.output_default.setToolTip("恢复默认路径：%s" % config.OUTPUT_DIR_DISPLAY_DEFAULT)
        self.output_default.clicked.connect(self._reset_output_dir)
        grid.addWidget(self.output_default, 3, 2)
        self.output_browse = QPushButton("选择")
        self.output_browse.clicked.connect(self._pick_output_dir)
        grid.addWidget(self.output_browse, 3, 3)
        self.output_dir_edit.editingFinished.connect(self._apply_output_dir)

        right.addLayout(grid)

        # 插件依赖注册开关
        dep_row = QHBoxLayout()
        dep_row.setSpacing(8)
        self.dep_check_cb = QCheckBox("启动服务时检查并注册插件依赖")
        self.dep_check_cb.setChecked(config.get_check_plugin_deps())
        self.dep_check_cb.setToolTip(
            "开启后，每次启动服务前扫描包内插件目录（ComfyUI/custom_nodes）下所有插件\n"
            "的 requirements.txt / pyproject 依赖，缺失的自动 pip 安装到包内 venv，\n"
            "并逐条输出每个插件的注册状态，便于确认新插件是否注册成功。")
        self.dep_check_cb.stateChanged.connect(self._on_dep_check_toggle)
        dep_row.addWidget(self.dep_check_cb)
        self.dep_now_btn = QPushButton("🔌 立即注册依赖")
        self.dep_now_btn.setToolTip("不启动服务，立即检查并安装当前插件目录下缺失的依赖")
        self.dep_now_btn.clicked.connect(self._register_deps_now)
        dep_row.addWidget(self.dep_now_btn)
        dep_row.addStretch(1)
        right.addLayout(dep_row)

        self.log_edit = QPlainTextEdit()
        self.log_edit.setReadOnly(True)
        self.log_edit.setMinimumHeight(150)
        self.log_edit.setStyleSheet(
            "background:#0e1117;color:#d4d4d4;font-family:Consolas,monospace;font-size:12px;")
        right.addWidget(self.log_edit, 1)

        # 更新进度条（不确定模式）：执行「更新」类长任务时滚动显示，避免误以为卡死
        self.update_progress = QProgressBar()
        self.update_progress.setTextVisible(False)
        self.update_progress.setRange(0, 0)
        self.update_progress.setFixedHeight(6)
        self.update_progress.setStyleSheet(
            "QProgressBar{background:#1b2230;border-radius:3px;}"
            "QProgressBar::chunk{background:#3a8a3a;border-radius:3px;}")
        self.update_progress.hide()
        right.addWidget(self.update_progress)

        # 启动/重启进度条（确定模式）：分阶段推进 0→100%，用于确认启动进度
        self.start_progress = QProgressBar()
        self.start_progress.setTextVisible(True)
        self.start_progress.setFormat("%p%")
        self.start_progress.setRange(0, 100)
        self.start_progress.setValue(0)
        self.start_progress.setFixedHeight(10)
        self.start_progress.setStyleSheet(
            "QProgressBar{background:#1b2230;border-radius:3px;color:#d4d4d4;}"
            "QProgressBar::chunk{background:#2a6f97;border-radius:3px;}")
        self.start_progress.hide()
        right.addWidget(self.start_progress)

        body.addLayout(right, 1)
        outer.addLayout(body)

    # ===== 日志 / 状态 =====
    def _log(self, msg):
        self.log_edit.appendPlainText(time.strftime("[%H:%M:%S] ") + msg)
        self.log_edit.moveCursor(QTextCursor.End)

    def _append_raw_log_lines(self, lines):
        """把 ComfyUI 子进程原始日志行追加到日志区（不加盖启动器时间戳）。"""
        for ln in lines:
            if not ln:
                continue
            # 去掉 ANSI 颜色码，避免 QPlainTextEdit 显示 "←[32m"
            ln = _ANSI_RE.sub("", ln)
            self.log_edit.appendPlainText(ln)
        if lines:
            self.log_edit.moveCursor(QTextCursor.End)

    def _tail_comfy_log(self):
        """实时 tail ComfyUI 子进程日志文件到右侧日志区，按 UTF-8 解码。

        同时做防倒退处理：若日志文件被清空/重建，则从头读。
        """
        p = comfy_launch._comfy_log_path()
        if not os.path.isfile(p):
            return
        try:
            size = os.path.getsize(p)
            if size < self._log_tail_pos:
                self._log_tail_pos = 0
            if size == self._log_tail_pos:
                return
            with open(p, "rb") as f:
                f.seek(self._log_tail_pos)
                chunk = f.read()
                self._log_tail_pos = f.tell()
            if not chunk:
                return
            # 如果从头开始读且文件有 UTF-8 BOM，跳过 BOM，避免日志首行出现零宽字符。
            if self._log_tail_pos == 0 and chunk.startswith(b"\xef\xbb\xbf"):
                chunk = chunk[3:]
            text = chunk.decode("utf-8", errors="replace")
            self._append_raw_log_lines(text.splitlines())
        except Exception:
            pass

    def _set_status(self, running):
        """running: True=运行中, False=未运行, None=启动中"""
        self._is_restarting = False
        if running is True:
            self.status_label.setText("⏹ ComfyUI 运行中")
            self.status_label.setStyleSheet("font-weight:bold;color:#2e9e4f;")
            self.start_comfy_btn.setEnabled(False)
            self.restart_comfy_btn.setEnabled(True)
            self.stop_comfy_btn.setEnabled(True)
        elif running is False:
            self.status_label.setText("⏹ ComfyUI 未运行")
            self.status_label.setStyleSheet("font-weight:bold;color:#888;")
            self.start_comfy_btn.setEnabled(True)
            self.restart_comfy_btn.setEnabled(False)
            self.stop_comfy_btn.setEnabled(False)
        else:
            self.status_label.setText("🟡 ComfyUI 启动中…")
            self.status_label.setStyleSheet("font-weight:bold;color:#c77800;")
            self.start_comfy_btn.setEnabled(False)
            self.restart_comfy_btn.setEnabled(False)
            self.stop_comfy_btn.setEnabled(False)

    def _set_restarting(self):
        """重启中状态：启动按钮亮起、重启按钮变灰，便于一眼识别处于「重启」而非「首次启动」。"""
        self._is_restarting = True
        self.status_label.setText("🔄 ComfyUI 重启中…")
        self.status_label.setStyleSheet("font-weight:bold;color:#c77800;")
        self.start_comfy_btn.setEnabled(True)    # 亮起
        self.restart_comfy_btn.setEnabled(False)  # 变灰
        self.stop_comfy_btn.setEnabled(False)

    def _set_busy_state(self):
        """启动/重启中统一入口：重启时走 _set_restarting（启动按钮亮起）做视觉区分，否则走 _set_status(None)。"""
        if getattr(self, "_is_restarting", False):
            self._set_restarting()
        else:
            self._set_status(None)

    # ---- 启动/重启进度条 ----
    def _show_start_progress(self, pct, text=""):
        self.start_progress.show()
        self.start_progress.setRange(0, 100)
        self.start_progress.setValue(pct)
        self.start_progress.setFormat("%p%" + ("  " + text if text else ""))

    def _hide_start_progress(self):
        self.start_progress.setRange(0, 100)
        self.start_progress.setValue(0)
        self.start_progress.setFormat("%p%")
        self.start_progress.hide()

    def _comfy_version(self):
        """返回「软件版本 | 内核版本」字符串。

        - 内核版本 = ComfyUI 程序本体版本（如 v0.34.0），优先读 comfyui_version.py，
          失败回退 git describe。
        - 软件版本 = 依赖环境（torch / cuda 等）。
        """
        # 内核版本：ComfyUI 版本（优先 comfyui_version.py，失败回退 git describe）
        kernel_ver = "unknown"
        try:
            ver_file = os.path.join(comfy_launch.COMFY_DIR, "comfyui_version.py")
            if os.path.isfile(ver_file):
                ns = {}
                with open(ver_file, "r", encoding="utf-8") as f:
                    exec(compile(f.read(), ver_file, "exec"), ns)
                kernel_ver = ns.get("__version__", "unknown")
        except Exception:
            pass
        if not kernel_ver or kernel_ver == "unknown":
            try:
                env = comfy_launch._comfy_env()
                r = subprocess.run(
                    [comfy_launch.GIT_EXE, "-C", comfy_launch.COMFY_DIR,
                     "describe", "--tags", "--always"],
                    capture_output=True, text=True,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    env=env, cwd=comfy_launch.COMFY_DIR)
                kernel_ver = r.stdout.strip() or "unknown"
            except Exception:
                pass

        # 软件版本：venv 中的 torch + cuda 版本
        software_ver = "unknown"
        try:
            if os.path.isfile(comfy_launch.COMFY_PYTHON):
                r = subprocess.run(
                    [comfy_launch.COMFY_PYTHON, "-c",
                     "import torch; print(torch.__version__); print(torch.version.cuda or 'cpu')"],
                    capture_output=True, text=True,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    cwd=comfy_launch.COMFY_DIR)
                parts = r.stdout.strip().splitlines()
                if len(parts) >= 2:
                    software_ver = "torch %s (cuda %s)" % (parts[0], parts[1])
                elif parts:
                    software_ver = "torch %s" % parts[0]
        except Exception:
            pass

        return "环境 %s | 内核 v%s" % (software_ver, kernel_ver)

    # ===== 启动 / 停止 =====
    def _auto_start_comfy(self):
        """启动后探测 ComfyUI 状态并清理包内残留进程。

        探测包含 HTTP / 端口 / **WMI 全进程扫描**，耗时可达数秒，因此必须放进
        工作线程：放主线程会阻塞 Qt 事件循环，用户看到的就是「窗口刚显示出来，
        一动就提示未响应」。日志与状态经信号排队回到主线程再更新 UI。
        """
        # 保持引用，避免线程运行期间 worker 被 GC
        self._probe_worker = StartupProbeWorker()
        self._probe_worker.log_sig.connect(self._log)
        self._probe_worker.status_sig.connect(self._set_status)
        self._probe_worker.start()

    def _begin_start_comfy(self, from_restart=False):
        # 重启进行中：启动按钮虽亮起，但用户点击会触发重复派发，需拦截；
        # 重启自身调用（from_restart=True）则放行。
        if getattr(self, "_is_restarting", False) and not from_restart:
            self._log("⚠ 正在重启中，请稍候，不要重复点击启动。")
            return
        # 清洗旧配置：确保工作流/插件目录固定为包内默认、不做外部目录映射；
        # 同时把指向旧包根（如 D:\\WorkBuddy\\...）的绝对路径清空，避免迁移后断裂。
        try:
            config.reset_internal_dirs()
            config.sanitize_settings()
        except Exception:
            pass
        if comfy_launch.is_ready(config.get_comfy_url()):
            self._log("✅ ComfyUI 已在运行：%s" % config.get_comfy_url())
            self._set_status(True)
            return
        self._show_start_progress(10, "清洗配置")
        # 开关打开时：先注册插件依赖，成功/失败后都继续启动服务
        if self.dep_check_cb.isChecked():
            self._run_dep_check(then_start=True)
            return
        self._spawn_after_dep_check()

    def _spawn_after_dep_check(self):
        self._apply_model_dir()
        user_args = config.get_extra_args()

        # 无 NVIDIA 显卡时自动 fallback 到 CPU 模式（不污染用户保存的参数）
        extra_args = user_args
        tokens = shlex.split(user_args.lower())
        is_cpu_mode = any(t in ("--cpu", "--cpu-only") for t in tokens)
        if not is_cpu_mode:
            health = comfy_launch.cuda_health_check()
            # 仅在「torch 正常导入 且 确实检测不到 NVIDIA 显卡」时才自动补 --cpu；
            # 探测出错（如 torch 缺失/导入失败）属误报，绝不擅自增加 --cpu，
            # 以免污染用户填写的启动参数。
            if health.get("device_count", 0) == 0 and not health.get("error"):
                # --cpu 与 --lowvram/--highvram/--gpu-only/--novram 在 ComfyUI 中互斥
                gpu_tokens = ["--lowvram", "--highvram", "--gpu-only", "--novram"]
                keep = [t for t in shlex.split(user_args) if t.lower() not in gpu_tokens]
                removed = [t for t in shlex.split(user_args) if t.lower() in gpu_tokens]
                extra_args = " ".join(keep + ["--cpu"]).strip()
                self._log("⚠ 未检测到 NVIDIA 显卡（CUDA 设备数=0），已自动切换为 CPU 模式启动。")
                if removed:
                    self._log("   已移除与 --cpu 冲突的参数：%s" % ", ".join(removed))

        self._log("🟡 正在后台启动 ComfyUI…")
        self._set_busy_state()
        self._show_start_progress(45, "正在加载 ComfyUI 模块…")
        # 启动实时日志 tail：从文件开头读，避免之前旧日志混入本次启动。
        self._log_tail_pos = 0
        self._log_tail_timer.start()
        comfy_launch.spawn_comfyui(silent=True, logger=self._log, extra_args=extra_args)
        self._start_time = time.time()
        self._poll_timer.start()

    # ===== 插件依赖注册 =====
    def _on_dep_check_toggle(self, state):
        on = bool(state)
        config.set_check_plugin_deps(on)
        self._log("🧩 启动检查插件依赖注册：%s" % ("开启" if on else "关闭"))

    def _run_dep_check(self, then_start=False):
        """后台执行依赖注册；then_start=True 时完成后接着启动服务。"""
        if self._dep_worker is not None and self._dep_worker.isRunning():
            self._log("⚠ 依赖注册正在执行，请稍候…")
            return
        self._dep_then_start = then_start
        self._dep_worker = PluginDepWorker(install=True)
        self._dep_worker.log_sig.connect(self._log)
        self._dep_worker.done_sig.connect(self._on_dep_done)
        if then_start:
            self._set_busy_state()
            self.status_label.setText(
                "🔄 正在检查插件依赖…" if getattr(self, "_is_restarting", False)
                else "🟡 正在检查插件依赖…")
            self._show_start_progress(20, "检查插件依赖")
        self.start_comfy_btn.setEnabled(False)
        self.dep_now_btn.setEnabled(False)
        self._dep_worker.start()

    def _register_deps_now(self):
        self._log("🔌 开始检查插件依赖注册（不启动服务）…")
        self._run_dep_check(then_start=False)

    def _on_dep_done(self, ok, summary, results):
        self.start_comfy_btn.setEnabled(True)
        self.dep_now_btn.setEnabled(True)
        self._log(summary)
        for name, status, detail in (results or []):
            if status in ("待注册", "注册失败"):
                self._log("   ⚠ %s：%s %s" % (name, status, detail))
        if self._dep_then_start:
            self._dep_then_start = False
            if not ok:
                self._log("⚠ 依赖注册未全部完成，仍继续启动服务（可在日志中查看失败项）")
            self._show_start_progress(35, "依赖检查完成，准备启动…")
            self._spawn_after_dep_check()
        else:
            self._set_status(comfy_launch.is_ready(config.get_comfy_url()))

    def _comfy_poll_tick(self):
        # 启动/重启进度条：等待服务就绪期间缓慢推进（45%→90%），给出「进度在动」的反馈
        if self.start_progress.isVisible() and self.start_progress.value() < 90:
            self.start_progress.setValue(self.start_progress.value() + 3)
        if comfy_launch.is_ready(config.get_comfy_url()):
            self._poll_timer.stop()
            self._log_tail_timer.stop()
            self._tail_comfy_log()  # 最后再刷一次，避免末尾丢失
            self._set_status(True)
            self._show_start_progress(100, "已就绪")
            self._log("✅ ComfyUI 已就绪：%s" % config.get_comfy_url())
            # 完成后短暂停留再隐藏进度条
            QTimer.singleShot(1200, self._hide_start_progress)
            return
        proc = comfy_launch._proc
        if proc is not None and proc.poll() is not None:
            self._poll_timer.stop()
            self._log_tail_timer.stop()
            self._tail_comfy_log()
            self._log("❌ ComfyUI 进程已退出，启动失败。日志尾部：")
            self._dump_log_tail()
            self._hide_start_progress()
            self._set_status(False)
            return
        if time.time() - self._start_time > 180:
            self._poll_timer.stop()
            self._log_tail_timer.stop()
            self._tail_comfy_log()
            self._log("⏱ 启动超时（180s）。日志位置：%s" % comfy_launch._comfy_log_path())
            self._dump_log_tail()
            self._hide_start_progress()
            self._set_status(False)

    def _dump_log_tail(self):
        try:
            p = comfy_launch._comfy_log_path()
            if not os.path.isfile(p):
                return
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                lines = f.read().splitlines()[-30:]
            has_cuda_crash = False
            for ln in lines:
                low = ln.lower()
                self._log("   " + ln)
                if any(k in low for k in ("access violation", "cuda", "cudart",
                                           "nvcuda", "torch.cuda", "nvidia")):
                    has_cuda_crash = True
            if has_cuda_crash:
                self._log("---")
                self._log("💡 疑似 CUDA/显卡驱动不兼容。可尝试：")
                self._log("   1) 在「启动参数」里加 --cpu 临时用 CPU 模式启动；")
                self._log("   2) 更新本机 NVIDIA 显卡驱动到最新版；")
                self._log("   3) 点「更新→环境依赖」，安装与本机驱动 CUDA 版本匹配的 PyTorch。")
        except Exception:
            pass

    def _restart_comfy(self):
        self._log("🔄 正在重启 ComfyUI…")
        self._is_restarting = True
        self._set_restarting()
        self._show_start_progress(5, "停止旧服务")
        comfy_launch.stop_comfyui(timeout=5, logger=self._log)
        self._begin_start_comfy(from_restart=True)

    def _stop_comfy(self):
        self.stop_comfy_btn.setEnabled(False)
        self._log("🛑 正在停止 ComfyUI…")
        self._stop_worker = StopComfyWorker()
        self._stop_worker.log_sig.connect(self._log)
        self._stop_worker.finished_sig.connect(self._on_comfy_stopped)
        self._stop_worker.start()

    def _on_comfy_stopped(self, ok):
        self._poll_timer.stop()
        self._log_tail_timer.stop()
        self._tail_comfy_log()
        self._hide_start_progress()
        self._set_status(False)
        self._log("✅ ComfyUI 已停止" if ok else "⚠ 已尝试停止，但端口仍被占用")
        self._release_package_files()

    def _release_package_files(self):
        """停止后兜底清理：确保没有任何包内进程仍加载着包内文件。

        ComfyUI 子进程是 detached 派生的，若上一次被强杀/启动器直接关闭，
        可能残留后台进程继续占用 custom_nodes 里的 .pyd/.dll，
        导致复制/替换插件目录时报「文件被占用」。
        """
        killed = comfy_launch.kill_stray_comfy_processes(logger=self._log)
        if killed:
            self._log("🧹 已结束残留的包内进程 PID=%s" % ",".join(str(p) for p in killed))
        self._log("🔓 包内文件已解除占用，可安全复制/替换 custom_nodes 等目录")

    def closeEvent(self, event):
        """关闭按钮：永远弹窗询问「关闭 / 最小化到托盘 / 取消」。
        - 已在托盘 → 直接忽略事件（不弹窗）；
        - 用户正在被 QApplication.quit 主动清理 → 走正常关闭流程。
        """
        # 1) 已经在托盘 / 主窗口已隐藏：忽略事件即可，不弹窗
        if self.isHidden():
            event.ignore()
            return
        # 2) 应用退出阶段（不再弹窗，否则会卡住退出动画）
        if getattr(self, "_quitting", False):
            event.accept()
            self._exit_cleanup_async(stop=self._quitting_stop)
            return
        # 探测 ComfyUI 是否在跑（端口+廉价 HTTP，1 秒超时）
        comfy_running = False
        try:
            _, port = comfy_launch._host_port(config.get_comfy_url())
            if comfy_launch._port_in_use(port):
                comfy_running = bool(comfy_launch.is_ready(config.get_comfy_url(), timeout=1))
        except Exception:
            comfy_running = False
        box = QMessageBox(self)
        box.setWindowTitle("关闭启动器")
        box.setIcon(QMessageBox.Question)
        box.setText(
            "请选择关闭方式：\n\n"
            "· 「停止服务并关闭」会停止 ComfyUI（如在运行）并退出启动器；\n"
            "· 「仅关闭启动器 UI」隐藏主窗口到托盘，ComfyUI 继续运行；\n"
            "· 「取消」不关闭。")
        stop_btn = box.addButton("停止服务并关闭", QMessageBox.AcceptRole)
        tray_btn = box.addButton("仅关闭启动器 UI", QMessageBox.DestructiveRole)
        cancel_btn = box.addButton("取消", QMessageBox.RejectRole)
        box.setDefaultButton(cancel_btn)
        box.exec()
        clicked = box.clickedButton()
        if clicked is cancel_btn:
            event.ignore()
            return
        if clicked is tray_btn:
            event.ignore()
            self._hide_to_tray()
            return
        # 真正关闭：用户已明确选择「停止服务并关闭」，无论实时探测是否成功都务必停止 ComfyUI
        # （探测走 HTTP is_ready，服务加载中/响应慢可能误判为未运行，导致本应停止的服务被漏杀）。
        self._quitting = True
        self._quitting_stop = True
        event.accept()
        self.hide()
        self._exit_cleanup_async(stop=True)

    def _hide_to_tray(self):
        """隐藏窗口到系统托盘（首次调用时按需创建托盘图标）。"""
        tray = getattr(self, "_tray_icon", None)
        if tray is None:
            tray = QSystemTrayIcon(self)
            icon_path = _app_icon_path()
            if icon_path:
                tray.setIcon(QIcon(icon_path))
            else:
                tray.setIcon(self.windowIcon())
            tray.setToolTip("小能ComfyUI启动器（点击还原）")
            menu = QMenu()
            act_show = menu.addAction("显示主窗口")
            act_quit = menu.addAction("退出启动器")
            act_show.triggered.connect(self._restore_from_tray)
            act_quit.triggered.connect(self._quit_from_tray)
            tray.setContextMenu(menu)
            tray.activated.connect(self._on_tray_activated)
            self._tray_icon = tray
            tray.show()
        self.hide()
        try:
            tray.showMessage(
                "小能ComfyUI启动器",
                "已最小化到托盘，双击图标可还原主窗口。",
                QSystemTrayIcon.Information, 2500)
        except Exception:
            pass

    def _restore_from_tray(self):
        if not self.isVisible():
            self.showNormal()
        self.activateWindow()
        self.raise_()

    def _on_tray_activated(self, reason):
        if reason in (QSystemTrayIcon.DoubleClick, QSystemTrayIcon.Trigger):
            self._restore_from_tray()

    def _quit_from_tray(self):
        """从托盘菜单退出启动器：绕过 closeEvent 的弹窗，直接走真正关闭路径。"""
        tray = getattr(self, "_tray_icon", None)
        if tray:
            tray.hide()
        self._quitting = True
        # 探测是否需要停 ComfyUI：端口被占用即尝试停止（比 is_ready 更可靠，
        # 避免服务加载中/响应慢被误判为未运行而漏杀）
        comfy_running = False
        try:
            _, port = comfy_launch._host_port(config.get_comfy_url())
            comfy_running = comfy_launch._port_in_use(port)
        except Exception:
            comfy_running = False
        self._quitting_stop = comfy_running
        self._exit_cleanup_async(stop=comfy_running)

    def _exit_cleanup_async(self, stop):
        """后台执行退出清理，保证窗口已立即关闭、不阻塞 UI。

        - stop=True：停止 ComfyUI（内部已含 PowerShell 兜底清理），完成后退出进程；
        - stop=False（保持运行）：不触碰任何包内进程，直接退出，秒关。
        """
        if not stop:
            # 保持运行并退出：不杀任何进程，直接退出（秒关）
            QApplication.instance().quit()
            return
        # 防重入：closeEvent 在退出阶段可能被二次触发，重复启动 QThread 会
        # 让上一个线程对象失去引用而被回收（运行中的 QThread 被销毁会崩溃）。
        if getattr(self, "_exit_cleanup_started", False):
            return
        self._exit_cleanup_started = True
        # 使用 QThread（非 daemon），确保 stop_comfyui 完整执行完再退出应用；
        # daemon threading.Thread 可能在主事件循环结束前被强制中断，留下 8190 占用。
        self._exit_worker = StopComfyWorker(self)
        self._exit_worker.log_sig.connect(self._log)
        self._exit_worker.finished_sig.connect(lambda _ok: QApplication.instance().quit())
        # 安全兜底：即使 stop_comfyui 内部阻塞，30 秒后强制退出应用
        QTimer.singleShot(30000, lambda: QApplication.instance().quit())
        self._exit_worker.start()

    # ===== 打开网页 / 工作流 =====
    def _detect_chromium(self):
        """检测本机 Chromium 系浏览器（Chrome / Edge），返回 exe 路径或 None。"""
        pf = os.environ.get("ProgramFiles", "C:\\Program Files")
        pf86 = os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)")
        candidates = [
            os.path.join(pf, "Google\\Chrome\\Application\\chrome.exe"),
            os.path.join(pf86, "Google\\Chrome\\Application\\chrome.exe"),
            os.path.join(pf, "Microsoft\\Edge\\Application\\msedge.exe"),
            os.path.join(pf86, "Microsoft\\Edge\\Application\\msedge.exe"),
        ]
        for c in candidates:
            if c and os.path.isfile(c):
                return c
        return None

    def _open_webui(self):
        url = config.get_comfy_url()
        # 让「另存图片」默认落到 output 目录（不锁定，仍可自由切换路径）。
        out_dir = config.get_output_dir()
        try:
            os.makedirs(out_dir, exist_ok=True)
        except Exception:
            pass
        exe = self._detect_chromium()
        if exe:
            # 包内独立浏览器配置：保证 --download-default-directory 每次生效，
            # 且不污染用户主浏览器的登录态/扩展；配置随包移动自包含。
            profile = os.path.join(comfy_launch.COMFY_DIR, ".launcher_browser")
            try:
                subprocess.Popen(
                    [exe,
                     "--download-default-directory=%s" % out_dir,
                     "--user-data-dir=%s" % profile,
                     "--no-first-run", "--new-window", url],
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                self._log("🌐 打开网页：%s" % url)
                self._log("📁 图片默认保存目录：%s" % out_dir)
                return
            except Exception as e:
                self._log("⚠ 自定义浏览器启动失败，改用系统默认：%s" % e)
        webbrowser.open(url)
        self._log("🌐 打开网页：%s" % url)

    # ===== 插件 / 终端 / 更新 =====
    def _open_workflow_manager(self):
        dlg = WorkflowManagerDialog(self)
        dlg.exec()

    def _open_plugin_manager(self):
        dlg = PluginManagerDialog(self)
        dlg.exec()

    def _open_terminal(self):
        bat = os.path.join(_PKG_ROOT, "tools", "debug_terminal.bat")
        venv_act = os.path.join(comfy_launch.COMFY_DIR, ".venv", "Scripts", "activate.bat")
        content = (
            "@echo off\n"
            "chcp 65001 >nul\n"
            "call \"%s\"\n"
            "cd /d \"%s\"\n"
            "echo ComfyUI 终端（已激活 venv + 内置 git）\n"
            "cmd /k\n"
        ) % (venv_act, comfy_launch.COMFY_DIR)
        try:
            os.makedirs(os.path.dirname(bat), exist_ok=True)
            with open(bat, "w", encoding="utf-8") as f:
                f.write(content)
        except Exception as e:
            self._log("生成终端脚本失败：%s" % e)
            return
        try:
            from ctypes import windll
            windll.shell32.ShellExecuteW(None, "runas", bat, "", "", 1)
            self._log("💻 已请求以管理员权限打开终端")
        except Exception as e:
            self._log("打开终端失败：%s" % e)

    def _open_about(self):
        dlg = AboutDialog(self)
        dlg.exec()

    def _open_sponsor(self):
        dlg = SponsorDialog(self)
        dlg.exec()

    # ===== 启动器自身增量更新 =====
    def _auto_check_launcher_update(self):
        """启动后静默检查启动器自身更新；有增量补丁且 ComfyUI 未运行时自动应用，否则在顶部提示条展示。"""
        if not config.get_update_urls():
            return
        self._lchk = LauncherCheckWorker()
        self._lchk.found_sig.connect(self._on_launcher_check)
        self._lchk.start()

    def _on_launcher_check(self, info, err):
        if err:
            self._log("ℹ 启动器更新检查：%s" % err)
            return
        if not info:
            return  # 已是最新
        self._pending_update_info["launcher"] = info
        self._refresh_update_banner()
        src_note = "（更新源已按 Git 镜像自动选择，失败自动切换）" if info.get("source") else ""
        # 仅顶部提示条提醒：不自动下载、不弹窗。由用户点击顶部提示条手动打开更新窗口。
        self._log("🔔 发现新版本 %s，已置顶提示；需要更新请点击顶部提示条打开更新窗口。%s"
                  % (info["version"], src_note))

    def _auto_check_kernel_update(self):
        """启动后静默检查 ComfyUI 内核是否有新版本，有则顶部提示条展示。"""
        if not os.path.isdir(os.path.join(comfy_launch.COMFY_DIR, ".git")):
            return
        self._kernel_chk = KernelCheckWorker()
        self._kernel_chk.result_sig.connect(self._on_kernel_check)
        self._kernel_chk.start()

    def _on_kernel_check(self, info, err):
        if err:
            self._log("ℹ 内核更新检查：%s" % err)
            return
        if not info:
            return  # 已是最新或无法比较
        self._pending_update_info["kernel"] = info
        self._refresh_update_banner()
        self._log("🔔 发现 ComfyUI 内核新版本 %s（当前 %s），可在「更新」→「ComfyUI 内核更新」中升级。"
                  % (info.get("latest"), info.get("current")))

    def _refresh_update_banner(self):
        """根据待更新信息刷新顶部提示条。"""
        launcher = self._pending_update_info.get("launcher")
        kernel = self._pending_update_info.get("kernel")
        parts = []
        if launcher and isinstance(launcher, dict):
            parts.append("🚀 启动器有更新：%s" % launcher.get("version", ""))
        if kernel and isinstance(kernel, dict):
            parts.append("⚙ 内核有更新：%s（当前 %s）" % (
                kernel.get("latest", ""), kernel.get("current", "")))
        if not parts:
            self._update_banner.setVisible(False)
            return
        text = " ｜ ".join(parts) + "  → 点击前往更新"
        self._update_banner.setText(text)
        self._update_banner.setVisible(True)

    def _on_update_banner_click(self):
        """点击顶部提示条：优先打开启动器更新；若无启动器更新则打开内核更新。"""
        launcher = self._pending_update_info.get("launcher")
        kernel = self._pending_update_info.get("kernel")
        if launcher and isinstance(launcher, dict):
            self._open_launcher_update()
        elif kernel and isinstance(kernel, dict):
            self._open_update_dialog_with_kernel()

    def _open_update_dialog_with_kernel(self):
        """直接打开 ComfyUI 内核正式版版本选择并执行更新。"""
        dlg = KernelVersionDialog(self, dev=False)
        if dlg.exec() != QDialog.Accepted:
            return
        target = dlg.target()
        self._log("🔄 开始执行：ComfyUI 内核更新（正式版）（目标：%s）" % (target or "最新稳定版"))
        self.update_btn.setEnabled(False)
        self.update_progress.show()
        self._upd_worker = UpdateWorker("kernel_stable", env_details=None, kernel_target=target)
        self._upd_worker.log_sig.connect(self._on_update_log)
        self._upd_worker.done_sig.connect(self._on_update_done)
        self._upd_worker.start()

    def _open_launcher_update(self):
        """手动打开启动器更新（含历史版本选择）。

        安全要点：dlg / fetch 必须保持引用直到关闭，且信号直连对话框方法；
        否则方法返回后局部对象被 GC、后台线程回调已销毁对象会闪退。
        """
        dlg = LauncherUpdateDialog(self, None)
        self._lupd_dlg = dlg
        dlg.setWindowTitle("启动器更新")
        dlg.title_lbl.setText("正在检查更新…")
        dlg.update_btn.setEnabled(False)
        fetch = LauncherFetchWorker()
        self._lupd_fetch = fetch
        fetch.result_sig.connect(dlg._on_fetch)
        fetch.start()
        dlg.exec()

    def _open_update_dialog(self):
        dlg = UpdateDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return
        choice, env_details, kernel_target = dlg.choice()
        if not choice:
            return
        names = {
            "env": "环境依赖更新（PyTorch / CUDA）",
            "kernel_stable": "ComfyUI 内核更新（正式版）",
            "kernel_dev": "ComfyUI 内核更新（开发版）",
        }
        if choice == "env" and env_details:
            triple, cuda_tag, is_nightly = env_details
            torch_v = (triple[0] if triple else None)
            self._log("🔄 开始执行：%s（PyTorch=%s，CUDA=%s，%s）" % (
                names.get(choice, choice),
                torch_v or "最新",
                cuda_tag,
                "nightly" if is_nightly else "stable"))
        elif choice in ("kernel_stable", "kernel_dev"):
            tgt = kernel_target or ("最新稳定版" if choice == "kernel_stable" else "master 最新")
            self._log("🔄 开始执行：%s（目标：%s）" % (names.get(choice, choice), tgt))
        else:
            self._log("🔄 开始执行：%s" % names.get(choice, choice))
        self.update_btn.setEnabled(False)
        self.update_progress.show()
        self._upd_worker = UpdateWorker(choice, env_details=env_details,
                                        kernel_target=kernel_target)
        self._upd_worker.log_sig.connect(self._on_update_log)
        self._upd_worker.done_sig.connect(self._on_update_done)
        self._upd_worker.start()

    def _on_update_log(self, msg):
        self._log(msg)

    def _on_update_done(self, ok, msg):
        self.update_btn.setEnabled(True)
        self.update_progress.hide()
        self._log("%s %s" % ("✅" if ok else "❌", msg))
        # 软件更新后刷新版本显示
        self.version_label.setText(self._comfy_version())

    # ===== 设置项 =====
    def _test_connection(self):
        ok = comfy_launch.is_ready(self.url_edit.text().strip())
        if ok:
            QMessageBox.information(self, "连接测试", "✅ ComfyUI 可访问")
            self._log("📡 连接测试通过")
        else:
            QMessageBox.warning(self, "连接测试", "❌ 无法访问，请确认地址与 ComfyUI 已启动")
            self._log("📡 连接测试失败")

    def _open_args_dialog(self):
        dlg = LaunchArgsDialog(self)
        if dlg.exec() == QDialog.Accepted:
            v = dlg.value()
            config.set_extra_args(v)
            self._log("✅ 启动参数已保存（下次启动生效）：%s" % (v or "（无）"))

    def _open_mirror_dialog(self, kind):
        dlg = MirrorDialog(self, kind)
        if dlg.exec() == QDialog.Accepted:
            if kind == "git":
                config.set_git_mirror(dlg.value())
                self._log("✅ Git 镜像已切换：%s" % dlg.text())
            else:
                config.set_hf_mirror(dlg.value())
                self._log("✅ HuggingFace 镜像已切换：%s" % dlg.text())

    def _safe_dialog_dir(self, candidate):
        """返回 QFileDialog 可用的起始目录，避免传入不存在路径导致弹窗。

        若 candidate 是相对路径，先按包根解析；不存在时依次回退到包根、
        用户桌面、D:/。彻底杜绝「位置不可用」弹窗。
        """
        if candidate:
            candidate = os.path.normpath(candidate.strip())
            if not os.path.isabs(candidate):
                candidate = os.path.join(_PKG_ROOT, candidate)
        if candidate and os.path.isdir(candidate):
            return candidate
        # 回退 1：包根（一定存在）
        if os.path.isdir(_PKG_ROOT):
            return _PKG_ROOT
        # 回退 2：系统桌面
        desktop = QStandardPaths.writableLocation(
            QStandardPaths.StandardLocation.DesktopLocation)
        if desktop and os.path.isdir(desktop):
            return desktop
        # 最终兜底
        return "D:/"

    def _pick_model_dir(self):
        d = QFileDialog.getExistingDirectory(
            self, "选择模型根目录（含 diffusion_models/loras/...）",
            self._safe_dialog_dir(self.model_dir_edit.text()))
        if d:
            self.model_dir_edit.setText(d)
            self._apply_model_dir()

    def _reset_model_dir(self):
        config.set_model_dir("")  # 存空 = 使用软件默认文件夹 ComfyUI/models
        self.model_dir_edit.setText(config.get_model_dir_display())
        self._log("↩️ 模型路径已恢复默认：%s" % config.MODEL_DIR_DISPLAY_DEFAULT)

    def _apply_model_dir(self):
        raw = self.model_dir_edit.text().strip()
        # 若用户手动输入或选中了软件默认目录，则按「默认」处理，不写死绝对路径
        if raw and (raw == config.MODEL_DIR_DISPLAY_DEFAULT or
                    os.path.normpath(raw) == os.path.normpath(config.MODEL_DIR_DEFAULT)):
            config.set_model_dir("")
            self.model_dir_edit.setText(config.get_model_dir_display())
            self._log("✅ 模型路径已恢复默认：%s（已自动保存）" % config.MODEL_DIR_DISPLAY_DEFAULT)
            return
        p = config.set_model_dir(raw)
        self._log("✅ 模型路径已设置：%s（已自动保存）" % p)
        # 同步 ComfyUI 的 extra_model_paths.yaml
        self._sync_extra_model_paths(p)

    def _sync_extra_model_paths(self, model_dir):
        yaml_path = os.path.join(comfy_launch.COMFY_DIR, "extra_model_paths.yaml")
        if not model_dir or not os.path.isdir(model_dir) or not os.path.isfile(yaml_path):
            return
        try:
            with open(yaml_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            norm = os.path.normpath(model_dir).replace("/", "\\")
            new_lines, changed = [], False
            for ln in lines:
                if ln.strip().startswith("base_path"):
                    indent = ln[:len(ln) - len(ln.lstrip())]
                    new = "%sbase_path: %s\n" % (indent, norm)
                    if ln.rstrip("\n") != new.rstrip("\n"):
                        changed = True
                    new_lines.append(new)
                else:
                    new_lines.append(ln)
            if changed:
                with open(yaml_path, "w", encoding="utf-8") as f:
                    f.writelines(new_lines)
                self._log("🔗 已把模型根写入 ComfyUI extra_model_paths.yaml")
        except Exception as e:
            self._log("同步模型路径失败：%s" % e)

    # ---- INPUT / OUTPUT 目录 ----
    def _pick_input_dir(self):
        d = QFileDialog.getExistingDirectory(
            self, "选择 ComfyUI INPUT 目录",
            self._safe_dialog_dir(self.input_dir_edit.text()))
        if d:
            self.input_dir_edit.setText(d)
            self._apply_input_dir()

    def _reset_input_dir(self):
        config.set_input_dir("")
        self.input_dir_edit.setText(config.get_input_dir_display())
        self._log("↩️ INPUT 目录已恢复默认：%s" % config.INPUT_DIR_DISPLAY_DEFAULT)

    def _apply_input_dir(self):
        raw = self.input_dir_edit.text().strip()
        # 若用户手动输入或选中了软件默认目录，则按「默认」处理，不写死绝对路径
        if raw and (raw == config.INPUT_DIR_DISPLAY_DEFAULT or
                    os.path.normpath(raw) == os.path.normpath(config.INPUT_DIR_DEFAULT)):
            config.set_input_dir("")
            self.input_dir_edit.setText(config.get_input_dir_display())
            self._log("✅ INPUT 目录已恢复默认：%s" % config.INPUT_DIR_DISPLAY_DEFAULT)
            return
        p = config.set_input_dir(raw)
        self.input_dir_edit.setText(p or config.get_input_dir_display())
        self._log("✅ INPUT 目录已设置：%s（已自动保存）" % p)

    def _pick_output_dir(self):
        d = QFileDialog.getExistingDirectory(
            self, "选择 ComfyUI OUTPUT 目录",
            self._safe_dialog_dir(self.output_dir_edit.text()))
        if d:
            self.output_dir_edit.setText(d)
            self._apply_output_dir()

    def _reset_output_dir(self):
        config.set_output_dir("")
        self.output_dir_edit.setText(config.get_output_dir_display())
        self._log("↩️ OUTPUT 目录已恢复默认：%s" % config.OUTPUT_DIR_DISPLAY_DEFAULT)

    def _apply_output_dir(self):
        raw = self.output_dir_edit.text().strip()
        if raw and (raw == config.OUTPUT_DIR_DISPLAY_DEFAULT or
                    os.path.normpath(raw) == os.path.normpath(config.OUTPUT_DIR_DEFAULT)):
            config.set_output_dir("")
            self.output_dir_edit.setText(config.get_output_dir_display())
            self._log("✅ OUTPUT 目录已恢复默认：%s" % config.OUTPUT_DIR_DISPLAY_DEFAULT)
            return
        p = config.set_output_dir(raw)
        self.output_dir_edit.setText(p or config.get_output_dir_display())
        self._log("✅ OUTPUT 目录已设置：%s（已自动保存）" % p)


if __name__ == "__main__":
    import time as _time
    _UI_T0 = _time.time()
    app = QApplication(sys.argv)
    # 在创建主窗口前设置应用级图标，Windows 任务栏/标题栏均会继承
    _icon = _app_icon_path()
    if _icon:
        app.setWindowIcon(QIcon(_icon))

    # ---- 单实例保护：保证全局只有一个启动器窗口 ----
    # 第二份实例会连上已有的本地服务器、请求把窗口提到前台后自行退出；
    # 首份实例创建本地服务器，收到请求后激活自身窗口。
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    _SINGLE_KEY = "XiaoNengComfyUILauncher"
    _single_server = QLocalServer()
    _probe = QLocalSocket()
    _probe.connectToServer(_SINGLE_KEY)
    if _probe.waitForConnected(300):
        # 已有实例在运行：发送激活指令后退出，避免重复打开
        _probe.write(b"show")
        _probe.waitForBytesWritten(300)
        _probe.disconnectFromServer()
        sys.exit(0)
    # 没有已有实例：本进程成为主实例（先清理上轮残留的死服务器，再监听）
    _single_server.removeServer(_SINGLE_KEY)
    _single_server.listen(_SINGLE_KEY)
    app._single_server = _single_server  # 挂到 app 上，避免事件循环期间被 GC

    w = MainWindow()
    w.show()
    # 窗口显示后再显式注册一次 ICO（pythonw 启动时有时仅靠 setWindowIcon 不够）
    _apply_windows_taskbar_icon(w)
    # 关掉 bootstrap 显示的启动进度条（跨进程：按窗口类名找到后发 WM_CLOSE），
    # 让用户看到的是「进度条 → 主界面」的无缝衔接。找不到（如控制台模式）则忽略。
    try:
        import splash
        splash.close()
    except Exception:
        pass
    # 记录 UI 冷启动耗时（双击 → 界面出现的主体耗时），用于定位慢在哪
    try:
        _pkg = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        with open(os.path.join(_pkg, "launch_log.txt"), "a", encoding="utf-8") as _fh:
            _fh.write("[ui] 进程启动 → 窗口显示 耗时 %.2fs\n"
                      % (_time.time() - _UI_T0))
    except Exception:
        pass

    def _on_new_conn():
        sock = _single_server.nextPendingConnection()
        if sock is None:
            return
        sock.readyRead.connect(lambda: _on_client_msg(sock))

    def _on_client_msg(sock):
        data = bytes(sock.readAll().data())
        if b"show" in data:
            # 把已有窗口提到前台（最小化时恢复、置顶、抢焦点）
            w.showNormal()
            w.raise_()
            w.activateWindow()
        sock.disconnectFromServer()

    _single_server.newConnection.connect(_on_new_conn)

    sys.exit(app.exec())
